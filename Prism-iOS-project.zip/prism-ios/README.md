# Prism TV 2.7.0 · build 14

Native SwiftUI remote and picture/sound controls for LG webOS, iOS 17+.
English interface, compact settings cards, lime accents and Liquid Glass on iOS 26.

## Install with your existing GitHub build

1. Replace the source ZIP at the repository root. Its name must be `Prism-iOS-project.zip`.
2. Commit and open Actions → Build Prism IPA.
3. Wait for a green run; download the **Prism-IPA** artifact.
4. Extract the artifact ZIP and sign/install **Prism-unsigned.ipa** with your sideload tool.
5. The installed app and `RELEASE.txt` must say **2.7.0 / build 14**.

The source ZIP is an Xcode project, not an installable IPA. Your already corrected ZIP-based workflow remains compatible. For a new repository, copy the supplied `BUILD_WORKFLOW.yml` into `.github/workflows/build.yml` and keep one active Prism workflow.

For an extracted-source repository, put the contents of `prism-ios` at the repository root and use `.github/workflows/build-ipa.yml` from that folder. Do not mix the extracted-source and ZIP-based layouts.

## Fixes in this release

- Handles `401 insufficient permissions`, code-only/nested errors, and unsupported-method responses. Compatible picture and sound writes are enabled by default. Once the TV rejects a direct settings route, subsequent writes reuse the compatible route for that category/session.
- Preserves the TV's error reason and code in the notice/diagnostics. A successful retry clears the previous notice. Timeouts and network failures never trigger a duplicate settings write.
- Uses one create/close-alert implementation for picture, sound and HDMI input type. Handles public/private alert ID differences after an explicit rejection. An accepted compatibility alert remains an unverified request, not a fabricated TV reading.
- Applies scene settings individually. One rejected optional setting no longer rejects the whole batch. Picture mode is sent first, allowed to settle, then read if supported. A different returned mode stops the scene; an unavailable mode reading allows the remaining requests and leaves them unverified.
- Retains the external audio route when changing sound mode. TV EQ stays disabled for an unknown/external output. Sound search and audio-context changes load the appropriate unread controls.
- Loads a fresh core picture snapshot when an input/app change is confirmed, even with background polling disabled. Late old-input replies are discarded.
- Shows app names such as YouTube instead of raw foreground IDs. Signal selection is directly accessible beside Input. Signal remains explicitly manual.
- Gives the bottom settings dock an opaque backing, keeps glass decoration noninteractive, and clears a failed numeric draft so a rejected edit does not remain displayed as a new value.
- Persists the compatible-write preference. Cancels/completes pending operations on disconnect.
- Updates every app/archive version check to build 14. Finds installed Xcode 26+ without depending on a particular patch filename. Standalone model tests explicitly target a supported macOS version.

## Connecting

Use the same Wi-Fi as the TV. Allow Local Network access, choose a discovered TV or enter its private IPv4 address, and approve pairing on the TV. Older sets commonly use WS port 3000; use the Secure option for WSS port 3001 when required. A self-signed certificate requires confirmation and is pinned to that host.

In App Settings, leave **Compatible settings writes** on. Read-back and automatic picture refresh are optional and off by default. Manual Refresh reads displayed values. `READ` is a received snapshot, `SET` is a request, and `SAVED` is a locally restored choice. An acknowledgement does not prove physical application.

Start matching SDR/HDR10/Dolby Vision content before choosing the signal or applying a preset. A manual signal selection does not change the TV's actual incoming signal. Firmware/mode restrictions can still prevent individual settings. There is no claim that every B9 setting can be forced through every firmware lock.

Sound settings address the LG TV. They do not control the TCL soundbar's internal equalizer or DSP. TV processing may not affect an external output in pass-through.

## Validation

`bash build-ipa.sh` on macOS with Xcode 26+ performs source/asset checks, archive tests, protocol tests, state-machine tests and regression tests. With `CI=true`, it also builds/launches the simulator app and runs native UI interaction tests before building and validating the Release IPA. Failures stop packaging; diagnostics are uploaded separately.

`python3 scripts/portable-tests.py` runs protocol and state-machine tests on Linux with Swift installed. Only Apple I/O, Keychain, observation notifications and Wake-on-LAN are replaced with test doubles; generated files stay under `build/portable` and never enter the app target.

The delivered project was checked in Linux. The iOS SDK, native hit testing, certificate handling, physical TV behavior and sideload installation require the macOS CI/device run. See `INTERACTION_AUDIT.md` for scope and `UPDATE.txt` for the short changelog.

Protocol references used for this repair:
- https://github.com/JPersson77/LGTVCompanion/issues/351
- https://github.com/chros73/bscpylgtv
