# Prism TV 2.6.2 · build 13

Native SwiftUI LG webOS remote for iOS 17+. English UI, charcoal/lime colours, native Liquid Glass on iOS 26+ and material/Reduce Transparency fallbacks.

## Build workflow

If you already installed the corrected workflow from the previous update, keep it: replacing the ZIP is sufficient. Much older workflows may upload a screenshot-only artifact named IPA after a failed build; those must be replaced.

For the ZIP-based repository:

1. Download this source ZIP to Files. Keep its exact name: `Prism-iOS-project.zip`.
2. Replace the ZIP at the root of your GitHub repository.
3. Only if your workflow is still the old version: extract a local copy in Files. Open the visible `BUILD_WORKFLOW.yml` inside it and copy its contents into GitHub's `.github/workflows/build.yml`. Use one active Prism build workflow; replace the previous one rather than leaving both active.
4. Commit both changes, then open Actions → Build Prism IPA.
5. Wait for a green run. Download **Prism-IPA**, not **Prism-build-diagnostics**.
6. Extract the downloaded artifact ZIP. Import **Prism-unsigned.ipa** into your signing/sideload tool. Do not import the source ZIP or GitHub's wrapper ZIP.
7. `RELEASE.txt` inside the artifact identifies the version, commit and IPA SHA-256. This is an unsigned IPA and needs signing before installation.

The archive does not contain a root `.github/workflows/build.yml`, preventing overwrite prompts with older extraction workflows. `BUILD_WORKFLOW.yml` is the replacement workflow to copy manually. If you maintain extracted source instead, use `prism-ios/.github/workflows/build-ipa.yml` and put the contents of `prism-ios` at your repository root. Do not mix those two layouts.

## Interaction fixes: 2.6.2

Home routes now use one explicit NavigationStack router. Entire rows have full-width rectangular touch regions, including blank space and chevrons. Glass is a separate, noninteractive background rather than a wrapper around controls. Toolbar icons use one system toolbar surface. Menus, navigation and help remain available while disconnected; TV writes keep their context/connection guards. EQ reads, local previews and TV writes have separate availability. App favourites are independent from launch buttons.

CI now runs native XCTest UI interactions before creating an IPA: every Home destination and Back, both toolbar buttons, a preference toggle, offline Display/Sound help, category/search interactions, and picture +/- dispatch with isolated Debug data. A failed UI test blocks packaging. Logs and screenshots are uploaded separately; the supplied workflow also retains the xcresult bundle. Tests have not been run on Xcode in this Linux workspace. The Debug data does not establish physical TV compatibility. See INTERACTION_AUDIT.md for findings and limits.

## Compact settings update: 2.6.1

Display and Sound now use dedicated dense setting cards, with 4-point vertical padding and no surplus gap between the header and control row at normal text sizes. Plus/minus, info and exact-value targets remain at least 44 points. Inter-card gaps shrink from 14 to 8 points. Section spacing and the bottom search/category area are smaller.

Option choices use a single horizontally scrollable 44-point row instead of wrapping ordinary-size choices into a second row. Larger text switches to adaptive grids and extra card spacing; no fixed card height clips accessibility content. Sound read/loading details move into the existing help UI/spinner instead of repeating full text lines under every card.

This is a UI-density update. TV commands, audio settings and connection behaviour are unchanged. Native iPhone layout verification is still required; simulator Home/Display/Sound previews remain part of CI diagnostics. Existing corrected workflow remains compatible.

## New in 2.6

The app now opens to a grouped home menu with TV connection/Manage, Remote, Display, Sound, Connectivity, Calibration guide, Presets, Quick Access and Apps & Inputs. Native NavigationStack replaces the old main tab layout. Display keeps its bottom categories/search. Quick Access is an in-app page, not a WidgetKit extension; the calibration page is guidance, not LUT or service-menu calibration. Unsupported mirroring/widget features are not represented by fake working buttons.

Sound includes 29 TV controls: output route; digital PCM/Auto/Pass Through; ARC/eARC; HDMI 1–4 bitstream/PCM; sound mode; AI/Smart sound; Clear Voice; auto volume; virtual surround; TV Atmos; speaker balance/placement; AV sync/bypass/delay; five-band TV EQ; broadcast audio priority; LG Sound Sync; audio description/level and power sound. Volume/mute are also available. The five-band array is validated and sent together; an unknown EQ requires a TV read or an explicit flat preview before a user applies it.

These are TV controls. They do not control a TCL soundbar's own EQ, subwoofer or surround DSP over eARC. External-output selection disables TV EQ and explains why. Keys/ranges are grounded in the documented 2019 C9 sound profile; B9 availability is unverified until its firmware replies. No current audio codec or active Atmos/eARC link is fabricated from an on/off setting.

Sound values load on first access to unread controls in a context, then use manual Refresh. Audio writes do not force read-back unless the existing preference is enabled. Numeric settings use JSON numbers and EQ uses five integer array elements. ACK/requested and actual read values are separate. Sound writes coalesce and serialize with picture writes. Output/mode changes clear prior processing/EQ snapshots; stale read replies cannot overwrite a newer edit. Disconnect and TV/input context changes clear sound state.

The supplied existing ZIP workflow remains compatible: replace the source ZIP and commit. If an older workflow names the artifact 2.5, that is only its label; RELEASE.txt and the app bundle identify 2.6. The bundled workflow uses the stable name Prism-IPA.

## Layout

Display Settings follows the supplied reference structure: video input and picture mode at the top, grouped inline sliders and choices, a fixed bottom row of Picture/Gaming/Advanced/All categories and a floating search/preferences/refresh bar. Back returns to the previous screen. Settings use native stack navigation with their own bottom category/search area.

Info buttons open native help sheets with What it does, update behaviour and timestamp/source details. Setting cards use individually separated glass surfaces. Unknown sliders remain visible and editable, with no fabricated current number. `READ` means a received snapshot, `SET` a requested value and `SAVED` a restored local choice; none means an instant subscription.

## Settings correctness

- Numeric values are JSON numbers; enum values remain strings. Invalid ranges, unknown keys and invalid enum choices are rejected.
- No background picture polling or read-after-every-write by default. Manual Refresh reads displayed settings; optional polling remains opt-in. Initial pairing reads core settings. Selecting a manual signal reads picture mode; scene mode confirmation is a bounded safety read.
- Signal context is explicitly manual: choose SDR, HDR10 or Dolby Vision in the search bar's preferences menu. Unknown is the honest default. Signal is not automatically detected from video frames.
- Saved selections use TV + input/app + chosen signal + picture mode. Unknown startup contexts do not restore an arbitrary previous input. Legacy per-input caches remain retained but are not automatically reused in the new context model.
- Input changes clear old readings and lock picture edits until the requested input/app is confirmed. Old foreground responses cannot release that lock. An unconfirmed switch times out with an error and unknown input context.
- Known signal restrictions are explained next to controls. Picture-mode choices are filtered by chosen signal. This is a conservative semantic filter, not a fully verified firmware capability database.
- Network/time-out failures do not trigger duplicate compatibility writes. The alert-based Luna fallback is restricted to recognized unsupported/permission failures. Alert closure is labelled unverified; it does not prove physical application.
- Scenes send the mode first and require a matching TV mode response before sending remaining settings. If that response is unavailable or different, the scene stops with an explicit error. This intentionally does not silently apply remaining values to an unconfirmed mode. Scene signal context is saved; legacy scenes remain identified as unknown.

## Connection and everyday controls

Saved TVs, direct pairing with Keychain keys, D-pad/pointer, volume/mute, playback, channels, text input, apps/HDMI inputs and B9 starting presets remain available. App favourites persist locally; app icons are loaded only when provided as HTTP(S) URLs on the selected TV itself.

Discovery checks ports 3000 and 3001 on the local subnet capped to /24. WS results must return a webOS TV hello. A device on port 3001 is only a **secure candidate** until pairing verifies it; it is not assumed to be an LG TV. Some networks still require manual IP entry.

TV editing now validates IP/MAC and allows WS 3000 or WSS 3001. TLS uses system trust or an explicitly approved SHA-256 certificate pin for that host. Unapproved/changed certificates are rejected pending user review, and secure navigation sockets cannot silently downgrade to WS. This path needs native/TV testing.

Foreground return checks connection health without refreshing all picture settings. Wake-on-LAN remains unicast; delivery depends on the router, ARP and TV standby settings. Invalid MACs and failed/timed-out sends are reported. A sent packet is not proof the TV woke.

Diagnostics include timestamps, model/firmware when reported, transport/context and a share action. Export masks IPv4 addresses. Pairing keys and text submissions are not added to diagnostics.

## Build and validation

On a Mac with Xcode 26+: `cd prism-ios && bash build-ipa.sh`.

The build runs source/configuration checks, archive regression tests, Swift parsing, protocol/model tests, simulator build/launch and a Release device build. It checks the app bundle and then validates the IPA's CRC, expected version, bundle ID, compiled assets, Mach-O executable and executable permissions. IPA and diagnostics are uploaded separately; a failed build cannot publish the install artifact through the supplied workflow.

Debug-only no-network fixtures create `simulator-home-preview.png`, `simulator-picture-preview.png` and `simulator-sound-preview.png` in diagnostics. This screenshot is a layout fixture, not a real TV reading. Release builds exclude the fixture. The normal simulator launch screenshot is separate.

Locally verified here: Python archive tests, shell syntax, source/project/version/icon checks, balanced Swift delimiters, YAML parsing and source ZIP integrity. This environment has no Swift/Xcode, iPhone or TV, so native compilation, new Swift test execution, screenshots, touch layout, WSS handshake and physical B9 behaviour remain unverified until CI/device testing.

## Scope boundaries

This release does not claim OLED Control feature parity. SSH/root transport, TPC/GSR/service controls, automatic HDR/DV detection, LUT calibration and system App Intents/macros are not implemented. Do not infer B9 support from a newer TV's screenshot. Additional advanced controls require a verified backend on the specific B9 firmware.

## Sound protocol references

- https://github.com/chros73/bscpylgtv/blob/master/docs/available_settings_C9.md — 2019 sound keys, choices, ranges and EQ array. C9 evidence is not a B9 compatibility guarantee.
- https://github.com/chros73/bscpylgtv/blob/master/bscpylgtv/endpoints.py — apiadapter sound-output read/change endpoints.
- https://github.com/chros73/bscpylgtv — category `sound` read/write examples.

Local metadata validation compared all 29 declared sound keys to that C9 document. Native Swift regression tests for audio bounds/EQ, coalescing, stale replies, output changes and state separation are included for CI; they have not run in the Linux authoring environment.
