# Prism TV 2.3.0 — LG webOS remote

Independent native SwiftUI app for iPhone and iPad, iOS 17+. Original design with native SwiftUI Liquid Glass on iOS 26+, a system-material fallback on iOS 17–25, a lime accent and generous spacing. Reduce Transparency uses opaque surfaces. No copied Spotify assets, branding or source code. The existing TV icon is retained.

## Update your existing GitHub repository

1. Replace the existing `Prism-iOS-project.zip` in the repository root with this ZIP. Keep the filename exactly the same; do not extract it there.
2. Commit the replacement. Your existing Actions workflow will unpack it and run `bash prism-ios/build-ipa.sh`.
3. Download `Prism-IPA` from the successful run, extract the artifact and sign/install `Prism-unsigned.ipa` using your sideload tool.

Keep bundle ID `com.kamilwhoo.prismtv` and the same signing identity if you want iOS to retain your saved TVs. If using extracted source instead, replace the whole `prism-ios` directory rather than mixing old and new Swift files.

**This ZIP is source, not a compiled IPA.** The authoring environment has no Xcode/Swift compiler or physical TV. Native compilation, simulator rendering and actual LG B9 operation have not been verified here. The build script runs regression tests and a simulator launch check on macOS before packaging the device IPA. These checks do not prove compatibility with every firmware.

## Current design (2.3)

The design uses CARROT Weather's data-first hierarchy as a direction, adapted for TV controls: a quiet atmospheric background, clear primary values and contained modules. Prism keeps its charcoal/teal and lime colours; no CARROT assets, copy, weather elements or screenshots are used.

- One native SwiftUI TabView remains available across Remote, Picture, Scenes and TVs. It provides the system navigation appearance, including Liquid Glass on supported iOS versions. The connection selector also uses native glass. Content cards and their buttons use quiet tonal surfaces, avoiding nested glass layers.
- Remote navigation and volume share a compact horizontal layout when space permits. Narrow screens and accessibility text use a vertical fallback. Home/Back/Menu and playback follow immediately; keyboard/touchpad/channels are disclosed under More.
- Picture has a consistent heading, search and category strip above its scrollable content. There is no second bottom navigation dock or persistent general-status footer.
- Cards show one main value and one TV/Selection source indicator. Queued/sending states use the header progress indicator. Only actual failures or conflicting TV replies add an error row. Regular selection/acknowledgement does not add duplicate value/status lines or a second line inside each option pill.
- Options use a single row where their natural widths fit, otherwise a wrapping grid; accessibility sizes get wider columns. Tap targets are retained rather than shrinking labels to fit five choices.
- Unknown numeric values have an unfilled dashed track. Moving the slider makes a deliberate proposal. Tapping the header number/dash reveals an inline exact-number field; it does not open another editor screen.
- The HDMI-type control is a collapsed advanced item; it appears for matching HDMI/input searches and does not dominate ordinary picture controls or unrelated search results.
- Saved-TV connection is the primary action when appropriate. Search is secondary once TVs exist; manual IP entry and technical options are disclosed separately. Native sheet/list backgrounds share the app's background.
- Preset and saved-scene application keep the required source/input confirmation with an always-reachable bottom action panel. Save-scene preview has an always-reachable Save toolbar action.

## Retained usability safeguards

Mode selection locks further picture edits until acknowledgement/settlement. The initial foreground-app reply preserves initial reads. Keyboard failures retain text; stale replies cannot clear a newer draft. Scene previews preserve the exact selection and distinguish received versus unverified keys. Saved scenes apply the mode before the remaining values. All previous discovery, remote, app/input, preset, WOL and manual-read functions remain.

## Read policy

Continuous picture refresh and read-after-write remain off by default. Core values are requested on connection. Category changes, search and foreground return do not themselves fetch picture values. Use Refresh or opt in via the gear menu. Labels never claim that an unverified write was physically applied.

## First connection

1. Turn on the TV. Connect iPhone and TV to the same Wi-Fi.
2. In **TV**, tap **Vyhľadať TV** and allow Local Network access. Choose the result and approve the pairing popup on the TV.
3. If discovery finds nothing, enter the TV's private IPv4 address manually. `192.168.0.110` is only a placeholder.
4. Test volume and navigation. If navigation is unavailable, tap **Opraviť navigáciu**. If denied again, clear pairing in the saved TV's menu and pair again.
5. Open **Obraz** and refresh the desired category. Use the visible sliders or choices directly. Expand the information button only for help.

The app does not change TV settings or connect automatically at launch. Discovery checks the local IPv4 subnet, capped to the phone's /24, with 16 concurrent probes. A candidate must answer as a webOS TV before appearing. Search is cancellable and does not initiate pairing.

## Real values and compatibility

The LG B9's public SSAP interface does not expose all picture values on all firmware. This app cannot turn an unsupported read into a real value. Unsupported values are explicitly unavailable, although a manual write may still be possible. A setting can also be blocked by the active signal or picture mode.

The app first requests `settings/setSystemSettings`. The optional compatibility method uses a webOS alert callback. A successful acknowledgement from either route does **not** prove that the panel applied the request. Optional read-back is shown separately, when enabled and exposed by the firmware. By default, writing does not trigger another read. Preset application is not atomic and does not provide a complete rollback.

This version supports private IPv4 WebSocket port 3000. TLS-only port 3001 firmware is not supported. Wake-on-LAN uses a supplied MAC address and unicast UDP, so it can fail after the router's ARP entry expires or if TV wake settings are disabled. There is no SSH/root backend, LUT upload or service-menu control.

## LG B9 presets

| Preset | Signal | Starting choices |
| --- | --- | --- |
| PS5 SDR | SDR | Game, OLED 60, contrast 85, brightness 50, colour 50, sharpness 10, Warm 2 |
| PS5 Kamil | SDR | Game, Warm 1, sharpness 25, Super Resolution Low; personal preference |
| Films night | SDR | Expert Dark, OLED 35, gamma 2.4 |
| Films day | SDR | Expert Bright, OLED 70, gamma 2.2 |
| PS5 HDR | HDR10 | HDR Game, OLED 100, peak High, HGiG if supported |
| Films HDR10 | HDR10 | HDR Cinema, OLED 100, peak High, DTM Off |
| Dolby Vision night | Dolby Vision | DV Cinema; preserve that mode's light/contrast/colour values |
| Dolby Vision day | Dolby Vision | DV Cinema Home; preserve that mode's light/contrast/colour values |

Presets are starting points, not a measured calibration. Adjust SDR OLED brightness to the room. Start the matching content before applying; signal detection is not automatic. Dolby Vision presets do not apply SDR gamma, HDR10 DTM or numerical OLED/contrast/colour overrides. They preserve the existing mode values rather than resetting factory defaults.

After HGiG selection, run the PS5 HDR adjustment patterns; no universal click count is assumed. HGiG support depends on firmware. HDMI range and input labels are not changed by these presets.

## Build from extracted source

On a Mac with Xcode 26+:

```bash
cd prism-ios
bash build-ipa.sh
```

Output: `build/Prism-unsigned.ipa`. This file needs signing before installation. Alternatively open `Prism.xcodeproj`, select your development team and run on iPhone.

The build runs:

1. Pure protocol/preset tests: LAN bounds, network byte order, WOL bytes, hello validation, JSON/framing, picture-response parsing and preset invariants.
2. Scripted-socket tests against the real connection model: received vs requested values, missing keys, stale input replies, rapid button order, socket readiness, volume parsing and inactive-TV deletion. Tests use isolated defaults and disable Keychain persistence.
3. In CI, an iPhone simulator build and launch check, with a screenshot and process check.
4. Release device compilation and bundle/icon validation before IPA packaging.

The scripted tests do not simulate every TV firmware or validate the physical screen. No native test result is claimed until this build runs successfully on macOS.

## GitHub workflow for a fresh repository

Use `.github/workflows/build.yml`:

```yaml
name: Build Prism IPA
on:
  workflow_dispatch:
  push:
    branches: [main, master]
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 25
    steps:
      - uses: actions/checkout@v4
      - name: Unpack project
        run: unzip -q Prism-iOS-project.zip
      - name: Build and test
        run: bash prism-ios/build-ipa.sh
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: Prism-IPA
          path: |
            prism-ios/build/Prism-unsigned.ipa
            prism-ios/build/simulator-launch.png
          if-no-files-found: warn
```

## Privacy

Pairing keys are stored in Keychain; TV names, IP/MAC addresses and scenes in local UserDefaults. Keys are omitted from diagnostics. No cloud service, advertising or analytics. ATS exceptions permit the B9's local plaintext WebSocket; connection code restricts destinations to private IPv4 addresses.

## Protocol and preset references

- https://github.com/JPersson77/LGTVCompanion
- https://github.com/chros73/bscpylgtv
- https://github.com/supersaiyanmode/PyWebOSTV
- https://www.rtings.com/tv/reviews/lg/b9-oled/settings
- https://www.lg.com/us/support/help-library/lg-tv-how-to-enable-the-hgig-setting--20153301892284
- https://www.playstation.com/cs-cz/support/hardware/ps5-enable-adjust-hdr/
- https://blog.playstation.com/2020/11/09/ps5-the-ultimate-faq/

## 2.0.1 / build 5 — reported build failure

The supplied Actions log confirmed both protocol and scripted-socket model tests passed on Xcode 26.3. Simulator compilation then failed because the `SettingEditor.body` getter lacked its closing brace, leaving `adjust` in local scope. This release closes that getter. A delimiter scan of all Swift files passes and detects the original missing-brace regression when reintroduced.

The build now runs Swift's syntax parser on all app sources before tests and keeps Xcode simulator/device logs. If Xcode fails, the reported compiler errors are repeated at the bottom of the build output for easier reading on iPhone. Full compilation of this corrected release still requires the next macOS Actions run.

## 2.1 verification and references

The supplied earlier Actions log confirmed the protocol and model suites on the 2.0 source. New 2.1 tests cover opt-in read-back, no automatic reads after a write, coalesced multi-control changes, retained unrelated values, range rejection and HDMI range labels/mapping. They are included in the build, but have not run locally because Xcode and Swift are unavailable here. Native Liquid Glass rendering and physical TV behaviour require the next macOS build and device test.

- Apple Liquid Glass API: https://developer.apple.com/documentation/swiftui/applying-liquid-glass-to-custom-views
- webOS HDMI low/limited, high/full and auto research: https://rorygallagher2024.github.io/glasshouse/development/TV-RESEARCH/
- Setting keys and ranges: https://github.com/JPersson77/LGTVCompanion/blob/master/Common/lg_api_commands.h

## 2.2 validation status

Local checks cover project wiring, source delimiters, shell syntax, version consistency, icon dimensions/colour and ZIP integrity. New Swift model regressions cover delayed initial foreground replies, mode locking/recovery, complete scene previews and stale-preview rejection, keyboard failure/retry/disconnect/stale replies, plus earlier queue/read/volume tests. These Swift tests require the next macOS Actions run; they have not been executed in this Linux environment.

The native appearance, actual touch hit-testing, VoiceOver traversal, large Dynamic Type layouts, Reduce Transparency and real LG B9 operations still require device testing. A passing compile/launch check alone is not a usability certification.

## 2.3 validation status

Local checks validate source delimiters, source references, version/privacy configuration, icon assets, shell syntax and ZIP integrity. The model suite includes separate command-error visibility and successful-retry clearing. Swift tests, native compilation, rendered layouts, actual touch targets, Dynamic Type, VoiceOver and physical LG B9 operation require a macOS/device run. This source delivery does not claim those native checks have already passed.

Design references:
- https://www.meetcarrot.com/weather/presskit.html
- https://developer.apple.com/design/human-interface-guidelines/materials
- https://developer.apple.com/videos/play/wwdc2025/219/
