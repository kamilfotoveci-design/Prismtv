# Prism TV 2.1.0 — LG webOS remote

Independent native SwiftUI app for iPhone and iPad, iOS 17+. Original design with native SwiftUI Liquid Glass on iOS 26+, a system-material fallback on iOS 17–25, a lime accent and generous spacing. Reduce Transparency uses opaque surfaces. No copied Spotify assets, branding or source code. The existing TV icon is retained.

## Update your existing GitHub repository

1. Replace the existing `Prism-iOS-project.zip` in the repository root with this ZIP. Keep the filename exactly the same; do not extract it there.
2. Commit the replacement. Your existing Actions workflow will unpack it and run `bash prism-ios/build-ipa.sh`.
3. Download `Prism-IPA` from the successful run, extract the artifact and sign/install `Prism-unsigned.ipa` using your sideload tool.

Keep bundle ID `com.kamilwhoo.prismtv` and the same signing identity if you want iOS to retain your saved TVs. If using extracted source instead, replace the whole `prism-ios` directory rather than mixing old and new Swift files.

**This ZIP is source, not a compiled IPA.** The authoring environment has no Xcode/Swift compiler or physical TV. Native compilation, simulator rendering and actual LG B9 operation have not been verified here. The build script runs regression tests and a simulator launch check on macOS before packaging the device IPA. These checks do not prove compatibility with every firmware.

## What changed in 2.1

- Picture sliders, plus/minus buttons and option grids are visible directly on the picture page. No editor sheet or extra Apply tap. Sliders submit on release; option buttons submit on tap.
- Native `glassEffect`, interactive glass buttons and `GlassEffectContainer` on iOS 26+. Material fallback on older systems and an opaque Reduce Transparency fallback.
- HDMI black level offers exactly Auto / Full / Limited: requests `auto` / `high` / `low`. Read aliases `full` and `limited` display consistently. The legacy value `medium` is never mislabelled Auto. Auto availability still depends on the TV's firmware, source and input type.
- Global setting search; Basics, Colour, Details, Motion, Gaming, Advanced and All categories. The catalogue includes 28 settings, including energy saving and eye comfort. Existing noise reduction, super resolution, gamma, gamut, TruMotion, Real Cinema and other controls are directly visible.
- Gaming/Advanced/All expose a target HDMI selector and PC / regular HDMI type requests. This does not claim to read the current input type.
- Continuous picture refresh and read-after-write are both **off by default**. Core picture values are read on connection. Thereafter use Refresh, or opt in to the two independent switches. Changing category, searching or returning to the foreground does not itself fetch picture values.
- Pending changes are serialised; rapid edits to the same queued key coalesce to its latest value. Requests are marked separately from received TV values. Unrelated settings retain their cached TV responses after a write.
- A disconnected picture screen shows an explicit reconnect action. Sliders and choices stay visible but cannot send while disconnected.
- Unknown numbers display a dash, never a fabricated current value. An unknown slider begins at its lower bound as a proposal position; moving it creates a visibly labelled request. Plus/minus needs a known value or proposal.
- The existing eight B9 starting presets, saved scenes, discovery, pointer remote, media controls, app/input switching, keyboard, touchpad and WOL remain.

## First connection

1. Turn on the TV. Connect iPhone and TV to the same Wi-Fi.
2. In **TV**, tap **Vyhľadať TV** and allow Local Network access. Choose the result and approve the pairing popup on the TV.
3. If discovery finds nothing, enter the TV's private IPv4 address manually. `192.168.0.110` is only a placeholder.
4. Test volume and navigation. If navigation is unavailable, tap **Opraviť navigáciu**. If denied again, clear pairing in the saved TV's menu and pair again.
5. Open **Obraz** and refresh the desired category. Use the visible sliders or choices directly. Expand the information button only for help.

The app does not change TV settings or connect automatically at launch. Discovery checks the local IPv4 subnet, capped to the phone's /24, with 16 concurrent probes. A candidate must answer as a webOS TV before appearing. Search is cancellable and does not initiate pairing.

## Real values and compatibility

The LG B9's public SSAP interface does not expose all picture values on all firmware. This app cannot turn an unsupported read into a real value. Unsupported values are explicitly unavailable, although a manual write may still be possible. A setting can also be blocked by the active signal or picture mode.

The app first requests `settings/setSystemSettings`. The optional compatibility method uses a webOS alert callback. A successful acknowledgement from either route does **not** prove that the panel applied the request. Optional read-back is shown separately, when enabled and exposed by the firmware. By default, writing does not trigger another read. Preset application is not atomic and does not provide a complete rollback.

This version supports private IPv4 WebSocket port 3000. TLS-only port 3001 firmware is not supported. Wake-on-LAN uses a supplied MAC address and unicast UDP, so it can fail after the router's ARP entry expires or if TV wake settings are disabled. There is no SSH/root backend, LUT upload or service-menu control.

## LG B9 presets

| Preset | Signal | Starting choices |
| --- | --- | --- |
| PS5 SDR | SDR | Game, OLED 60, contrast 85, brightness 50, colour 50, sharpness 10, Warm 2 |
| PS5 Kamil | SDR | Game, Warm 1, sharpness 25, Super Resolution Low; personal preference |
| Films night | SDR | Expert Dark, OLED 35, gamma 2.4 |
| Films day | SDR | Expert Bright, OLED 70, gamma 2.2 |
| PS5 HDR | HDR10 | HDR Game, OLED 100, peak High, HGiG if supported |
| Films HDR10 | HDR10 | HDR Cinema, OLED 100, peak High, DTM Off |
| Dolby Vision night | Dolby Vision | DV Cinema; preserve that mode's light/contrast/colour values |
| Dolby Vision day | Dolby Vision | DV Cinema Home; preserve that mode's light/contrast/colour values |

Presets are starting points, not a measured calibration. Adjust SDR OLED brightness to the room. Start the matching content before applying; signal detection is not automatic. Dolby Vision presets do not apply SDR gamma, HDR10 DTM or numerical OLED/contrast/colour overrides. They preserve the existing mode values rather than resetting factory defaults.

After HGiG selection, run the PS5 HDR adjustment patterns; no universal click count is assumed. HGiG support depends on firmware. HDMI range and input labels are not changed by these presets.

## Build from extracted source

On a Mac with Xcode 26+:

```bash
cd prism-ios
bash build-ipa.sh
```

Output: `build/Prism-unsigned.ipa`. This file needs signing before installation. Alternatively open `Prism.xcodeproj`, select your development team and run on iPhone.

The build runs:

1. Pure protocol/preset tests: LAN bounds, network byte order, WOL bytes, hello validation, JSON/framing, picture-response parsing and preset invariants.
2. Scripted-socket tests against the real connection model: received vs requested values, missing keys, stale input replies, rapid button order, socket readiness, volume parsing and inactive-TV deletion. Tests use isolated defaults and disable Keychain persistence.
3. In CI, an iPhone simulator build and launch check, with a screenshot and process check.
4. Release device compilation and bundle/icon validation before IPA packaging.

The scripted tests do not simulate every TV firmware or validate the physical screen. No native test result is claimed until this build runs successfully on macOS.

## GitHub workflow for a fresh repository

Use `.github/workflows/build.yml`:

```yaml
name: Build Prism IPA
on:
  workflow_dispatch:
  push:
    branches: [main, master]
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 25
    steps:
      - uses: actions/checkout@v4
      - name: Unpack project
        run: unzip -q Prism-iOS-project.zip
      - name: Build and test
        run: bash prism-ios/build-ipa.sh
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: Prism-IPA
          path: |
            prism-ios/build/Prism-unsigned.ipa
            prism-ios/build/simulator-launch.png
          if-no-files-found: warn
```

## Privacy

Pairing keys are stored in Keychain; TV names, IP/MAC addresses and scenes in local UserDefaults. Keys are omitted from diagnostics. No cloud service, advertising or analytics. ATS exceptions permit the B9's local plaintext WebSocket; connection code restricts destinations to private IPv4 addresses.

## Protocol and preset references

- https://github.com/JPersson77/LGTVCompanion
- https://github.com/chros73/bscpylgtv
- https://github.com/supersaiyanmode/PyWebOSTV
- https://www.rtings.com/tv/reviews/lg/b9-oled/settings
- https://www.lg.com/us/support/help-library/lg-tv-how-to-enable-the-hgig-setting--20153301892284
- https://www.playstation.com/cs-cz/support/hardware/ps5-enable-adjust-hdr/
- https://blog.playstation.com/2020/11/09/ps5-the-ultimate-faq/

## 2.0.1 / build 5 — reported build failure

The supplied Actions log confirmed both protocol and scripted-socket model tests passed on Xcode 26.3. Simulator compilation then failed because the `SettingEditor.body` getter lacked its closing brace, leaving `adjust` in local scope. This release closes that getter. A delimiter scan of all Swift files passes and detects the original missing-brace regression when reintroduced.

The build now runs Swift's syntax parser on all app sources before tests and keeps Xcode simulator/device logs. If Xcode fails, the reported compiler errors are repeated at the bottom of the build output for easier reading on iPhone. Full compilation of this corrected release still requires the next macOS Actions run.

## 2.1 verification and references

The supplied earlier Actions log confirmed the protocol and model suites on the 2.0 source. New 2.1 tests cover opt-in read-back, no automatic reads after a write, coalesced multi-control changes, retained unrelated values, range rejection and HDMI range labels/mapping. They are included in the build, but have not run locally because Xcode and Swift are unavailable here. Native Liquid Glass rendering and physical TV behaviour require the next macOS build and device test.

- Apple Liquid Glass API: https://developer.apple.com/documentation/swiftui/applying-liquid-glass-to-custom-views
- webOS HDMI low/limited, high/full and auto research: https://rorygallagher2024.github.io/glasshouse/development/TV-RESEARCH/
- Setting keys and ranges: https://github.com/JPersson77/LGTVCompanion/blob/master/Common/lg_api_commands.h
