# Prism TV 2.4.0

Native SwiftUI remote for LG webOS, iOS 17+. All app-owned UI, presets, help text, accessibility labels and status messages are English. Existing user-created names and content supplied by the TV are preserved.

## Update from iPhone

1. Replace `Prism-iOS-project.zip` at the root of your existing GitHub repository. Keep its name and do not extract it there.
2. Commit. Your workflow runs `bash prism-ios/build-ipa.sh`.
3. Download the successful `Prism-IPA` artifact, extract it, and sign/install `Prism-unsigned.ipa` using your sideload tool.

If using extracted source, replace the entire `prism-ios` directory. Keep the bundle ID and signing identity to retain local app data.

## Current changes

- English screens, settings, presets, help, accessibility labels and error messages. English is declared as the bundle language and used in the SwiftUI locale.
- A single compact Picture heading, combined search/settings/refresh row and existing native tab navigation.
- Tighter cards, aligned headers, 44-point plus/minus targets and no repeated unknown markers or drag text.
- `Connect TV` stays visible in the header when disconnected. It reconnects the selected saved TV directly; with no TV it opens setup. While connecting it becomes Cancel connection.
- Last acknowledged choices persist locally by saved TV and input. `SAVED` explicitly identifies a restored choice, `TV` a received value and `SET` a current selection/request. A saved choice is never treated as a live reading or applied automatically.
- A first foreground-app response selects the input cache without discarding initial TV reads or newer in-session selections. A different known input uses its own cache. Removing a TV removes its cached choices.
- Unknown numeric values remain a single dash and an empty track. Drag to choose a value or tap the header value to enter an exact number. No invented current zero or midpoint.
- Automatic refresh and read-after-write remain off by default.

## Features

Private-IPv4 webOS WebSocket connection and TV-approved pairing; Keychain pairing keys; bounded local discovery; saved TVs; D-pad and pointer control; volume/mute, media and channels; apps and HDMI inputs; text entry with failure/retry retention; manual picture reads and queued writes; Auto/Full/Limited HDMI range; PC/HDMI type requests; eight LG B9 SDR/HDR10/Dolby Vision starting presets; saved scenes with exact previews and verified/unverified distinctions; mode-first scene application; unicast Wake-on-LAN with a supplied MAC.

Picture values requested through the public SSAP interface vary by model, firmware, input and signal. Unsupported reads remain unknown. A write acknowledgement or successful compatibility alert does not prove that the panel applied the setting. Optional read-back is displayed separately.

This version supports private IPv4 `ws://` port 3000, not TLS-only port 3001 firmware. Discovery checks the local subnet capped to /24 with 16 concurrent probes and verifies a webOS TV hello before listing it. WOL can fail when router ARP entries expire or wake settings are disabled. No SSH/root backend, service-menu changes, LUT uploads or cloud account are implemented.

## First use

Connect iPhone and powered-on TV to the same Wi-Fi. Use Find TV and approve Local Network access, select the result and accept pairing on the TV. Manual IP entry is available under Add by IP address. The placeholder IP is not a discovery result. Use Repair navigation if needed; clear pairing and reconnect if the TV denies the navigation socket.

## LG B9 presets

Start matching SDR, HDR10 or Dolby Vision content before applying a preset; signal detection is not automatic. Confirm the signal in the preview. SDR OLED levels are room-brightness starting points, not measured calibration. Dolby Vision presets preserve the mode's existing brightness/contrast/color values and do not apply SDR gamma or HDR10 tone mapping. HGiG depends on firmware; after choosing it, run the PS5 HDR adjustment patterns without assuming a fixed click count. HDMI range and input type are not changed by these presets.

## Build and verification

On a Mac with Xcode 26+:

```bash
cd prism-ios
bash build-ipa.sh
```

The script validates sources/assets and parses Swift syntax, runs protocol/preset and scripted-socket model tests, performs a simulator launch check in CI, compiles a Release device app and validates the bundle/icon before creating the unsigned IPA.

New cache tests cover session restoration, honest saved-versus-received markers, per-TV isolation and per-input restoration. Existing tests cover delayed foreground replies, mode locking, complete scene previews, stale responses, keyboard retention, request queuing, volume and transport errors.

The authoring environment has no Xcode/Swift compiler or physical TV. Local checks cover project wiring, version/language/privacy configuration, app icons, shell syntax, source delimiters and archive integrity. New Swift tests, native compilation, visual appearance, touch hit-testing, VoiceOver and physical LG B9 behaviour still require the next macOS/device run. A launch check alone does not certify usability.

## Fresh GitHub workflow

```yaml
name: Build Prism IPA
on:
  workflow_dispatch:
  push:
    branches: [main, master]
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 25
    steps:
      - uses: actions/checkout@v4
      - name: Unpack project
        run: unzip -q Prism-iOS-project.zip
      - name: Build and test
        run: bash prism-ios/build-ipa.sh
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: Prism-IPA
          path: |
            prism-ios/build/Prism-unsigned.ipa
            prism-ios/build/simulator-launch.png
          if-no-files-found: warn
```

## Privacy

Pairing keys remain in Keychain. Device IP/MAC/name, scene values and cached selections stay in local UserDefaults. Text submissions are not logged. No advertising, analytics or cloud backend. Native system permission buttons and names/content supplied by other services may follow the device or TV language.

## References

- https://github.com/JPersson77/LGTVCompanion
- https://github.com/chros73/bscpylgtv
- https://github.com/supersaiyanmode/PyWebOSTV
- https://www.rtings.com/tv/reviews/lg/b9-oled/settings
- https://www.playstation.com/cs-cz/support/hardware/ps5-enable-adjust-hdr/
- https://developer.apple.com/documentation/swiftui/applying-liquid-glass-to-custom-views
