# Prism TV — iOS remote for LG webOS

Independent native SwiftUI app inspired by the supplied OLED Control references. The original app's name, assets and proprietary code are not included. Dark glass cards, cyan selection chips, ± sliders, bottom setting categories and search follow the supplied visual direction.

## Build status

This ZIP contains an Xcode project, NOT a compiled IPA. The current execution environment is Linux without Xcode. iOS compilation, visual rendering and connection to the user's physical LG B9 have not been performed here. GitHub CI compiles protocol tests, builds and launches the simulator app, then builds a device IPA. That IPA needs signing by the user's sideload tool.

## Features implemented

- Direct local WebSocket connection to a private IPv4 address, port 3000.
- TV approval prompt and client-key storage in iOS Keychain.
- Automatic nearby TV search with progress, cancellation and local-network permission help. Unicast TCP port checks are followed by a webOS hello identification, without pairing prompts until the user selects a TV. Search covers the iPhone’s IPv4 Wi-Fi subnet, capped to its local /24 (up to 253 other addresses). Larger networks and TVs without the port-3000 hello response still have manual IP fallback.
- Saved TVs and selected-TV switching.
- Remote D-pad/OK/Home/Back/Settings, playback, volume, mute, channel buttons, numbers.
- Pointer touchpad and text input while a TV text field is open.
- Installed app list and launch; external-input list and switching.
- Picture controls: OLED pixel brightness, contrast, brightness/near-black, colour, tint, colour temperature, sharpness, peak brightness, dynamic contrast/colour, super resolution, noise/MPEG reduction, smooth gradation, gamma, HDMI range, white balance, HDR tone mapping/HGiG, TruMotion, Motion Eye Care, Real Cinema and BFI where the TV supports the supplied key.
- Explicit target HDMI selection and PC / Regular HDMI requests.
- Picture/Gaming/Advanced categories, setting info sheets and global search.
- Saved picture profiles per TV. Values apply to the current input/signal; no automatic input/signal switching.
- Direct SSAP picture writes with optional settings-service alert callback fallback. A brief TV alert may flash. A successful alert operation does NOT prove that firmware applied a setting.
- LIVE badge = value received on the last TV read; SET = last requested value. Unknown settings do not pretend to have a current value. Only core brightness/contrast/colour values are requested for read-back by default because some firmware rejects reads containing unsupported keys.
- Unicast Wake-on-LAN with a supplied TV MAC. It may not work after the router's ARP entry expires. Requires the TV's relevant wake options.
- Native Liquid Glass with Xcode 26/iOS 26+, system-material fallback on iOS 17–25, Reduce Transparency support.
- Independent glass TV icon, all required opaque PNG sizes.

## Important compatibility limits

This version targets LG B9-era webOS with plaintext local WebSocket port 3000. Firmware that only accepts TLS on 3001 is not implemented. There is no global certificate-validation bypass.

Home Screen widgets, service-menu TPC/GSR changes, LUT/calibration uploads and an SSH/root backend are not implemented. The app does not claim complete feature parity with OLED Control.

The input mode, signal and firmware may prevent a requested picture change even when a setting is greyed out in LG's menu. Peak Brightness requests do not guarantee the TV will override its current restrictions.

## Build on GitHub from an iPhone

Use a NEW repository such as `prism-tv` so the working Luma project stays separate.

1. Upload `Prism-iOS-project.zip` to the root of the repository as a ZIP, without extracting it.
2. Add a new file named `.github/workflows/build.yml`.
3. Paste the following workflow and commit:

```yaml
name: Build Prism IPA
on:
  workflow_dispatch:
  push:
    branches: [main, master]
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 25
    steps:
      - uses: actions/checkout@v4
      - name: Unpack project
        run: unzip -q Prism-iOS-project.zip
      - name: Build and test
        run: bash prism-ios/build-ipa.sh
      - uses: actions/upload-artifact@v4
        with:
          name: Prism-IPA
          path: prism-ios/build/Prism-unsigned.ipa
          if-no-files-found: error
```

4. Open Actions → Build Prism IPA.
5. On success, download Artifacts → Prism-IPA; extract the artifact ZIP and sign/install `Prism-unsigned.ipa` using your sideload tool (for example the user's Flarestore setup).

No Apple credentials or certificates need to be added to the repository for this unsigned build. Use your own GitHub account's Actions allowance.

## Build from extracted source on a Mac

Install Xcode 26+. In the extracted `prism-ios` directory:

```bash
bash build-ipa.sh
```

The build performs the pure Foundation protocol tests. In GitHub CI it also runs the simulator launch test. Output: `build/Prism-unsigned.ipa`.

You can instead open `Prism.xcodeproj`, select your team in Signing & Capabilities and run on your iPhone.

## First connection

1. Keep the iPhone and TV on the same local network. Turn the TV on.
2. In Prism → TVs → Find TV on Wi-Fi, allow Local Network access and select a discovered TV. Search does not register or change settings. If none is found, expand Add by IP instead and enter the current IP from LG Network settings. 192.168.0.110 is a placeholder, not a discovery result.
3. Selecting a discovered TV starts pairing. For a manually added TV, tap Connect.
4. Accept the pairing popup on the TV using the physical remote.
5. Test volume and the D-pad, then Display → Refresh.
6. If buttons fail, Clear selected TV pairing and reconnect. If picture writes fail, check the compatibility-method toggle and Diagnostics.

The app does not connect or change settings automatically at launch.

## Diagnostics

For a startup crash, share the newest Prism `.ips` report from iPhone Analytics Data and the signing/install method. Build errors are in the red GitHub Actions step.

## Privacy and transport

Pairing keys are held in Keychain and are not included in diagnostic messages. Saved device IP/MAC/name and profiles stay in local UserDefaults. Network URLs are restricted in application code to private IPv4 addresses. The app's ATS allowance accommodates the B9's local plaintext WebSocket. It uses no cloud API, analytics or advertising.

## Protocol references

- App reference: https://apps.apple.com/us/app/oled-control-smart-tv-remote/id6747833454
- SSAP and normal unsigned pairing permissions: https://github.com/JPersson77/LGTVCompanion/issues/351
- Picture key/value catalogue: https://github.com/JPersson77/LGTVCompanion/blob/master/Common/lg_api_commands.h
- Picture/Luna examples: https://github.com/chros73/bscpylgtv
- Remote keyboard and commands: https://github.com/klattimer/LGWebOSRemote
- HDMI EIM request: https://github.com/JPersson77/LGTVCompanion/discussions/171
- Native Liquid Glass: https://developer.apple.com/documentation/swiftui/applying-liquid-glass-to-custom-views

## Icon

Generated with the built-in image tool: a front-facing television sculpted from translucent cyan/violet liquid glass on a full-bleed midnight background, no text or LG/Apple marks. Embedded under `Prism/Assets.xcassets/AppIcon.appiconset`.

## Discovery and modern layout update

The project now includes automatic nearby IPv4 discovery without a restricted multicast entitlement. It does not send SSDP broadcasts or silently register a device. Each open port candidate must respond to an SSAP hello as a webOS television. Standard Local Network permission is still required. Search is bounded to 16 concurrent probes and the local /24 or smaller actual subnet; it can be stopped.

Tests cover private-address validation, subnet bounds, /30 and /32 cases, noncontiguous-mask rejection, hello identification, remote framing, alert-ID normalization and Wake-on-LAN data. They are compiled and executed in the build script on macOS; they have not run in the Linux authoring environment.

The interface uses shared native GlassEffectContainer on iOS 26, cyan selection chips, large rounded cards, bottom search/category controls and the supplied display-settings visual references. No copied screenshot images are included in the product.

## Prism TV 1.1.0 — LG B9 starting presets

Eight built-in presets are now under Profiles, filtered by SDR, HDR10 or Dolby Vision. They are practical starting points, not measurements or a calibration of the user's individual panel.

| Preset | Required signal | Mode | Key choices |
| --- | --- | --- | --- |
| PS5 SDR | SDR | Game | OLED 60 starting point, contrast 85, brightness 50, colour 50, sharpness 10, Warm 2, peak Off |
| PS5 Kamil | SDR | Game | Warm 1, sharpness 25, Super Resolution Low; preference profile |
| SDR films night | SDR | Expert Dark | OLED 35 starting point, contrast 85, gamma 2.4, Real Cinema On |
| SDR films day | SDR | Expert Bright | OLED 70 starting point, contrast 85, gamma 2.2, Real Cinema On |
| PS5 HDR HGiG | HDR10 | HDR Game | OLED 100, contrast 100, peak High, HGiG when supported; recalibrate PS5 HDR afterwards |
| HDR10 films | HDR10 | HDR Cinema | OLED 100, peak High, DTM Off, Real Cinema On |
| Dolby Vision night | Dolby Vision | DV Cinema | Preserve the mode's light/contrast/colour settings; interpolation Off |
| Dolby Vision day | Dolby Vision | DV Cinema Home | Preserve the mode's light/contrast/colour settings; interpolation Off |

Warm 1 / Warm 2 may be selected as an explicit override in the preview. Preset is the default; the personal Kamil preset uses Warm 1. The Dolby Vision presets do not copy SDR gamma, HDR10 DTM or numerical brightness/contrast values. They preserve existing values rather than resetting the TV to factory settings.

OLED values in SDR are adjustable room-brightness choices. The night gamma 2.4 is an editorial dark-room starting choice; the measured B9 source used gamma 2.2 as its target. HDMI range and input labels are intentionally not changed by these picture presets. The user can adjust them separately.

The preview requires confirmation that the TV is showing the required signal; there is no automatic HDR/DV detection. Applying requests the picture mode first and waits 1.2 seconds before requesting its values. Each step checks connection/input continuity and stops on reported failure. A request acknowledged through the compatibility alert does not prove the TV physically applied it. This is not an atomic transaction or automatic full backup.

PS5 guidance: HDR On When Supported preserves SDR games. After HGiG selection, use PS5 Settings → Screen and Video → Video Output → Adjust HDR; no fixed click count is assumed. Dolby Vision profiles are for actual DV sources/content, not a PS5 HDR10 signal.

Sources:
- B9 measured settings: https://www.rtings.com/tv/reviews/lg/b9-oled/settings
- B9 HDR measurements: https://www.rtings.com/tv/reviews/lg/b9-oled
- LG HGiG support and model dependence: https://www.lg.com/us/support/help-library/lg-tv-how-to-enable-the-hgig-setting--20153301892284
- PS5 HDR setup: https://www.playstation.com/cs-cz/support/hardware/ps5-enable-adjust-hdr/
- Sony PS5 HDR10 specification: https://blog.playstation.com/2020/11/09/ps5-the-ultimate-faq/

This update still needs Xcode compilation and physical B9 verification. Build scripts now compile preset invariants as well as protocol tests, then run the simulator startup check in CI.

## 1.1.1 / build 3 — Xcode 26.3 discovery compile fix

Replaced both uses of the Darwin C macro `ntohl`, which this SDK does not import into Swift, with `UInt32(bigEndian:)` in the shared IPv4 formatter. Added regression checks for a known network-order IP and subnet mask. No discovery, preset or UI features were removed. The reported compilation error is addressed; full iOS compilation still runs in GitHub CI, not in the Linux authoring environment.
