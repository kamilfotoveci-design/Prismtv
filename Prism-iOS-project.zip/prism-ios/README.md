# Prism TV 2.0 — LG webOS remote

Independent native SwiftUI app for iPhone and iPad, iOS 17+. New original design: charcoal surfaces, lime accent, clean typography and generous spacing. No copied Spotify assets, branding or source code. The existing TV icon is retained.

## Update your existing GitHub repository

1. Replace the existing `Prism-iOS-project.zip` in the repository root with this ZIP. Keep the filename exactly the same; do not extract it there.
2. Commit the replacement. Your existing Actions workflow will unpack it and run `bash prism-ios/build-ipa.sh`.
3. Download `Prism-IPA` from the successful run, extract the artifact and sign/install `Prism-unsigned.ipa` using your sideload tool.

Keep bundle ID `com.kamilwhoo.prismtv` and the same signing identity if you want iOS to retain your saved TVs. If using extracted source instead, replace the whole `prism-ios` directory rather than mixing old and new Swift files.

**This ZIP is source, not a compiled IPA.** The authoring environment has no Xcode/Swift compiler or physical TV. Native compilation, simulator rendering and actual LG B9 operation have not been verified here. The build script runs regression tests and a simulator launch check on macOS before packaging the device IPA. These checks do not prove compatibility with every firmware.

## What changed

- Four uncluttered sections: remote, picture, scenes and TVs. Apps/inputs, touchpad and keyboard open separately.
- Remote D-pad targets are at least 76 points tall, with 14-point gaps. Action buttons are at least 52 points tall. Disabled controls are visually dimmed.
- Navigation readiness follows the actual WebSocket open event, with an explicit repair action. It no longer depends on the TV answering a ping.
- Rapid navigation commands use a bounded serial queue, preserving order. Touchpad updates are limited to 25 per second.
- Playback and channels use SSAP endpoints directly; they do not require the pointer connection.
- Volume and mute are read from TV responses, including nested `volumeStatus`. Unknown values stay unknown. Mute reads the TV state before toggling if necessary.
- Picture responses and requested writes are stored separately. An acknowledgement never becomes a current value.
- Each picture row opens its own editor. Values from the TV have a read timestamp. An unavailable read never becomes zero, a midpoint or the last requested value.
- Read failures retry once using current-app context, then show unavailable. Reads are limited to three at a time. The visible category is refreshed in the foreground.
- Input/context changes discard old picture values and late responses. Writing settings also invalidates earlier reads before requesting read-back.
- Deleting an inactive saved TV preserves the active connection.
- Legacy saved scenes are labelled unverified; new scenes contain only received TV values.
- Eight LG B9 starting presets remain, with separate SDR/HDR10/Dolby Vision selection and an explicit source confirmation. A contradictory picture-mode read stops the remaining preset requests.

## First connection

1. Turn on the TV. Connect iPhone and TV to the same Wi-Fi.
2. In **TV**, tap **Vyhľadať TV** and allow Local Network access. Choose the result and approve the pairing popup on the TV.
3. If discovery finds nothing, enter the TV's private IPv4 address manually. `192.168.0.110` is only a placeholder.
4. Test volume and navigation. If navigation is unavailable, tap **Opraviť navigáciu**. If denied again, clear pairing in the saved TV's menu and pair again.
5. Open **Obraz** and refresh the desired category. Tap a setting to inspect the actual response and request a change.

The app does not change TV settings or connect automatically at launch. Discovery checks the local IPv4 subnet, capped to the phone's /24, with 16 concurrent probes. A candidate must answer as a webOS TV before appearing. Search is cancellable and does not initiate pairing.

## Real values and compatibility

The LG B9's public SSAP interface does not expose all picture values on all firmware. This app cannot turn an unsupported read into a real value. Unsupported values are explicitly unavailable, although a manual write may still be possible. A setting can also be blocked by the active signal or picture mode.

The app first requests `settings/setSystemSettings`. The optional compatibility method uses a webOS alert callback. A successful acknowledgement from either route does **not** prove that the panel applied the request. Read-back is shown separately, when the firmware exposes it. Preset application is not atomic and does not provide a complete rollback.

This version supports private IPv4 WebSocket port 3000. TLS-only port 3001 firmware is not supported. Wake-on-LAN uses a supplied MAC address and unicast UDP, so it can fail after the router's ARP entry expires or if TV wake settings are disabled. There is no SSH/root backend, LUT upload or service-menu control.

## LG B9 presets

| Preset | Signal | Starting choices |
| --- | --- | --- |
| PS5 SDR | SDR | Game, OLED 60, contrast 85, brightness 50, colour 50, sharpness 10, Warm 2 |
| PS5 Kamil | SDR | Game, Warm 1, sharpness 25, Super Resolution Low; personal preference |
| Films night | SDR | Expert Dark, OLED 35, gamma 2.4 |
| Films day | SDR | Expert Bright, OLED 70, gamma 2.2 |
| PS5 HDR | HDR10 | HDR Game, OLED 100, peak High, HGiG if supported |
| Films HDR10 | HDR10 | HDR Cinema, OLED 100, peak High, DTM Off |
| Dolby Vision night | Dolby Vision | DV Cinema; preserve that mode's light/contrast/colour values |
| Dolby Vision day | Dolby Vision | DV Cinema Home; preserve that mode's light/contrast/colour values |

Presets are starting points, not a measured calibration. Adjust SDR OLED brightness to the room. Start the matching content before applying; signal detection is not automatic. Dolby Vision presets do not apply SDR gamma, HDR10 DTM or numerical OLED/contrast/colour overrides. They preserve the existing mode values rather than resetting factory defaults.

After HGiG selection, run the PS5 HDR adjustment patterns; no universal click count is assumed. HGiG support depends on firmware. HDMI range and input labels are not changed by these presets.

## Build from extracted source

On a Mac with Xcode 26+:

```bash
cd prism-ios
bash build-ipa.sh
```

Output: `build/Prism-unsigned.ipa`. This file needs signing before installation. Alternatively open `Prism.xcodeproj`, select your development team and run on iPhone.

The build runs:

1. Pure protocol/preset tests: LAN bounds, network byte order, WOL bytes, hello validation, JSON/framing, picture-response parsing and preset invariants.
2. Scripted-socket tests against the real connection model: received vs requested values, missing keys, stale input replies, rapid button order, socket readiness, volume parsing and inactive-TV deletion. Tests use isolated defaults and disable Keychain persistence.
3. In CI, an iPhone simulator build and launch check, with a screenshot and process check.
4. Release device compilation and bundle/icon validation before IPA packaging.

The scripted tests do not simulate every TV firmware or validate the physical screen. No native test result is claimed until this build runs successfully on macOS.

## GitHub workflow for a fresh repository

Use `.github/workflows/build.yml`:

```yaml
name: Build Prism IPA
on:
  workflow_dispatch:
  push:
    branches: [main, master]
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 25
    steps:
      - uses: actions/checkout@v4
      - name: Unpack project
        run: unzip -q Prism-iOS-project.zip
      - name: Build and test
        run: bash prism-ios/build-ipa.sh
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: Prism-IPA
          path: |
            prism-ios/build/Prism-unsigned.ipa
            prism-ios/build/simulator-launch.png
          if-no-files-found: warn
```

## Privacy

Pairing keys are stored in Keychain; TV names, IP/MAC addresses and scenes in local UserDefaults. Keys are omitted from diagnostics. No cloud service, advertising or analytics. ATS exceptions permit the B9's local plaintext WebSocket; connection code restricts destinations to private IPv4 addresses.

## Protocol and preset references

- https://github.com/JPersson77/LGTVCompanion
- https://github.com/chros73/bscpylgtv
- https://github.com/supersaiyanmode/PyWebOSTV
- https://www.rtings.com/tv/reviews/lg/b9-oled/settings
- https://www.lg.com/us/support/help-library/lg-tv-how-to-enable-the-hgig-setting--20153301892284
- https://www.playstation.com/cs-cz/support/hardware/ps5-enable-adjust-hdr/
- https://blog.playstation.com/2020/11/09/ps5-the-ultimate-faq/
