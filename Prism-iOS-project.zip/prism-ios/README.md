# Prism TV 2.5.0 · build 10

Native SwiftUI LG webOS remote for iOS 17+. English UI, charcoal/lime colours, native Liquid Glass on iOS 26+ and material/Reduce Transparency fallbacks.

## Important: update the workflow too

The old workflow may upload a screenshot-only artifact named IPA after a failed build. Replacing the source ZIP alone does not replace that workflow.

For the ZIP-based repository:

1. Download this source ZIP to Files. Keep its exact name: `Prism-iOS-project.zip`.
2. Replace the ZIP at the root of your GitHub repository.
3. Extract a local copy in Files. Open the visible `BUILD_WORKFLOW.yml` inside it and copy its contents into GitHub's `.github/workflows/build.yml`. Use one active Prism build workflow; replace the previous one rather than leaving both active.
4. Commit both changes, then open Actions → Build Prism IPA.
5. Wait for a green run. Download **Prism-2.5.0-build-10-IPA**, not **Prism-build-diagnostics**.
6. Extract the downloaded artifact ZIP. Import **Prism-unsigned.ipa** into your signing/sideload tool. Do not import the source ZIP or GitHub's wrapper ZIP.
7. `RELEASE.txt` inside the artifact identifies the version, commit and IPA SHA-256. This is an unsigned IPA and needs signing before installation.

The root `.github/workflows/build.yml` in this archive is the same workflow as the visible copy. If you maintain extracted source instead, use `prism-ios/.github/workflows/build-ipa.yml` and put the contents of `prism-ios` at your repository root. Do not mix those two layouts.

## Layout

Display Settings follows the supplied reference structure: video input and picture mode at the top, grouped inline sliders and choices, a fixed bottom row of Picture/Gaming/Advanced/All categories and a floating search/preferences/refresh bar. Back returns to Remote. The native main tab bar is hidden on this dedicated settings screen to avoid two competing navigation bars.

Info buttons open native help sheets with What it does, update behaviour and timestamp/source details. Setting cards use individually separated glass surfaces. Unknown sliders remain visible and editable, with no fabricated current number. `READ` means a received snapshot, `SET` a requested value and `SAVED` a restored local choice; none means an instant subscription.

## Settings correctness

- Numeric values are JSON numbers; enum values remain strings. Invalid ranges, unknown keys and invalid enum choices are rejected.
- No background picture polling or read-after-every-write by default. Manual Refresh reads displayed settings; optional polling remains opt-in. Initial pairing reads core settings. Selecting a manual signal reads picture mode; scene mode confirmation is a bounded safety read.
- Signal context is explicitly manual: choose SDR, HDR10 or Dolby Vision in the search bar's preferences menu. Unknown is the honest default. Signal is not automatically detected from video frames.
- Saved selections use TV + input/app + chosen signal + picture mode. Unknown startup contexts do not restore an arbitrary previous input. Legacy per-input caches remain retained but are not automatically reused in the new context model.
- Input changes clear old readings and lock picture edits until the requested input/app is confirmed. Old foreground responses cannot release that lock. An unconfirmed switch times out with an error and unknown input context.
- Known signal restrictions are explained next to controls. Picture-mode choices are filtered by chosen signal. This is a conservative semantic filter, not a fully verified firmware capability database.
- Network/time-out failures do not trigger duplicate compatibility writes. The alert-based Luna fallback is restricted to recognized unsupported/permission failures. Alert closure is labelled unverified; it does not prove physical application.
- Scenes send the mode first and require a matching TV mode response before sending remaining settings. If that response is unavailable or different, the scene stops with an explicit error. This intentionally does not silently apply remaining values to an unconfirmed mode. Scene signal context is saved; legacy scenes remain identified as unknown.

## Connection and everyday controls

Saved TVs, direct pairing with Keychain keys, D-pad/pointer, volume/mute, playback, channels, text input, apps/HDMI inputs and B9 starting presets remain available. App favourites persist locally; app icons are loaded only when provided as HTTP(S) URLs on the selected TV itself.

Discovery checks ports 3000 and 3001 on the local subnet capped to /24. WS results must return a webOS TV hello. A device on port 3001 is only a **secure candidate** until pairing verifies it; it is not assumed to be an LG TV. Some networks still require manual IP entry.

TV editing now validates IP/MAC and allows WS 3000 or WSS 3001. TLS uses system trust or an explicitly approved SHA-256 certificate pin for that host. Unapproved/changed certificates are rejected pending user review, and secure navigation sockets cannot silently downgrade to WS. This path needs native/TV testing.

Foreground return checks connection health without refreshing all picture settings. Wake-on-LAN remains unicast; delivery depends on the router, ARP and TV standby settings. Invalid MACs and failed/timed-out sends are reported. A sent packet is not proof the TV woke.

Diagnostics include timestamps, model/firmware when reported, transport/context and a share action. Export masks IPv4 addresses. Pairing keys and text submissions are not added to diagnostics.

## Build and validation

On a Mac with Xcode 26+: `cd prism-ios && bash build-ipa.sh`.

The build runs source/configuration checks, archive regression tests, Swift parsing, protocol/model tests, simulator build/launch and a Release device build. It checks the app bundle and then validates the IPA's CRC, expected version, bundle ID, compiled assets, Mach-O executable and executable permissions. IPA and diagnostics are uploaded separately; a failed build cannot publish the install artifact through the supplied workflow.

A Debug-only no-network fixture creates `simulator-picture-preview.png` in diagnostics. This screenshot is a layout fixture, not a real TV reading. Release builds exclude the fixture. The normal simulator launch screenshot is separate.

Locally verified here: Python archive tests, shell syntax, source/project/version/icon checks, balanced Swift delimiters, YAML parsing and source ZIP integrity. This environment has no Swift/Xcode, iPhone or TV, so native compilation, new Swift test execution, screenshots, touch layout, WSS handshake and physical B9 behaviour remain unverified until CI/device testing.

## Scope boundaries

This release does not claim OLED Control feature parity. SSH/root transport, TPC/GSR/service controls, automatic HDR/DV detection, LUT calibration and system App Intents/macros are not implemented. Do not infer B9 support from a newer TV's screenshot. Additional advanced controls require a verified backend on the specific B9 firmware.
