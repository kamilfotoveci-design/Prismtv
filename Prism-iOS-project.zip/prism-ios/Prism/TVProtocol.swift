import Foundation

enum TVProtocol {
    static func isLocalIP(_ host:String)->Bool {
        let parts=host.split(separator:".",omittingEmptySubsequences:false)
        guard parts.count==4,parts.allSatisfy({!$0.isEmpty && $0.allSatisfy{$0.isASCII && $0.isNumber} && ($0.count==1 || $0.first != "0")}) else{return false}
        let n=parts.compactMap{Int($0)}
        guard n.count==4,n.allSatisfy({(0...255).contains($0)}) else{return false}
        return n[0]==10 || (n[0]==192 && n[1]==168) || (n[0]==172 && (16...31).contains(n[1])) || (n[0]==169 && n[1]==254)
    }
    static func ipNumber(_ ip:String)->UInt32? {
        let parts=ip.split(separator:".",omittingEmptySubsequences:false)
        guard parts.count==4 else{return nil}
        let bytes=parts.compactMap{UInt8($0)}
        guard bytes.count==4 else{return nil}
        return bytes.reduce(UInt32(0)){($0 << 8) | UInt32($1)}
    }
    static func ipString(_ number:UInt32)->String {
        [24,16,8,0].map{String((number >> $0) & 255)}.joined(separator:".")
    }
    static func scanHosts(ip:String,mask:String)->[String] {
        guard isLocalIP(ip),let address=ipNumber(ip),let maskValue=ipNumber(mask) else{return []}
        // Require a contiguous mask, search only the phone's network, cap large LANs to its /24.
        let inverse = ~maskValue
        guard (inverse & (inverse &+ 1)) == 0,maskValue != 0 else{return []}
        let effective=max(maskValue,UInt32(0xffffff00))
        let network=address & effective,broadcast=network | ~effective
        guard broadcast>network+1 else{return []}
        return ((network+1)..<broadcast).filter{$0 != address}.map{ipString($0)}
    }
    static func webOSHelloName(_ data:Data)->String? {
        guard let object=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any],object["type"] as? String=="hello",let payload=object["payload"] as? [String:Any],(payload["deviceOS"] as? String)?.lowercased()=="webos",(payload["deviceType"] as? String)?.lowercased()=="tv" else{return nil}
        return "LG webOS TV"
    }
    static func wakePacket(_ mac:String)->Data? {
        let clean=mac.replacingOccurrences(of:":",with:"").replacingOccurrences(of:"-",with:"")
        guard clean.count==12,clean.allSatisfy({$0.isASCII && $0.isHexDigit}) else{return nil}
        var bytes:[UInt8]=[]
        for i in stride(from:0,to:12,by:2){let a=clean.index(clean.startIndex,offsetBy:i),b=clean.index(a,offsetBy:2);guard let v=UInt8(clean[a..<b],radix:16) else{return nil};bytes.append(v)}
        var data=Data(repeating:0xff,count:6)
        for _ in 0..<16{data.append(contentsOf:bytes)}
        return data
    }
    static func closeAlertID(_ id:String)->String {
        id.replacingOccurrences(of:"com.webos.service.apiadapter.pub-",with:"com.webos.service.apiadapter-")
    }
    static func button(_ name:String)->String {"type:button\nname:\(name)\n\n"}
    static func request(id:String,uri:String,payload:[String:Any])->[String:Any] {
        ["id":id,"type":"request","uri":"ssap://"+uri,"payload":payload]
    }
}
