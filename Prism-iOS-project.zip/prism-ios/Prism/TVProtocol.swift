import Foundation
import CoreFoundation

enum TVProtocol {
    static func inputIdentity(_ value:String)->String {
        value.lowercased().replacingOccurrences(of:"com.webos.app.",with:"").filter{$0.isLetter || $0.isNumber}
    }
    static func shouldUseCompatibilityFallback(_ error:Error)->Bool {
        guard let failure=error as? TVFailure else{return false}
        let message=failure.message.lowercased()
        if ["invalid", "out of range", "bad parameter"].contains(where:{message.contains($0)}) {return false}
        if let code=failure.code,["401","403","404"].contains(code) {return true}
        return ["401","403","404","not permitted","permission denied","insufficient permission","not supported","not found","no such service","unknown method","access denied"].contains{message.contains($0)} || (failure.rejectedByTV && message=="the tv rejected the request.")
    }
    static func rejection(_ object:[String:Any])->TVFailure {
        let payload=object["payload"] as? [String:Any] ?? [:]
        let nested=(payload["error"] as? [String:Any]) ?? (object["error"] as? [String:Any]) ?? [:]
        let text=[object["error"],payload["errorText"],payload["error"],payload["message"],nested["message"],nested["errorText"]].compactMap{$0 as? String}.first{!$0.isEmpty} ?? "The TV rejected the request."
        let code=[payload["errorCode"],object["errorCode"],nested["code"]].compactMap{value -> String? in
            if let text=value as? String {return text};if let number=value as? NSNumber {return number.stringValue};return nil
        }.first
        return TVFailure(message:code.map{ text.contains($0) ? text : "\($0): \(text)" } ?? text,code:code,rejectedByTV:true)
    }
    static func inputTitle(_ app:String,inputs:[TVInput],apps:[TVApp])->String {
        if let input=inputs.first(where:{inputIdentity($0.id)==inputIdentity(app)}) {return input.title}
        if let item=apps.first(where:{$0.id==app}) {return item.title}
        if app.lowercased().contains("youtube") {return "YouTube"}
        if app.lowercased().contains("netflix") {return "Netflix"}
        if app=="com.webos.app.livetv" {return "Live TV"}
        return app.isEmpty ? "Input unknown" : app.replacingOccurrences(of:"com.webos.app.",with:"")
    }
    static func blackLevelValue(_ value:String)->String {
        switch value.lowercased() {case "full":return "high";case "limited":return "low";default:return value.lowercased()}
    }
    static func pictureMatches(_ observed:String,_ requested:String)->Bool {
        if let a=Double(observed),let b=Double(requested),a.isFinite,b.isFinite {return a==b}
        return observed.caseInsensitiveCompare(requested) == .orderedSame
    }
    static func messageID(_ value:Any?)->String {
        if let value=value as? String {return value}
        if let value=value as? NSNumber {return value.stringValue}
        return ""
    }
    static func pictureValues(_ payload:[String:Any],allowed:Set<String>)->[String:String] {
        guard payload["returnValue"] as? Bool != false,let settings=payload["settings"] as? [String:Any] else{return [:]}
        var result:[String:String]=[:]
        for (key,value) in settings where allowed.contains(key) {
            if let text=value as? String,!text.isEmpty {result[key]=text}
            else if let number=value as? NSNumber,CFGetTypeID(number) != CFBooleanGetTypeID() {result[key]=number.stringValue}
        }
        return result
    }
    static func isLocalIP(_ host:String)->Bool {
        let parts=host.split(separator:".",omittingEmptySubsequences:false)
        guard parts.count==4,parts.allSatisfy({!$0.isEmpty && $0.allSatisfy{$0.isASCII && $0.isNumber} && ($0.count==1 || $0.first != "0")}) else{return false}
        let n=parts.compactMap{Int($0)}
        guard n.count==4,n.allSatisfy({(0...255).contains($0)}) else{return false}
        return n[0]==10 || (n[0]==192 && n[1]==168) || (n[0]==172 && (16...31).contains(n[1])) || (n[0]==169 && n[1]==254)
    }
    static func ipNumber(_ ip:String)->UInt32? {
        let parts=ip.split(separator:".",omittingEmptySubsequences:false)
        guard parts.count==4 else{return nil}
        let bytes=parts.compactMap{UInt8($0)}
        guard bytes.count==4 else{return nil}
        return bytes.reduce(UInt32(0)){($0 << 8) | UInt32($1)}
    }
    static func ipString(_ number:UInt32)->String {
        [24,16,8,0].map{String((number >> $0) & 255)}.joined(separator:".")
    }
    static func ipString(networkOrder value:UInt32)->String {
        ipString(UInt32(bigEndian:value))
    }
    static func scanHosts(ip:String,mask:String)->[String] {
        guard isLocalIP(ip),let address=ipNumber(ip),let maskValue=ipNumber(mask) else{return []}
        // Require a contiguous mask, search only the phone's network, cap large LANs to its /24.
        let inverse = ~maskValue
        guard (inverse & (inverse &+ 1)) == 0,maskValue != 0 else{return []}
        let effective=max(maskValue,UInt32(0xffffff00))
        let network=address & effective,broadcast=network | ~effective
        guard broadcast>network+1 else{return []}
        return ((network+1)..<broadcast).filter{$0 != address}.map{ipString($0)}
    }
    static func webOSHelloName(_ data:Data)->String? {
        guard let object=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any],object["type"] as? String=="hello",let payload=object["payload"] as? [String:Any],(payload["deviceOS"] as? String)?.lowercased()=="webos",(payload["deviceType"] as? String)?.lowercased()=="tv" else{return nil}
        for key in ["modelName","deviceModel"] {
            if let name=payload[key] as? String,!name.isEmpty {return "LG " + String(name.prefix(60))}
        }
        return "LG webOS TV"
    }
    static func wakePacket(_ mac:String)->Data? {
        let clean=mac.replacingOccurrences(of:":",with:"").replacingOccurrences(of:"-",with:"")
        guard clean.count==12,clean.allSatisfy({$0.isASCII && $0.isHexDigit}) else{return nil}
        var bytes:[UInt8]=[]
        for i in stride(from:0,to:12,by:2){let a=clean.index(clean.startIndex,offsetBy:i),b=clean.index(a,offsetBy:2);guard let v=UInt8(clean[a..<b],radix:16) else{return nil};bytes.append(v)}
        var data=Data(repeating:0xff,count:6)
        for _ in 0..<16{data.append(contentsOf:bytes)}
        return data
    }
    static func closeAlertID(_ id:String)->String {
        id.replacingOccurrences(of:"com.webos.service.apiadapter.pub-",with:"com.webos.service.apiadapter-")
    }
    static func button(_ name:String)->String {"type:button\nname:\(name)\n\n"}
    static func request(id:String,uri:String,payload:[String:Any])->[String:Any] {
        ["id":id,"type":"request","uri":"ssap://"+uri,"payload":payload]
    }
}
