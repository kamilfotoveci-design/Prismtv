import Foundation

struct TVDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var host: String
    var mac: String
    var secure: Bool? = nil
}
struct TVApp: Identifiable { var id: String; var title: String; var icon: String? = nil }
struct TVInput: Identifiable { var id: String; var title: String }
struct PictureProfile: Codable, Identifiable {
    var id = UUID()
    var name: String
    var device: UUID
    var settings: [String:String]
    var confirmed:Bool? = nil
    var confirmedKeys:Set<String>? = nil
    var sourceInput:String? = nil
    var signal:String? = nil
    var mode:String? = nil
}
struct SceneDraft:Identifiable {
    var id=UUID()
    let device:UUID
    let context:Int
    let settings:[String:String]
    let confirmedKeys:Set<String>
    let sourceInput:String
    var signal:String? = nil
    var mode:String? = nil}

enum TVSignal:String,CaseIterable,Identifiable {
    case unknown="Unknown",sdr="SDR",hdr10="HDR10",dolbyVision="Dolby Vision"
    var id:String {rawValue}
}

struct TVFailure: LocalizedError {
    let message: String
    var code: String? = nil
    var rejectedByTV = false
    var errorDescription: String? { message }
}

struct PictureSetting: Identifiable {
    var id:String {key}
    let key:String
    let title:String
    let range:ClosedRange<Double>?
    let options:[String]
    var symbol:String {
        if ["color","tint","colorTemperature","whiteBalanceColorTemperature","colorGamut","dynamicColor"].contains(key) {return "paintpalette"}
        if key.hasPrefix("truMotion") || ["realCinema","motionEyeCare","motionPro"].contains(key) {return "film"}
        return "slider.horizontal.3"
    }
    static func label(_ value:String,key:String)->String {
        if key=="blackLevel" {return ["auto":"Auto","high":"Full","full":"Full","low":"Limited","limited":"Limited"][value.lowercased()] ?? value}
        if key=="gamma" {return ["low":"1.9","medium":"2.2","high1":"2.4","high2":"BT.1886"][value] ?? value}
        return ["off":"Off","on":"On","warm1":"Warm 1","warm2":"Warm 2","cool":"Cool","auto":"Auto","medium":"Medium","low":"Low","high":"High","min":"Minimum","med":"Medium","max":"Maximum","expert1":"Expert Bright","expert2":"Expert Dark","hdrGame":"HDR Game","hdrCinema":"HDR Cinema","dolbyHdrCinema":"DV Cinema","dolbyHdrCinemaBright":"DV Cinema Home","smooth":"Smooth","clear":"Clear","user":"User","game":"Game","cinema":"Cinema","normal":"Standard","extended":"Extended","wide":"Wide","srgb":"sRGB","HGIG":"HGiG"][value] ?? value
    }
    var help:String {
        switch key {
        case "blackLevel":return "Auto follows the source range. Full is High (0–255); Limited is Low (16–235). Auto availability on the B9 depends on firmware, input type and signal. Medium is not treated as Auto."
        case "backlight":return "Controls overall OLED panel brightness. Higher values make the image brighter. Choose a comfortable level for your room; SDR, HDR10 and Dolby Vision can have different values. This is not the Black Level control."
        case "contrast":return "Adjusts the picture's bright-end contrast. Excessive values can hide highlight detail. SDR and HDR modes may use different defaults; use a matching signal before adjusting."
        case "color":return "Adjusts color intensity. This is separate from Color Gamut, which selects the range of colors the TV targets."
        case "sharpness":return "Adds edge enhancement. Higher values can look crisper but may create halos. It does not add source detail."
        case "brightness":return "Picture black level, 0–100. This is separate from HDMI Auto/Full/Limited video range."
        case "pictureMode":return "Choose a mode for the current signal. HDR and Dolby Vision modes require matching content."
        case "hdrDynamicToneMapping":return "For HDR10. HGiG is intended for gaming and depends on firmware and the active picture mode."
        case "whiteBalanceColorTemperature":return "Warm 1 and Warm 2 are white-balance presets, not measured Kelvin temperatures."
        case "energySaving":return "Energy saving can change panel brightness. The choice applies to the current TV context."
        default:return "Release the slider to send a value. Tap a choice to send it directly. Last received is a timestamped snapshot; requested or saved choices are not confirmed TV state. Availability depends on firmware and picture mode."
        }
    }
    func choices(signal:TVSignal)->[String] {
        guard key=="pictureMode",signal != .unknown else{return options}
        switch signal {
        case .sdr:return options.filter{!$0.hasPrefix("hdr") && !$0.hasPrefix("dolby")}
        case .hdr10:return options.filter{$0.hasPrefix("hdr")}
        case .dolbyVision:return options.filter{$0.hasPrefix("dolby")}
        case .unknown:return options
        }
    }
    static func payload(_ settings:[String:String]) throws -> [String:Any] {
        var result:[String:Any]=[:]
        for (key,value) in settings {
            guard let setting=all.first(where:{$0.key==key}) else {throw TVFailure(message:"Unknown picture setting: \(key)")}
            if let range=setting.range {
                guard let number=Double(value),number.isFinite,range.contains(number),number.rounded()==number else {throw TVFailure(message:"Invalid value for \(setting.title)")}
                result[key]=Int(number)
            } else {
                let normalized=key=="blackLevel" ? TVProtocol.blackLevelValue(value) : value
                guard setting.options.contains(normalized) else {throw TVFailure(message:"Invalid choice for \(setting.title)")}
                result[key]=normalized
            }
        }
        return result
    }
    static let all:[PictureSetting]=[
        .init(key:"backlight",title:"OLED pixel brightness",range:0...100,options:[]),
        .init(key:"contrast",title:"Contrast",range:0...100,options:[]),
        .init(key:"brightness",title:"Black level",range:0...100,options:[]),
        .init(key:"color",title:"Color depth",range:0...100,options:[]),
        .init(key:"tint",title:"Tint",range:-50...50,options:[]),
        .init(key:"colorTemperature",title:"Color temperature",range:-50...50,options:[]),
        .init(key:"dynamicColor",title:"Color adjustment",range:nil,options:["off","low","medium","high"]),
        .init(key:"noiseReduction",title:"Noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"mpegNoiseReduction",title:"MPEG noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"sharpness",title:"Sharpness",range:0...50,options:[]),
        .init(key:"peakBrightness",title:"Peak brightness",range:nil,options:["off","low","medium","high"]),
        .init(key:"hdrDynamicToneMapping",title:"HDR tone mapping",range:nil,options:["off","on","HGIG"]),
        .init(key:"whiteBalanceColorTemperature",title:"White balance",range:nil,options:["cool","medium","warm1","warm2"]),
        .init(key:"blackLevel",title:"HDMI video range",range:nil,options:["auto","high","low"]),
        .init(key:"colorGamut",title:"Color gamut",range:nil,options:["auto","extended","wide","srgb"]),
        .init(key:"superResolution",title:"Super resolution",range:nil,options:["off","low","medium","high"]),
        .init(key:"dynamicContrast",title:"Dynamic contrast",range:nil,options:["off","low","medium","high"]),
        .init(key:"smoothGradation",title:"Smooth gradation",range:nil,options:["off","low","medium","high"]),
        .init(key:"gamma",title:"Gamma",range:nil,options:["low","medium","high1","high2"]),
        .init(key:"truMotionMode",title:"TruMotion",range:nil,options:["off","smooth","clear","user"]),
        .init(key:"truMotionJudder",title:"De-judder",range:0...10,options:[]),
        .init(key:"truMotionBlur",title:"De-blur",range:0...10,options:[]),
        .init(key:"realCinema",title:"Real Cinema",range:nil,options:["off","on"]),
        .init(key:"motionEyeCare",title:"Motion eye care",range:nil,options:["off","on"]),
        .init(key:"motionPro",title:"OLED Motion / BFI",range:nil,options:["off","on"]),
        .init(key:"energySaving",title:"Energy saving",range:nil,options:["off","auto","min","med","max"]),
        .init(key:"eyeComfortMode",title:"Eye comfort mode",range:nil,options:["off","on"]),
        .init(key:"pictureMode",title:"Picture mode",range:nil,options:["cinema","expert1","expert2","game","normal","hdrCinema","hdrGame","dolbyHdrCinema","dolbyHdrCinemaBright","dolbyHdrGame"])
    ]
}


struct KeyboardDraft {
    var text=""
    private(set) var activeID:UUID?
    private(set) var error:String?
    private var submitted=""
    init(){}
    var sending:Bool {activeID != nil}
    mutating func begin()->(id:UUID,text:String)? {
        guard !sending,!text.isEmpty else{return nil}
        let id=UUID();activeID=id;submitted=text;error=nil
        return(id,text)
    }
    mutating func finish(id:UUID,success:Bool){
        guard activeID==id else{return}
        activeID=nil
        if success {if text==submitted{text=""};error=nil}
        else {error="Text could not be sent. Try again."}
    }
    mutating func disconnected(){
        guard sending else{return}
        activeID=nil;error="Connection lost. Your text has been kept."
    }
}

// Sound keys/ranges from the 2019 C9 sound-category dump. B9 firmware support
// remains per-setting and must not be inferred from a neighbouring model.
struct SoundSetting:Identifiable {
    let key:String
    let title:String
    let group:String
    let range:ClosedRange<Double>?
    let options:[String]
    var id:String {key}
    var help:String {
        switch key {
        case "soundOutput":return "Selects the TV's audio route. HDMI ARC/eARC sends audio to your soundbar or receiver. A successful request is not a confirmed route until read back."
        case "soundOutputDigital":return "PCM, Auto or Pass Through for digital output. Actual codecs depend on the source, TV and connected receiver. This does not report the currently decoded codec."
        case "eArcSupport":return "Requests enhanced Audio Return Channel. It requires a compatible port, cable, receiver and TV firmware. On/off is a setting, not proof of an active eARC link."
        case "supportATMOS":return "TV Dolby Atmos processing setting. It does not create Atmos in a source or confirm that your soundbar is decoding Atmos."
        case "userEqualizerValues":return "Five TV equalizer bands, -10 to +10 in the TV's own units. The complete five-band array is sent together. These are TV speaker settings, not the TCL soundbar's internal EQ."
        case "avSyncSpdif","avSyncSpeaker":return "Audio/video delay in TV steps, not milliseconds. Increasing delay cannot repair every source/receiver timing mismatch. Bypass and active output can affect whether this applies."
        case "digitalAudioPriority":return "Audio format priority for broadcasts, not the HDMI bitstream/PCM setting."
        default:return "TV sound-category setting. Availability and audible effect depend on model, firmware, output and signal. TV processing and EQ may not affect an external soundbar in pass-through. Read values are snapshots; requested choices are not confirmed hardware state."
        }
    }
    static func label(_ value:String)->String {
        ["tv_speaker":"TV speakers","external_arc":"HDMI ARC / eARC","external_optical":"Optical","tv_external_speaker":"TV + external speakers","tv_speaker_headphone":"TV + headphones","tv_speakerbar":"TV + soundbar","bt_soundbar":"LG Bluetooth soundbar","bt_audio":"Bluetooth","wisa_speaker":"WiSA","builtin_soundbar":"Built-in soundbar","lineout":"Line out","headphone":"Headphones","tv_speakerbar_headphone":"TV + soundbar + headphones","pcm":"PCM","auto":"Auto","passThrough":"Pass Through","bitstream":"Bitstream","standard":"Standard","movie":"Cinema","asc":"Adaptive sound","bass":"Bass","on":"On","off":"Off","level1":"Level 1","level2":"Level 2","level3":"Level 3","normal":"Normal","stand":"Stand","wall_mount":"Wall mounted","mpeg":"MPEG","dolbyDigital":"Dolby Digital","dobyDigitalPlus":"Dolby Digital Plus","heAaC":"HE-AAC","dra":"DRA"][value] ?? value
    }
    static func bands(_ value:String)->[Int]? {
        guard let data=value.data(using:.utf8),let values=try? JSONDecoder().decode([Int].self,from:data),values.count==5,values.allSatisfy({(-10...10).contains($0)}) else{return nil}
        return values
    }
    static func payload(_ settings:[String:String]) throws -> [String:Any] {
        var encoded:[String:Any]=[:]
        for (key,value) in settings {
            guard let setting=all.first(where:{$0.key==key}) else{throw TVFailure(message:"Unknown sound setting")}
            if key=="userEqualizerValues" {
                guard let values=bands(value) else{throw TVFailure(message:"Equalizer needs five whole values from -10 to +10")}
                encoded[key]=values
            }else if let range=setting.range {
                guard let number=Double(value),number.isFinite,number.rounded()==number,range.contains(number) else{throw TVFailure(message:"Invalid value for \(setting.title)")}
                encoded[key]=Int(number)
            }else{
                guard setting.options.contains(value) else{throw TVFailure(message:"Invalid choice for \(setting.title)")}
                encoded[key]=value
            }
        }
        return encoded
    }
    static let all:[SoundSetting]=[
        .init(key:"soundOutput",title:"Sound output",group:"Output",range:nil,options:["tv_speaker","external_arc","external_optical","bt_audio","headphone","lineout","tv_external_speaker","tv_speaker_headphone","tv_speakerbar","bt_soundbar","wisa_speaker","builtin_soundbar","tv_speakerbar_headphone"]),
        .init(key:"soundOutputDigital",title:"Digital sound output",group:"Output",range:nil,options:["pcm","auto","passThrough"]),
        .init(key:"eArcSupport",title:"eARC support",group:"Output",range:nil,options:["off","on"]),
        .init(key:"hdmiArcMode",title:"HDMI ARC",group:"Output",range:nil,options:["off","on"]),
        .init(key:"inputAudioFormatHDMI1",title:"HDMI 1 audio format",group:"HDMI",range:nil,options:["bitstream","pcm"]),
        .init(key:"inputAudioFormatHDMI2",title:"HDMI 2 audio format",group:"HDMI",range:nil,options:["bitstream","pcm"]),
        .init(key:"inputAudioFormatHDMI3",title:"HDMI 3 audio format",group:"HDMI",range:nil,options:["bitstream","pcm"]),
        .init(key:"inputAudioFormatHDMI4",title:"HDMI 4 audio format",group:"HDMI",range:nil,options:["bitstream","pcm"]),
        .init(key:"soundMode",title:"Sound mode",group:"Processing",range:nil,options:["standard","movie","asc","bass"]),
        .init(key:"aiSound",title:"AI Sound",group:"Processing",range:nil,options:["off","on"]),
        .init(key:"smartSoundMode",title:"Smart sound mode",group:"Processing",range:nil,options:["off","on"]),
        .init(key:"clearVoice",title:"Clear Voice",group:"Processing",range:nil,options:["off","level1","level2","level3"]),
        .init(key:"autoVolume",title:"Auto volume",group:"Processing",range:nil,options:["off","on"]),
        .init(key:"virtualSurround",title:"Virtual surround",group:"Processing",range:nil,options:["off","on"]),
        .init(key:"supportATMOS",title:"Dolby Atmos (TV)",group:"Processing",range:nil,options:["off","on"]),
        .init(key:"audioBalance",title:"Speaker balance",group:"Processing",range:-50...50,options:[]),
        .init(key:"soundOptimizer",title:"Speaker placement",group:"Processing",range:nil,options:["normal","stand","wall_mount"]),
        .init(key:"avSync",title:"AV sync adjustment",group:"Sync",range:nil,options:["off","on"]),
        .init(key:"avSyncBypass",title:"AV sync bypass",group:"Sync",range:nil,options:["off","on"]),
        .init(key:"avSyncBypassInput",title:"Input sync bypass",group:"Sync",range:nil,options:["off","on"]),
        .init(key:"avSyncSpdif",title:"Digital output delay (steps)",group:"Sync",range:0...15,options:[]),
        .init(key:"avSyncSpeaker",title:"TV speaker delay (steps)",group:"Sync",range:0...15,options:[]),
        .init(key:"userEqualizer",title:"TV equalizer",group:"Equalizer",range:nil,options:["off","on"]),
        .init(key:"userEqualizerValues",title:"Five-band equalizer",group:"Equalizer",range:nil,options:[]),
        .init(key:"digitalAudioPriority",title:"Broadcast audio priority",group:"Advanced",range:nil,options:["auto","mpeg","dolbyDigital","dobyDigitalPlus","heAaC","dra"]),
        .init(key:"lgSoundSync",title:"LG Sound Sync",group:"Advanced",range:nil,options:["off","on"]),
        .init(key:"audioDescription",title:"Audio description",group:"Advanced",range:nil,options:["off","on"]),
        .init(key:"audioDescriptionVolume",title:"Audio description level",group:"Advanced",range:-15...15,options:[]),
        .init(key:"tvPowerSound",title:"TV power sound",group:"Advanced",range:nil,options:["off","on"])
    ]
}
