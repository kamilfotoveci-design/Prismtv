import Foundation

struct TVDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var host: String
    var mac: String
}
struct TVApp: Identifiable { var id: String; var title: String }
struct TVInput: Identifiable { var id: String; var title: String }
struct PictureProfile: Codable, Identifiable {
    var id = UUID()
    var name: String
    var device: UUID
    var settings: [String:String]
    var confirmed:Bool? = nil
    var confirmedKeys:Set<String>? = nil
    var sourceInput:String? = nil
}
struct SceneDraft:Identifiable {
    var id=UUID()
    let device:UUID
    let context:Int
    let settings:[String:String]
    let confirmedKeys:Set<String>
    let sourceInput:String
}

struct TVFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct PictureSetting: Identifiable {
    var id:String {key}
    let key:String
    let title:String
    let range:ClosedRange<Double>?
    let options:[String]
    var symbol:String {
        if ["color","tint","colorTemperature","whiteBalanceColorTemperature","colorGamut","dynamicColor"].contains(key) {return "paintpalette"}
        if key.hasPrefix("truMotion") || ["realCinema","motionEyeCare","motionPro"].contains(key) {return "film"}
        return "slider.horizontal.3"
    }
    static func label(_ value:String,key:String)->String {
        if key=="blackLevel" {return ["auto":"Auto","high":"Full","full":"Full","low":"Limited","limited":"Limited"][value.lowercased()] ?? value}
        if key=="gamma" {return ["low":"1.9","medium":"2.2","high1":"2.4","high2":"BT.1886"][value] ?? value}
        return ["off":"Off","on":"On","warm1":"Warm 1","warm2":"Warm 2","cool":"Cool","auto":"Auto","medium":"Medium","low":"Low","high":"High","min":"Minimum","med":"Medium","max":"Maximum","expert1":"Expert Bright","expert2":"Expert Dark","hdrGame":"HDR Game","hdrCinema":"HDR Cinema","dolbyHdrCinema":"DV Cinema","dolbyHdrCinemaBright":"DV Cinema Home","smooth":"Smooth","clear":"Clear","user":"User","game":"Game","cinema":"Cinema","normal":"Standard","extended":"Extended","wide":"Wide","srgb":"sRGB","HGIG":"HGiG"][value] ?? value
    }
    var help:String {
        switch key {
        case "blackLevel":return "Auto follows the source range. Full is High (0–255); Limited is Low (16–235). Auto availability on the B9 depends on firmware, input type and signal. Medium is not treated as Auto."
        case "brightness":return "Picture black level, 0–100. This is separate from HDMI Auto/Full/Limited video range."
        case "pictureMode":return "Choose a mode for the current signal. HDR and Dolby Vision modes require matching content."
        case "hdrDynamicToneMapping":return "For HDR10. HGiG is intended for gaming and depends on firmware and the active picture mode."
        case "whiteBalanceColorTemperature":return "Warm 1 and Warm 2 are white-balance presets, not measured Kelvin temperatures."
        case "energySaving":return "Energy saving can change panel brightness. The choice applies to the current TV context."
        default:return "Release the slider to send a value. Tap a choice to send it directly. TV means a received value; a selected or saved choice is not a confirmed TV state. Availability depends on firmware and picture mode."
        }
    }
    static let all:[PictureSetting]=[
        .init(key:"backlight",title:"OLED pixel brightness",range:0...100,options:[]),
        .init(key:"contrast",title:"Contrast",range:0...100,options:[]),
        .init(key:"brightness",title:"Black level",range:0...100,options:[]),
        .init(key:"color",title:"Color depth",range:0...100,options:[]),
        .init(key:"tint",title:"Tint",range:-50...50,options:[]),
        .init(key:"colorTemperature",title:"Color temperature",range:-50...50,options:[]),
        .init(key:"dynamicColor",title:"Color adjustment",range:nil,options:["off","low","medium","high"]),
        .init(key:"noiseReduction",title:"Noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"mpegNoiseReduction",title:"MPEG noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"sharpness",title:"Sharpness",range:0...50,options:[]),
        .init(key:"peakBrightness",title:"Peak brightness",range:nil,options:["off","low","medium","high"]),
        .init(key:"hdrDynamicToneMapping",title:"HDR tone mapping",range:nil,options:["off","on","HGIG"]),
        .init(key:"whiteBalanceColorTemperature",title:"White balance",range:nil,options:["cool","medium","warm1","warm2"]),
        .init(key:"blackLevel",title:"HDMI video range",range:nil,options:["auto","high","low"]),
        .init(key:"colorGamut",title:"Color gamut",range:nil,options:["auto","extended","wide","srgb"]),
        .init(key:"superResolution",title:"Super resolution",range:nil,options:["off","low","medium","high"]),
        .init(key:"dynamicContrast",title:"Dynamic contrast",range:nil,options:["off","low","medium","high"]),
        .init(key:"smoothGradation",title:"Smooth gradation",range:nil,options:["off","low","medium","high"]),
        .init(key:"gamma",title:"Gamma",range:nil,options:["low","medium","high1","high2"]),
        .init(key:"truMotionMode",title:"TruMotion",range:nil,options:["off","smooth","clear","user"]),
        .init(key:"truMotionJudder",title:"De-judder",range:0...10,options:[]),
        .init(key:"truMotionBlur",title:"De-blur",range:0...10,options:[]),
        .init(key:"realCinema",title:"Real Cinema",range:nil,options:["off","on"]),
        .init(key:"motionEyeCare",title:"Motion eye care",range:nil,options:["off","on"]),
        .init(key:"motionPro",title:"OLED Motion / BFI",range:nil,options:["off","on"]),
        .init(key:"energySaving",title:"Energy saving",range:nil,options:["off","auto","min","med","max"]),
        .init(key:"eyeComfortMode",title:"Eye comfort mode",range:nil,options:["off","on"]),
        .init(key:"pictureMode",title:"Picture mode",range:nil,options:["cinema","expert1","expert2","game","normal","hdrCinema","hdrGame","dolbyHdrCinema","dolbyHdrCinemaBright","dolbyHdrGame"])
    ]
}


struct KeyboardDraft {
    var text=""
    private(set) var activeID:UUID?
    private(set) var error:String?
    private var submitted=""
    init(){}
    var sending:Bool {activeID != nil}
    mutating func begin()->(id:UUID,text:String)? {
        guard !sending,!text.isEmpty else{return nil}
        let id=UUID();activeID=id;submitted=text;error=nil
        return(id,text)
    }
    mutating func finish(id:UUID,success:Bool){
        guard activeID==id else{return}
        activeID=nil
        if success {if text==submitted{text=""};error=nil}
        else {error="Text could not be sent. Try again."}
    }
    mutating func disconnected(){
        guard sending else{return}
        activeID=nil;error="Connection lost. Your text has been kept."
    }
}
