import Foundation

struct TVDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var host: String
    var mac: String
}
struct TVApp: Identifiable { var id: String; var title: String }
struct TVInput: Identifiable { var id: String; var title: String }
struct PictureProfile: Codable, Identifiable {
    var id = UUID()
    var name: String
    var device: UUID
    var settings: [String:String]
    var confirmed:Bool? = nil
    var confirmedKeys:Set<String>? = nil
    var sourceInput:String? = nil
}
struct SceneDraft:Identifiable {
    var id=UUID()
    let device:UUID
    let context:Int
    let settings:[String:String]
    let confirmedKeys:Set<String>
    let sourceInput:String
}

struct TVFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct PictureSetting: Identifiable {
    var id:String {key}
    let key:String
    let title:String
    let range:ClosedRange<Double>?
    let options:[String]
    var symbol:String {
        if ["color","tint","colorTemperature","whiteBalanceColorTemperature","colorGamut","dynamicColor"].contains(key) {return "paintpalette"}
        if key.hasPrefix("truMotion") || ["realCinema","motionEyeCare","motionPro"].contains(key) {return "film"}
        return "slider.horizontal.3"
    }
    static func label(_ value:String,key:String)->String {
        if key=="blackLevel" {return ["auto":"Auto","high":"Full","full":"Full","low":"Limited","limited":"Limited"][value.lowercased()] ?? value}
        if key=="gamma" {return ["low":"1.9","medium":"2.2","high1":"2.4","high2":"BT.1886"][value] ?? value}
        return ["off":"Vyp","on":"Zap","warm1":"Warm 1","warm2":"Warm 2","cool":"Studená","auto":"Auto","medium":"Stredné","low":"Nízke","high":"Vysoké","min":"Minimum","med":"Stredné","max":"Maximum","expert1":"Expert svetlá","expert2":"Expert tmavá","hdrGame":"HDR hra","hdrCinema":"HDR kino","dolbyHdrCinema":"DV kino","dolbyHdrCinemaBright":"DV kino doma","smooth":"Plynulý","clear":"Jasný","user":"Vlastné","game":"Hra","cinema":"Kino","normal":"Štandard","extended":"Rozšírený","wide":"Široký","srgb":"sRGB","HGIG":"HGiG"][value] ?? value
    }
    var help:String {
        switch key {
        case "blackLevel":return "Auto sleduje rozsah zdroja. Full zodpovedá High (0–255), Limited zodpovedá Low (16–235). Dostupnosť Auto na B9 závisí aj od typu HDMI vstupu a signálu. Medium nie je automaticky Auto."
        case "brightness":return "Úroveň čiernej obrazu 0–100. Toto nie je HDMI video rozsah Auto/Full/Limited."
        case "pictureMode":return "Vyber režim pre aktuálny signál. HDR a Dolby Vision režimy vyžadujú zodpovedajúci obsah."
        case "hdrDynamicToneMapping":return "Pre HDR10. HGiG je určené pre hranie a závisí od firmvéru aj aktívneho režimu."
        case "whiteBalanceColorTemperature":return "Warm 1 a Warm 2 sú predvoľby bielej; nejde o meranú teplotu v kelvinoch."
        case "energySaving":return "Úspora energie môže meniť jas panela. Voľba sa odošle pre aktuálny kontext TV."
        default:return "Posuvník odošle hodnotu po pustení. Tlačidlá volieb sa odosielajú priamo. Hodnota označená TV pochádza z čítania; požiadavka nie je potvrdený stav. Dostupnosť závisí od firmvéru a režimu."
        }
    }
    static let all:[PictureSetting]=[
        .init(key:"backlight",title:"Jas OLED panela",range:0...100,options:[]),
        .init(key:"contrast",title:"Kontrast",range:0...100,options:[]),
        .init(key:"brightness",title:"Úroveň čiernej",range:0...100,options:[]),
        .init(key:"color",title:"Sýtosť farieb",range:0...100,options:[]),
        .init(key:"tint",title:"Odtieň",range:-50...50,options:[]),
        .init(key:"colorTemperature",title:"Teplota farieb",range:-50...50,options:[]),
        .init(key:"dynamicColor",title:"Úprava farieb",range:nil,options:["off","low","medium","high"]),
        .init(key:"noiseReduction",title:"Redukcia šumu",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"mpegNoiseReduction",title:"Redukcia MPEG šumu",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"sharpness",title:"Ostrosť",range:0...50,options:[]),
        .init(key:"peakBrightness",title:"Špičkový jas",range:nil,options:["off","low","medium","high"]),
        .init(key:"hdrDynamicToneMapping",title:"Mapovanie HDR tónov",range:nil,options:["off","on","HGIG"]),
        .init(key:"whiteBalanceColorTemperature",title:"Vyváženie bielej",range:nil,options:["cool","medium","warm1","warm2"]),
        .init(key:"blackLevel",title:"Rozsah HDMI",range:nil,options:["auto","high","low"]),
        .init(key:"colorGamut",title:"Farebný gamut",range:nil,options:["auto","extended","wide","srgb"]),
        .init(key:"superResolution",title:"Super rozlíšenie",range:nil,options:["off","low","medium","high"]),
        .init(key:"dynamicContrast",title:"Dynamický kontrast",range:nil,options:["off","low","medium","high"]),
        .init(key:"smoothGradation",title:"Plynulé prechody",range:nil,options:["off","low","medium","high"]),
        .init(key:"gamma",title:"Gamma",range:nil,options:["low","medium","high1","high2"]),
        .init(key:"truMotionMode",title:"TruMotion",range:nil,options:["off","smooth","clear","user"]),
        .init(key:"truMotionJudder",title:"Vyhladenie trhania",range:0...10,options:[]),
        .init(key:"truMotionBlur",title:"Odstránenie rozmazania",range:0...10,options:[]),
        .init(key:"realCinema",title:"Real Cinema",range:nil,options:["off","on"]),
        .init(key:"motionEyeCare",title:"Ochrana očí pri pohybe",range:nil,options:["off","on"]),
        .init(key:"motionPro",title:"OLED Motion / BFI",range:nil,options:["off","on"]),
        .init(key:"energySaving",title:"Úspora energie",range:nil,options:["off","auto","min","med","max"]),
        .init(key:"eyeComfortMode",title:"Komfort pre oči",range:nil,options:["off","on"]),
        .init(key:"pictureMode",title:"Obrazový režim",range:nil,options:["cinema","expert1","expert2","game","normal","hdrCinema","hdrGame","dolbyHdrCinema","dolbyHdrCinemaBright","dolbyHdrGame"])
    ]
}


struct KeyboardDraft {
    var text=""
    private(set) var activeID:UUID?
    private(set) var error:String?
    private var submitted=""
    init(){}
    var sending:Bool {activeID != nil}
    mutating func begin()->(id:UUID,text:String)? {
        guard !sending,!text.isEmpty else{return nil}
        let id=UUID();activeID=id;submitted=text;error=nil
        return(id,text)
    }
    mutating func finish(id:UUID,success:Bool){
        guard activeID==id else{return}
        activeID=nil
        if success {if text==submitted{text=""};error=nil}
        else {error="Text sa nepodarilo odoslať. Skús to znova."}
    }
    mutating func disconnected(){
        guard sending else{return}
        activeID=nil;error="Spojenie sa prerušilo. Text zostal zachovaný."
    }
}
