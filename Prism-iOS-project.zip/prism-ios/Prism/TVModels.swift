import Foundation

struct TVDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var host: String
    var mac: String
}
struct TVApp: Identifiable { var id: String; var title: String }
struct TVInput: Identifiable { var id: String; var title: String }
struct PictureProfile: Codable, Identifiable {
    var id = UUID()
    var name: String
    var device: UUID
    var settings: [String:String]
    var confirmed:Bool? = nil
}
struct TVFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct PictureSetting: Identifiable {
    var id:String {key}
    let key:String
    let title:String
    let range:ClosedRange<Double>?
    let options:[String]
    static let all:[PictureSetting]=[
        .init(key:"backlight",title:"OLED pixel brightness",range:0...100,options:[]),
        .init(key:"contrast",title:"Contrast",range:0...100,options:[]),
        .init(key:"brightness",title:"Brightness / black level",range:0...100,options:[]),
        .init(key:"color",title:"Colour depth",range:0...100,options:[]),
        .init(key:"tint",title:"Tint",range:-50...50,options:[]),
        .init(key:"colorTemperature",title:"Colour temperature",range:-50...50,options:[]),
        .init(key:"dynamicColor",title:"Colour adjustment",range:nil,options:["off","low","medium","high"]),
        .init(key:"noiseReduction",title:"Noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"mpegNoiseReduction",title:"MPEG noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"sharpness",title:"Sharpness",range:0...50,options:[]),
        .init(key:"peakBrightness",title:"Peak brightness",range:nil,options:["off","low","medium","high"]),
        .init(key:"hdrDynamicToneMapping",title:"HDR tone mapping",range:nil,options:["off","on","HGIG"]),
        .init(key:"whiteBalanceColorTemperature",title:"White balance",range:nil,options:["cool","medium","warm1","warm2"]),
        .init(key:"blackLevel",title:"HDMI black level",range:nil,options:["low","medium","high"]),
        .init(key:"colorGamut",title:"Colour gamut",range:nil,options:["auto","extended","wide","srgb"]),
        .init(key:"superResolution",title:"Super resolution",range:nil,options:["off","low","medium","high"]),
        .init(key:"dynamicContrast",title:"Dynamic contrast",range:nil,options:["off","low","medium","high"]),
        .init(key:"smoothGradation",title:"Smooth gradation",range:nil,options:["off","low","medium","high"]),
        .init(key:"gamma",title:"Gamma",range:nil,options:["low","medium","high1","high2"]),
        .init(key:"truMotionMode",title:"TruMotion",range:nil,options:["off","smooth","clear","user"]),
        .init(key:"truMotionJudder",title:"De-judder",range:0...10,options:[]),
        .init(key:"truMotionBlur",title:"De-blur",range:0...10,options:[]),
        .init(key:"realCinema",title:"Real cinema",range:nil,options:["off","on"]),
        .init(key:"motionEyeCare",title:"Motion eye care",range:nil,options:["off","on"]),
        .init(key:"motionPro",title:"OLED Motion / BFI",range:nil,options:["off","on"]),
        .init(key:"pictureMode",title:"Picture mode",range:nil,options:["cinema","expert1","expert2","game","normal","hdrCinema","hdrGame","dolbyHdrCinema","dolbyHdrCinemaBright","dolbyHdrGame"])
    ]
}

