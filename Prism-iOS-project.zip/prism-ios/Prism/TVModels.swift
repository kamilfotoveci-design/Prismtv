import Foundation

struct TVDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var host: String
    var mac: String
}
struct TVApp: Identifiable { var id: String; var title: String }
struct TVInput: Identifiable { var id: String; var title: String }
struct PictureProfile: Codable, Identifiable {
    var id = UUID()
    var name: String
    var device: UUID
    var settings: [String:String]
    var confirmed:Bool? = nil
}
struct TVFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct PictureSetting: Identifiable {
    var id:String {key}
    let key:String
    let title:String
    let range:ClosedRange<Double>?
    let options:[String]
    var symbol:String {
        if ["color","tint","colorTemperature","whiteBalanceColorTemperature","colorGamut","dynamicColor"].contains(key) {return "paintpalette"}
        if key.hasPrefix("truMotion") || ["realCinema","motionEyeCare","motionPro"].contains(key) {return "film"}
        return "slider.horizontal.3"
    }
    static func label(_ value:String,key:String)->String {
        if key=="blackLevel" {return ["auto":"Auto","high":"Full","full":"Full","low":"Limited","limited":"Limited"][value.lowercased()] ?? value}
        if key=="gamma" {return ["low":"1.9","medium":"2.2","high1":"2.4","high2":"BT.1886"][value] ?? value}
        return ["off":"Off","on":"On","warm1":"Warm 1","warm2":"Warm 2","cool":"Cool","auto":"Auto","medium":"Medium","low":"Low","high":"High","min":"Minimum","med":"Medium","max":"Maximum","expert1":"Expert Bright","expert2":"Expert Dark","hdrGame":"HDR Game","hdrCinema":"HDR Cinema","dolbyHdrCinema":"DV Cinema","dolbyHdrCinemaBright":"DV Cinema Home","smooth":"Smooth","clear":"Clear","user":"User","game":"Game","cinema":"Cinema"][value] ?? value
    }
    var help:String {
        switch key {
        case "blackLevel":return "Auto sleduje rozsah zdroja. Full zodpovedá High (0–255), Limited zodpovedá Low (16–235). Dostupnosť Auto na B9 závisí aj od typu HDMI vstupu a signálu. Medium nie je automaticky Auto."
        case "brightness":return "Úroveň čiernej obrazu 0–100. Toto nie je HDMI video rozsah Auto/Full/Limited."
        case "pictureMode":return "Vyber režim pre aktuálny signál. HDR a Dolby Vision režimy vyžadujú zodpovedajúci obsah."
        case "hdrDynamicToneMapping":return "Pre HDR10. HGiG je určené pre hranie a závisí od firmvéru aj aktívneho režimu."
        case "whiteBalanceColorTemperature":return "Warm 1 a Warm 2 sú predvoľby bielej; nejde o meranú teplotu v kelvinoch."
        case "energySaving":return "Úspora energie môže meniť jas panela. Voľba sa odošle pre aktuálny kontext TV."
        default:return "Posuvník odošle hodnotu po pustení. Tlačidlá volieb sa odosielajú priamo. Hodnota označená TV pochádza z čítania; požiadavka nie je potvrdený stav. Dostupnosť závisí od firmvéru a režimu."
        }
    }
    static let all:[PictureSetting]=[
        .init(key:"backlight",title:"OLED pixel brightness",range:0...100,options:[]),
        .init(key:"contrast",title:"Contrast",range:0...100,options:[]),
        .init(key:"brightness",title:"Brightness / black level",range:0...100,options:[]),
        .init(key:"color",title:"Colour depth",range:0...100,options:[]),
        .init(key:"tint",title:"Tint",range:-50...50,options:[]),
        .init(key:"colorTemperature",title:"Colour temperature",range:-50...50,options:[]),
        .init(key:"dynamicColor",title:"Colour adjustment",range:nil,options:["off","low","medium","high"]),
        .init(key:"noiseReduction",title:"Noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"mpegNoiseReduction",title:"MPEG noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"sharpness",title:"Sharpness",range:0...50,options:[]),
        .init(key:"peakBrightness",title:"Peak brightness",range:nil,options:["off","low","medium","high"]),
        .init(key:"hdrDynamicToneMapping",title:"HDR tone mapping",range:nil,options:["off","on","HGIG"]),
        .init(key:"whiteBalanceColorTemperature",title:"White balance",range:nil,options:["cool","medium","warm1","warm2"]),
        .init(key:"blackLevel",title:"HDMI black level",range:nil,options:["auto","high","low"]),
        .init(key:"colorGamut",title:"Colour gamut",range:nil,options:["auto","extended","wide","srgb"]),
        .init(key:"superResolution",title:"Super resolution",range:nil,options:["off","low","medium","high"]),
        .init(key:"dynamicContrast",title:"Dynamic contrast",range:nil,options:["off","low","medium","high"]),
        .init(key:"smoothGradation",title:"Smooth gradation",range:nil,options:["off","low","medium","high"]),
        .init(key:"gamma",title:"Gamma",range:nil,options:["low","medium","high1","high2"]),
        .init(key:"truMotionMode",title:"TruMotion",range:nil,options:["off","smooth","clear","user"]),
        .init(key:"truMotionJudder",title:"De-judder",range:0...10,options:[]),
        .init(key:"truMotionBlur",title:"De-blur",range:0...10,options:[]),
        .init(key:"realCinema",title:"Real cinema",range:nil,options:["off","on"]),
        .init(key:"motionEyeCare",title:"Motion eye care",range:nil,options:["off","on"]),
        .init(key:"motionPro",title:"OLED Motion / BFI",range:nil,options:["off","on"]),
        .init(key:"energySaving",title:"Energy saving",range:nil,options:["off","auto","min","med","max"]),
        .init(key:"eyeComfortMode",title:"Eye comfort mode",range:nil,options:["off","on"]),
        .init(key:"pictureMode",title:"Picture mode",range:nil,options:["cinema","expert1","expert2","game","normal","hdrCinema","hdrGame","dolbyHdrCinema","dolbyHdrCinemaBright","dolbyHdrGame"])
    ]
}

