import Foundation
import Combine
import Network
import Security

private enum PairingStore {
    static func read(_ host: String) -> String? {
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&item) == errSecSuccess,let d = item as? Data else { return nil }
        return String(data:d,encoding:.utf8)
    }
    static func save(_ key: String,host: String) {
        delete(host)
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecValueData as String:Data(key.utf8),kSecAttrAccessible as String:kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        SecItemAdd(q as CFDictionary,nil)
    }
    static func delete(_ host: String) {
        SecItemDelete([kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host] as CFDictionary)
    }
}

@MainActor final class WebOSTV: ObservableObject {
    @Published var sound:[String:String]=[:]
    @Published var requestedSound:[String:String]=[:]
    @Published var queuedSound:[String:String]=[:]
    @Published var sendingSound:[String:String]=[:]
    @Published var failedSound:[String:String]=[:]
    @Published var soundReadAt:[String:Date]=[:]
    @Published var soundUnavailable:[String:String]=[:]
    @Published var soundReading:Set<String>=[]
    @Published var soundBusy=false
    private var audioRevision=0
    var audioContextID:Int {audioRevision}
    var soundContextChanging:Bool {queuedSound["soundOutput"] != nil || sendingSound["soundOutput"] != nil || queuedSound["soundMode"] != nil || sendingSound["soundMode"] != nil}
    private var soundReadGeneration:[String:Int]=[:]
    private var soundAttempted:Set<String>=[]
    private var soundReadQueue:[String]=[]
    private var soundReadsInFlight=0
    private var soundQueue:[String]=[]
    private var soundWorker:Task<Void,Never>?
    @Published var devices: [TVDevice] = []
    @Published var profiles: [PictureProfile] = []
    @Published var selected: UUID?
    @Published var connected = false
    @Published var connecting = false
    @Published var pointerReady = false
    @Published var userError:String?
    @Published var status = "Add a TV to get started."
    @Published var model = "LG webOS"
    @Published var firmware = "Not reported"
    @Published private(set) var signal:TVSignal = .unknown
    @Published private(set) var contextMode = ""
    @Published var pendingCertificate:String?
    private var certificateHost:String?
    @Published var compatibilityKeys:Set<String>=[]
    private var reconnectOnReturn=false
    @Published var favoriteApps:Set<String>=[]
    @Published var apps: [TVApp] = []
    @Published var inputs: [TVInput] = []
    @Published var volume: Double?
    @Published var muted:Bool? = nil
    @Published var picture: [String:String] = [:]
    @Published var verifiedKeys: Set<String> = []
    @Published var diagnostics: [String] = []
    @Published var settingsBusy = false
    @Published var presetBusy = false
    @Published var modeSettling=false
    @Published private(set) var inputSwitchPending=false
    private var inputSwitchTarget=""
    private var inputSwitchTimeout:Task<Void,Never>?
    private var modeSettleTask:Task<Void,Never>?
    @Published var useLunaFallback = true
    @Published var autoRefreshPicture=false
    @Published var verifyPictureWrites=false
    private var socket:TVSocket?
    private var pointer:TVSocket?
    private let injectedSocketFactory:((URL)->TVSocket)?
    private let defaults:UserDefaults
    private let persistPairing:Bool
    private var pointerAttempt=0
    private var polling:Task<Void,Never>?
    private var pointerQueue:[String]=[]
    private var pointerSending=false
    private var readQueue:[String]=[]
    private var readsInFlight=0
    private var readGeneration:[String:Int]=[:]
    private var writeQueue:[String]=[]
    private var writeWorker:Task<Void,Never>?
    @Published var queuedPicture:[String:String]=[:]
    @Published var sendingPicture:[String:String]=[:]
    @Published var failedPicture:[String:String]=[:]
    private var watchedKeys=["backlight","contrast","brightness","color"]
    @Published var savedSelectionKeys:Set<String>=[]
    private var savedSelections:[String:[String:String]]=[:]
    @Published var requestedPicture:[String:String]=[:]
    @Published var readingKeys:Set<String>=[]
    @Published var unavailableKeys:[String:String]=[:]
    @Published var pictureReadAt:[String:Date]=[:]
    var contextID:Int {contextRevision}
    private var receiver: Task<Void,Never>?
    private var pointerReceiver: Task<Void,Never>?
    private var pending: [String:(Result<[String:Any],Error>)->Void] = [:]
    private var subscriptions: [String:([String:Any])->Void] = [:]
    private var requestURIs:[String:String]=[:]
    private var compatibilityCategories:Set<String>=[]
    private var sceneWorker:Task<Void,Never>?
    private var counter = 0
    private var epoch = 0
    private var contextRevision = 0
    private var foregroundApp = ""
    private var timeouts: [String:Task<Void,Never>] = [:]
    private var pairTimeout: Task<Void,Never>?
    private var wakeConnection: NWConnection?
    var pictureModePending:Bool {modeSettling || queuedPicture["pictureMode"] != nil || sendingPicture["pictureMode"] != nil}
    var hasPendingPicture:Bool {soundBusy || !queuedSound.isEmpty || !sendingSound.isEmpty || inputSwitchPending || settingsBusy || pictureModePending || !queuedPicture.isEmpty || !sendingPicture.isEmpty}
    var current: TVDevice? { devices.first { $0.id == selected } }
    init(defaults:UserDefaults = .standard,persistPairing:Bool=true,socketFactory:((URL)->TVSocket)? = nil) {
        self.defaults=defaults;self.persistPairing=persistPairing
        self.injectedSocketFactory=socketFactory
        autoRefreshPicture=defaults.bool(forKey:"prism.autoRefreshPicture")
        verifyPictureWrites=defaults.bool(forKey:"prism.verifyPictureWrites")
        useLunaFallback=defaults.object(forKey:"prism.useLunaFallback") as? Bool ?? true
        if let data = defaults.data(forKey:"prism.devices"),let v = try? JSONDecoder().decode([TVDevice].self,from:data) { devices = v }
        if let data = defaults.data(forKey:"prism.profiles"),let v = try? JSONDecoder().decode([PictureProfile].self,from:data) { profiles = v }
        if let raw = defaults.string(forKey:"prism.selected"),let id=UUID(uuidString:raw),devices.contains(where:{$0.id==id}) { selected=id } else { selected=devices.first?.id }
        if let data=defaults.data(forKey:"prism.savedSelections"),let cache=try? JSONDecoder().decode([String:[String:String]].self,from:data){savedSelections=cache}
        favoriteApps=Set(defaults.stringArray(forKey:"prism.favoriteApps") ?? [])
        // Legacy per-input selections are retained on disk, but never restored
        // into a context whose signal and picture mode have not been established.
    }
#if DEBUG
    private var simulateFixtureWrites=false
    func configureScreenshotFixture(simulateWrites:Bool=false){
        simulateFixtureWrites=simulateWrites
        devices=[TVDevice(name:"LG OLED B9 · Preview",host:"192.168.0.110",mac:"")];selected=devices.first?.id
        connected=true;pointerReady=true;model="LG OLED B9 · Preview";firmware="Screenshot fixture"
        foregroundApp="com.webos.app.hdmi1";signal = .sdr;contextMode="game"
        inputs=[TVInput(id:"com.webos.app.hdmi1",title:"HDMI 1 · PS5")]
        picture=["pictureMode":"game","backlight":"21","contrast":"85","brightness":"50","color":"50","blackLevel":"auto","peakBrightness":"off","gamma":"medium","noiseReduction":"off","superResolution":"low","realCinema":"on","truMotionMode":"off"]
        pictureReadAt=Dictionary(uniqueKeysWithValues:picture.keys.map{($0,Date())})
        sound=["soundOutput":"tv_speaker","soundMode":"standard","eArcSupport":"on","soundOutputDigital":"passThrough","clearVoice":"level1","userEqualizer":"on","userEqualizerValues":"[0,0,0,0,0]"]
        soundReadAt=Dictionary(uniqueKeysWithValues:sound.keys.map{($0,Date())})
        volume=27;muted=false;status="Preview data · no TV connection"
    }
#endif
    func persist() {
        defaults.set(try? JSONEncoder().encode(devices),forKey:"prism.devices")
        defaults.set(try? JSONEncoder().encode(profiles),forKey:"prism.profiles")
        defaults.set(selected?.uuidString,forKey:"prism.selected")
    }
    static func isLocalIP(_ host:String)->Bool {TVProtocol.isLocalIP(host)}
    func add(name: String,host: String,mac: String,secure:Bool=false) -> Bool {
        let host=host.trimmingCharacters(in:.whitespacesAndNewlines)
        guard Self.isLocalIP(host) else {status="Enter a private IPv4 address, for example 192.168.0.110.";return false}
        if let index=devices.firstIndex(where:{$0.host==host}) {
            if !mac.isEmpty {devices[index].mac=mac}
            devices[index].secure=secure
            if !name.isEmpty && name != "LG webOS TV" {devices[index].name=name}
            select(devices[index].id);persist();return true
        }
        var d=TVDevice(name:name.isEmpty ? "LG OLED" : name,host:host,mac:mac);d.secure=secure
        devices.append(d);select(d.id);persist();return true
    }
    func select(_ id: UUID) { if selected != id { disconnect();selected=id;restoreSelections();persist() } }
    func remove(_ id: UUID) {
        if selected==id {disconnect()}
        if persistPairing,let d=devices.first(where:{$0.id==id}) {PairingStore.delete(d.host)}
        let wasSelected=selected==id
        devices.removeAll{$0.id==id};profiles.removeAll{$0.device==id}
        savedSelections=savedSelections.filter{!$0.key.hasPrefix(id.uuidString+"|")}
        defaults.set(try? JSONEncoder().encode(savedSelections),forKey:"prism.savedSelections")
        if wasSelected {selected=devices.first?.id;restoreSelections()}
        persist()
    }
    func log(_ message: String) {
        let stamp=ISO8601DateFormatter().string(from:Date())
        diagnostics.insert("[\(stamp)] \(message)",at:0);if diagnostics.count>40 {diagnostics.removeLast()}
    }
    private func makeSocket(_ url:URL)->TVSocket {
        if let factory=injectedSocketFactory {return factory(url)}
        let host=url.host ?? "",token=epoch
        return NativeTVSocket(url:url,certificatePin:defaults.string(forKey:"prism.certificate."+host)) { [weak self] fingerprint in
            guard let self=self,self.epoch==token,self.current?.host==host else{return}
            self.certificateHost=host;self.pendingCertificate=fingerprint
        }
    }
    func approveCertificate(){
        guard let host=certificateHost,host==current?.host,let pin=pendingCertificate else{return}
        defaults.set(pin,forKey:"prism.certificate."+host)
        pendingCertificate=nil;certificateHost=nil;connect()
    }
    func rejectCertificate(){pendingCertificate=nil;certificateHost=nil}
    func updateDevice(_ id:UUID,name:String,host:String,mac:String,secure:Bool)->Bool {
        guard let index=devices.firstIndex(where:{$0.id==id}),Self.isLocalIP(host),mac.isEmpty || TVProtocol.wakePacket(mac) != nil else {status="Check the IP and MAC address.";return false}
        guard !devices.contains(where:{$0.id != id && $0.host==host}) else{status="That IP address is already saved.";return false}
        let old=devices[index]
        if selected==id {disconnect()}
        if old.host != host,persistPairing {PairingStore.delete(old.host)}
        devices[index].name=name.isEmpty ? old.name : name;devices[index].host=host;devices[index].mac=mac;devices[index].secure=secure
        persist();return true
    }
    func setSecure(_ secure:Bool,device:UUID){
        guard let index=devices.firstIndex(where:{$0.id==device}) else{return}
        if selected==device {disconnect()}
        devices[index].secure=secure;persist()
    }
    func setSignal(_ value:TVSignal){
        guard !hasPendingPicture,!presetBusy,signal != value else{return}
        signal=value;contextMode="";invalidatePicture()
        if connected {readPicture(keys:["pictureMode"])}
    }
    var inputTitle:String {TVProtocol.inputTitle(foregroundApp,inputs:inputs,apps:apps)}
    var contextDescription:String {"\(inputTitle) · \(signal.rawValue) · \(contextMode.isEmpty ? "Mode unknown" : PictureSetting.label(contextMode,key:"pictureMode"))"}
    func restriction(_ key:String)->String? {
        if signal == .sdr && key=="hdrDynamicToneMapping" {return "Available with HDR10 content"}
        if signal == .dolbyVision && ["gamma","hdrDynamicToneMapping"].contains(key) {return "Controlled by Dolby Vision"}
        if signal == .hdr10 && key=="gamma" {return "SDR gamma is unavailable in HDR10"}
        if ["truMotionJudder","truMotionBlur"].contains(key),let mode=picture["truMotionMode"] ?? requestedPicture["truMotionMode"],mode != "user" {return "Choose User TruMotion first"}
        return nil
    }
    func toggleFavorite(_ id:String){
        if favoriteApps.contains(id){favoriteApps.remove(id)}else{favoriteApps.insert(id)}
        defaults.set(Array(favoriteApps),forKey:"prism.favoriteApps")
    }
    func suspend(){reconnectOnReturn=connected;stopPolling()}
    func resume(){
        if connected {
            request("system/getSystemInfo",timeout:3){[weak self] result in
                guard let self=self else{return}
                if case .failure=result {self.connect()}
                else {self.startPolling();self.readVolume();if !self.pointerReady{self.reconnectPointer()}}
            }
        }else if reconnectOnReturn && current != nil {reconnectOnReturn=false;connect()}
    }
    var diagnosticReport:String {
        let version=Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String ?? "development"
        let report=(["Prism \(version)","Model: \(model)","Firmware: \(firmware)","Transport: \(current?.secure==true ? "WSS 3001" : "WS 3000")",contextDescription,"Status: \(status)"]+diagnostics).joined(separator:"\n")
        return report.replacingOccurrences(of:#"\b(?:\d{1,3}\.){3}\d{1,3}\b"#,with:"[local address]",options:.regularExpression)
    }
    func connect() {
        guard let tv=current else {status="Add a TV first.";return}
        disconnect();model="LG webOS";firmware="Not reported";pendingCertificate=nil;certificateHost=nil;userError=nil;connecting=true;status="Connecting to \(tv.name)…"
        guard Self.isLocalIP(tv.host),let url=URL(string:"\(tv.secure==true ? "wss" : "ws")://\(tv.host):\(tv.secure==true ? 3001 : 3000)") else {connecting=false;return}
        let token=epoch
        let ws=makeSocket(url);socket=ws;ws.connect()
        receiver=Task { [weak self] in
            do {
                while !Task.isCancelled {
                    let message=try await ws.receive()
                    guard let self=self,self.epoch==token else{return}
                    self.handle(message)
                }
            } catch {
                guard let self=self,self.epoch==token,!Task.isCancelled else{return}
                let awaitingCertificate=self.pendingCertificate != nil
                self.disconnect();if awaitingCertificate {self.status="Review the TV certificate to connect securely.";return};self.status="Connection lost. Check Wi-Fi, TV power and IP address.";self.userError=self.status;self.log("WebSocket: \(error.localizedDescription)")
            }
        }
        let permissions=["LAUNCH","LAUNCH_WEBAPP","APP_TO_APP","CONTROL_AUDIO","CONTROL_DISPLAY","CONTROL_INPUT_TV","CONTROL_INPUT_MEDIA_PLAYBACK","CONTROL_INPUT_TEXT","CONTROL_MOUSE_AND_KEYBOARD","CONTROL_POWER","CONTROL_TV_SCREEN","READ_APP_STATUS","READ_INSTALLED_APPS","READ_RUNNING_APPS","READ_INPUT_DEVICE_LIST","READ_CURRENT_CHANNEL","READ_TV_CHANNEL_LIST","READ_POWER_STATE","READ_SETTINGS","WRITE_SETTINGS","WRITE_NOTIFICATION_ALERT","WRITE_NOTIFICATION_TOAST"]
        var payload:[String:Any]=["forcePairing":false,"pairingType":"PROMPT","manifest":["manifestVersion":1,"appVersion":"1.0","permissions":permissions]]
        if persistPairing,let key=PairingStore.read(tv.host) {payload["client-key"]=key}
        send(["id":"register","type":"register","payload":payload])
        pairTimeout=Task { [weak self] in
            try? await Task.sleep(nanoseconds:60_000_000_000)
            guard !Task.isCancelled,let self=self,self.epoch==token,!self.connected else{return}
            self.disconnect();self.status="Pairing timed out. Approve the request on your TV and try again."
        }
    }
    func forgetPairing() { if persistPairing,let host=current?.host {PairingStore.delete(host)};disconnect();status="Pairing cleared. Connect and approve the request on your TV again." }
    func disconnect() {
        epoch += 1;inputSwitchTimeout?.cancel();inputSwitchPending=false;pointerAttempt += 1;receiver?.cancel();pointerReceiver?.cancel();pairTimeout?.cancel()
        socket?.close();pointer?.close();polling?.cancel();polling=nil;pointerQueue=[];pointerSending=false
        socket=nil;pointer=nil;connected=false;connecting=false;pointerReady=false;settingsBusy=false;presetBusy=false
        apps=[];inputs=[];volume=nil;muted=nil;foregroundApp="";signal = .unknown;contextMode="";invalidatePicture()
        sceneWorker?.cancel();sceneWorker=nil;compatibilityCategories=[]
        let callbacks=Array(pending.values);pending=[:];subscriptions=[:];requestURIs=[:]
        timeouts.values.forEach{$0.cancel()};timeouts=[:]
        callbacks.forEach{$0(.failure(TVFailure(message:"Disconnected")))}
        status="Disconnected"
    }
    private func send(_ object:[String:Any]) {
        guard let ws=socket,let data=try? JSONSerialization.data(withJSONObject:object),let text=String(data:data,encoding:.utf8) else{return}
        let token=epoch
        Task { [weak self] in
            do {try await ws.send(text)}
            catch {guard let self=self,self.epoch==token else{return};self.status="Could not send command.";self.log(error.localizedDescription)
                let id=TVProtocol.messageID(object["id"])
                self.timeouts.removeValue(forKey:id)?.cancel()
                self.requestURIs.removeValue(forKey:id)
                self.pending.removeValue(forKey:id)?(.failure(error))}
        }
    }
    private func handle(_ data:Data) {
        guard let obj=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{return}
        let type=obj["type"] as? String ?? "",id=TVProtocol.messageID(obj["id"])
        let payload=obj["payload"] as? [String:Any] ?? [:]
        if type=="registered" {
            guard !connected else{return}
            if persistPairing,let key=payload["client-key"] as? String,let host=current?.host {PairingStore.save(key,host:host)}
            pairTimeout?.cancel();connected=true;connecting=false;status="Connected to \(current?.name ?? "TV")";refresh();return
        }
        if id=="register",type=="response" {status="Approve pairing on your TV.";return}
        if type=="error" || (payload["returnValue"] as? Bool)==false {
            let failure=TVProtocol.rejection(obj)
            log("\(requestURIs[id] ?? id): \(failure.message)")
            requestURIs.removeValue(forKey:id)
            if id=="register" {disconnect();status="Pairing rejected. Clear the saved pairing and try again.";return}
            timeouts.removeValue(forKey:id)?.cancel()
            if let cb=pending.removeValue(forKey:id) {cb(.failure(failure))}
            subscriptions.removeValue(forKey:id)
            return
        }
        timeouts.removeValue(forKey:id)?.cancel()
        requestURIs.removeValue(forKey:id)
        if let cb=pending.removeValue(forKey:id) {cb(.success(payload))}
        subscriptions[id]?(payload)
    }
    func request(_ uri:String,payload:[String:Any]=[:],timeout:UInt64=10,completion:@escaping(Result<[String:Any],Error>)->Void) {
        guard connected else {completion(.failure(TVFailure(message:"Connect the TV first.")));return}
#if DEBUG
        // Only the isolated UI-test fixture uses this simulated acknowledgement.
        // It exercises dispatch/state updates without a socket or timeout. It
        // supplies no readback and is never enabled in the production app.
        if simulateFixtureWrites {
            if uri=="settings/setSystemSettings" {completion(.success(["returnValue":true]))}
            else {completion(.failure(TVFailure(message:"Preview data has no TV connection.")))}
            return
        }
#endif
        counter += 1;let id="r\(counter)"
        let token=epoch
        pending[id]={[weak self] result in
            guard self?.epoch==token else{completion(.failure(TVFailure(message:"Disconnected")));return}
            completion(result)
        }
        requestURIs[id]=uri
        send(TVProtocol.request(id:id,uri:uri,payload:payload))
        timeouts[id]=Task { [weak self] in
            try? await Task.sleep(nanoseconds:timeout*1_000_000_000)
            guard !Task.isCancelled,let self=self,let cb=self.pending.removeValue(forKey:id) else{return}
            self.timeouts.removeValue(forKey:id);self.requestURIs.removeValue(forKey:id);cb(.failure(TVFailure(message:"The TV did not reply in time.")))
        }
    }
    private func subscribe(_ uri:String,callback:@escaping([String:Any])->Void) {
        counter += 1;let id="s\(counter)";subscriptions[id]=callback
        send(["id":id,"type":"subscribe","uri":"ssap://"+uri,"payload":[:]])
    }
    func command(_ uri:String,payload:[String:Any]=[:],success:String="Command sent.") {
        let token=epoch
        let changesInput=uri=="tv/switchInput" || uri=="com.webos.applicationManager/launch"
        if changesInput {
            guard connected,!hasPendingPicture,!presetBusy else{return}
            beginInputSwitch(payload["inputId"] as? String ?? payload["id"] as? String ?? "")
        }
        request(uri,payload:payload) { [weak self] r in
            guard self?.epoch==token else{return}
            switch r {
            case .success:
                self?.userError=nil;self?.status=success
                if uri.hasPrefix("audio/") {self?.readVolume()}
                if changesInput {
                    self?.request("com.webos.applicationManager/getForegroundAppInfo",timeout:3){[weak self] result in
                        if case .success(let payload)=result,let app=payload["appId"] as? String {self?.acceptForeground(app)}
                    }
                }
            case .failure(let e):
                if changesInput {self?.inputSwitchTimeout?.cancel();self?.inputSwitchPending=false;self?.foregroundApp="";self?.invalidatePicture()}
                self?.showError(e)
            }
        }
    }
    private func acceptForeground(_ app:String){
        guard !app.isEmpty else{return}
        if inputSwitchPending {
            guard TVProtocol.inputIdentity(app)==TVProtocol.inputIdentity(inputSwitchTarget) else{return}
            inputSwitchTimeout?.cancel();inputSwitchPending=false
            foregroundApp=app;signal = .unknown;contextMode="";invalidatePicture()
            readPicture()
            return
        }
        guard app != foregroundApp else{return}
        let firstReply=foregroundApp.isEmpty
        foregroundApp=app
        if !firstReply {signal = .unknown;contextMode="";invalidatePicture();readPicture()}
        else {
            let choices=requestedPicture.filter{!savedSelectionKeys.contains($0.key)}
            restoreSelections();requestedPicture.merge(choices){_,new in new}
            for key in choices.keys {savedSelectionKeys.remove(key)}
            if !choices.isEmpty {cacheSelections(choices)}
        }
    }
    private func beginInputSwitch(_ target:String){
        inputSwitchTimeout?.cancel();inputSwitchTarget=target;inputSwitchPending=true
        signal = .unknown;contextMode="";invalidatePicture()
        let token=epoch
        inputSwitchTimeout=Task{[weak self] in
            try? await Task.sleep(nanoseconds:6_000_000_000)
            guard !Task.isCancelled,let self=self,self.epoch==token,self.inputSwitchPending else{return}
            self.inputSwitchPending=false;self.foregroundApp="";self.invalidatePicture()
            self.status="Input switch was not confirmed. Check the TV before changing picture settings.";self.userError=self.status
        }
    }
    func refresh() {
        guard connected else{return}
        request("system/getSystemInfo") { [weak self] r in if case .success(let p)=r,let name=p["modelName"] as? String {self?.model=name} }
        request("com.webos.applicationManager/listApps") { [weak self] r in
            if case .success(let p)=r,let list=p["apps"] as? [[String:Any]] {self?.apps=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVApp(id:id,title:v["title"] as? String ?? id,icon:v["icon"] as? String)}.sorted{$0.title.localizedCaseInsensitiveCompare($1.title) == ComparisonResult.orderedAscending}}
        }
        request("tv/getExternalInputList") { [weak self] r in
            if case .success(let p)=r,let list=p["devices"] as? [[String:Any]] {self?.inputs=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVInput(id:id,title:v["label"] as? String ?? id)}}
        }
        request("com.webos.service.update/getCurrentSWInformation") { [weak self] r in
            if case .success(let p)=r {
                if let name=p["model_name"] as? String {self?.model=name}
                if let version=p["product_version"] as? String {self?.firmware=version}
            }
        }
        subscribe("com.webos.applicationManager/getForegroundAppInfo") { [weak self] p in
            if let app=p["appId"] as? String {self?.acceptForeground(app)}
        }
        subscribe("audio/getVolume") { [weak self] p in
            self?.acceptVolume(p)
        }
        reconnectPointer()
        readPicture();startPolling()
    }
    func reconnectPointer(){
        guard connected else{return}
        pointerAttempt += 1;let attempt=pointerAttempt
        pointer?.close();pointerReady=false;pointerQueue=[];pointerSending=false
        request("com.webos.service.networkinput/getPointerInputSocket"){[weak self] result in
            guard let self=self,self.pointerAttempt==attempt else{return}
            if case .success(let payload)=result,let path=payload["socketPath"] as? String,let url=URL(string:path),["ws","wss"].contains(url.scheme ?? ""),url.host==self.current?.host,(self.current?.secure != true || url.scheme=="wss") {self.openPointer(url)}
            else {self.status="The TV rejected navigation. Clear pairing in TVs and reconnect."}
        }
    }
    private func openPointer(_ url:URL){
        pointerReceiver?.cancel();pointer?.close();pointerReady=false;pointerQueue=[];pointerSending=false
        let p=makeSocket(url),token=epoch
        pointer=p
        p.onOpen={[weak self,weak p] in guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=true;self.drainPointer()}
        p.onClose={[weak self,weak p] in guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=false}
        p.connect()
        pointerReceiver=Task{[weak self] in
            do {while !Task.isCancelled {_=try await p.receive()}}
            catch {guard let self=self,self.epoch==token,self.pointer === p,!Task.isCancelled else{return};self.pointerReady=false}
        }
    }
    func button(_ name:String){pointerSend(TVProtocol.button(name))}
    func move(dx:Int,dy:Int){pointerSend("type:move\ndx:\(dx)\ndy:\(dy)\ndown:0\n\n")}
    func click(){pointerSend("type:click\n\n")}
    private func pointerSend(_ text:String){
        guard connected,pointerReady else{status="Navigation is not ready. Tap Repair navigation.";return}
        guard pointerQueue.count<32 else{status="The remote is busy. Try again in a moment.";return}
        pointerQueue.append(text);drainPointer()
    }
    private func drainPointer(){
        guard !pointerSending,connected,pointerReady,let p=pointer,!pointerQueue.isEmpty else{return}
        pointerSending=true;let text=pointerQueue.removeFirst(),token=epoch
        Task{[weak self] in
            do {try await p.send(text)}
            catch {guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=false;self.pointerQueue=[];self.status="Navigation disconnected. Tap Repair navigation."}
            guard let self=self,self.epoch==token,self.pointer === p else{return}
            self.pointerSending=false;self.drainPointer()
        }
    }
    func invalidatePicture(restoreSaved:Bool=true){
        invalidateSound()
        modeSettleTask?.cancel();modeSettleTask=nil;modeSettling=false
        writeWorker?.cancel();writeWorker=nil;writeQueue=[];queuedPicture=[:];sendingPicture=[:];failedPicture=[:];readGeneration=[:]
        contextRevision += 1;picture=[:];verifiedKeys=[];requestedPicture=[:];pictureReadAt=[:];unavailableKeys=[:];readingKeys=[];readQueue=[];readsInFlight=0
        savedSelectionKeys=[];compatibilityKeys=[]
        if restoreSaved {restoreSelections()}
    }
    func readPicture(keys:[String]=["pictureMode","backlight","contrast","brightness","color"],force:Bool=true,priority:Bool=false){
        guard connected,!inputSwitchPending else{return}
        if priority {
            let queued=keys.filter{readQueue.contains($0)}
            readQueue.removeAll{queued.contains($0)};readQueue.insert(contentsOf:queued,at:0)
        }
        for key in keys where !readingKeys.contains(key) {
            if !force,let time=pictureReadAt[key],Date().timeIntervalSince(time)<5 {continue}
            readingKeys.insert(key);unavailableKeys.removeValue(forKey:key);if priority {readQueue.insert(key,at:0)}else{readQueue.append(key)}
        }
        pumpReads()
    }
    private func pumpReads(){
        guard connected else{return}
        while readsInFlight<3,!readQueue.isEmpty {
            let key=readQueue.removeFirst(),revision=contextRevision,token=epoch
            let generation=readGeneration[key,default:0]
            readsInFlight += 1
            readOne(key,currentApp:false){[weak self] value,error in
                guard let self=self,self.epoch==token,self.contextRevision==revision else{return}
                self.readsInFlight -= 1
                guard self.readGeneration[key,default:0]==generation else{self.pumpReads();return}
                self.readingKeys.remove(key)
                if let value=value {
                    if key=="pictureMode",self.contextMode != value {
                        let first=self.contextMode.isEmpty
                        self.contextMode=value
                        if !first {self.invalidatePicture()}
                        else {
                            let choices=self.requestedPicture.filter{!self.savedSelectionKeys.contains($0.key)}
                            self.restoreSelections();self.requestedPicture.merge(choices){_,new in new}
                            for key in choices.keys {self.savedSelectionKeys.remove(key)}
                            if !choices.isEmpty {self.cacheSelections(choices)}
                        }
                    }
                    self.picture[key]=value;self.verifiedKeys.insert(key);self.pictureReadAt[key]=Date();self.unavailableKeys.removeValue(forKey:key)}
                else {self.picture.removeValue(forKey:key);self.verifiedKeys.remove(key);self.pictureReadAt.removeValue(forKey:key);self.unavailableKeys[key]=error ?? "The TV did not expose this value."}
                self.pumpReads()
            }
        }
    }
    private func readOne(_ key:String,currentApp:Bool,completion:@escaping(String?,String?)->Void){
        let revision=contextRevision,token=epoch
        var payload:[String:Any]=["category":"picture","keys":[key]]
        if currentApp {payload["current_app"]=true}
        request("settings/getSystemSettings",payload:payload,timeout:3){[weak self] result in
            guard let self=self,self.epoch==token,self.contextRevision==revision else{completion(nil,"The TV context changed.");return}
            if case .success(let data)=result,let value=TVProtocol.pictureValues(data,allowed:[key])[key] {completion(value,nil)}
            else if !currentApp {self.readOne(key,currentApp:true,completion:completion)}
            else {
                let message:String
                switch result {case .failure(let error):message=error.localizedDescription;case .success:message="The TV did not return this setting."}
                completion(nil,message)
            }
        }
    }
    func watchPicture(keys:[String]){watchedKeys=keys}
    func saveReadPreferences(){
        defaults.set(autoRefreshPicture,forKey:"prism.autoRefreshPicture")
        defaults.set(verifyPictureWrites,forKey:"prism.verifyPictureWrites")
        defaults.set(useLunaFallback,forKey:"prism.useLunaFallback")
        if autoRefreshPicture {startPolling()}else{stopPolling()}
    }
    func startPolling(){
        polling?.cancel();polling=nil
        guard connected,autoRefreshPicture else{return}
        polling=Task{[weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds:8_000_000_000)
                guard !Task.isCancelled,let self=self,self.connected else{return}
                self.readPicture(keys:self.watchedKeys,force:false);self.readVolume()
            }
        }
    }
    func stopPolling(){polling?.cancel();polling=nil}
    func readVolume(){request("audio/getVolume"){[weak self] result in if case .success(let p)=result {self?.acceptVolume(p)}}}
    private func acceptVolume(_ payload:[String:Any]){
        let value=payload["volumeStatus"] as? [String:Any] ?? payload
        if let number=value["volume"] as? NSNumber {volume=(0...100).contains(number.doubleValue) ? number.doubleValue : nil}
        if let mute=value["mute"] as? Bool ?? value["muted"] as? Bool ?? value["muteStatus"] as? Bool {muted=mute}
    }
    func toggleMute(){
        if let value=muted {command("audio/setMute",payload:["mute":!value])}
        else {request("audio/getVolume"){[weak self] result in
            guard let self=self else{return}
            if case .success(let p)=result {self.acceptVolume(p)}
            guard let value=self.muted else{self.status="The TV did not report mute state.";return}
            self.command("audio/setMute",payload:["mute":!value])
        }}
    }
    func writePicture(_ settings:[String:String],completion:((Bool)->Void)?=nil) {
        guard connected,!inputSwitchPending,!settingsBusy,!settings.isEmpty else{completion?(false);return}
        let encoded:[String:Any]
        do {encoded=try PictureSetting.payload(settings)}
        catch {showError(error);completion?(false);return}
        settingsBusy=true
        let writeContext=contextRevision,token=epoch
        writeSettings(category:"picture",encoded:encoded) { [weak self] r in
            guard let self=self else{completion?(false);return}
            guard self.epoch==token else{completion?(false);return}
            guard self.contextRevision==writeContext else{self.settingsBusy=false;self.status="The input changed during the request. Check the picture on your TV.";completion?(false);return}
            switch r {
            case .success(let compatibility):self.accepted(settings,compatibility:compatibility);completion?(true)
            case .failure(let error):
                self.settingsBusy=false;self.showError(error);completion?(false)
            }
        }
    }
    func enqueuePicture(key:String,value:String) {
        guard !pictureModePending,!inputSwitchPending else{status="Wait for the input or picture mode change to finish.";return}
        guard connected,!presetBusy,restriction(key)==nil,let setting=PictureSetting.all.first(where:{$0.key==key}) else{return}
        let value=key=="blackLevel" ? TVProtocol.blackLevelValue(value) : value
        if let range=setting.range {
            guard let number=Double(value),number.isFinite,number.rounded()==number,range.contains(number) else{return}
        } else if !setting.choices(signal:signal).contains(value) {return}
        queuedPicture[key]=value;failedPicture.removeValue(forKey:key)
        if !writeQueue.contains(key) {writeQueue.append(key)}
        guard writeWorker==nil else{return}
        let token=epoch,revision=contextRevision
        writeWorker=Task{[weak self] in
            try? await Task.sleep(nanoseconds:150_000_000)
            while !Task.isCancelled {
                guard let self=self,self.epoch==token,self.contextRevision==revision,self.connected else{return}
                if self.settingsBusy || self.presetBusy {try? await Task.sleep(nanoseconds:80_000_000);continue}
                guard !self.writeQueue.isEmpty else{self.writeWorker=nil;return}
                let key=self.writeQueue.removeFirst()
                guard let value=self.queuedPicture.removeValue(forKey:key) else{continue}
                self.sendingPicture[key]=value
                self.writePicture([key:value]){[weak self] ok in
                    guard let self=self,self.epoch==token,(self.contextRevision==revision || (ok && key=="pictureMode" && self.contextRevision==revision+1)) else{return}
                    self.sendingPicture.removeValue(forKey:key)
                    if !ok {self.failedPicture[key]=self.status}
                }
            }
        }
    }
    private func accepted(_ values:[String:String],compatibility:Bool=false){
        if let mode=values["pictureMode"] {
            contextMode=mode
            invalidatePicture(restoreSaved:false);modeSettling=true
            let token=epoch,revision=contextRevision
            modeSettleTask=Task{[weak self] in
                try? await Task.sleep(nanoseconds:1_200_000_000)
                guard !Task.isCancelled,let self=self,self.epoch==token,self.contextRevision==revision else{return}
                self.modeSettling=false;self.modeSettleTask=nil
            }
        }
        for(key,value) in values {
            readGeneration[key,default:0] += 1
            readQueue.removeAll{$0==key};readingKeys.remove(key)
            savedSelectionKeys.remove(key)
            if compatibility {compatibilityKeys.insert(key)}else{compatibilityKeys.remove(key)}
            requestedPicture[key]=value;picture.removeValue(forKey:key);verifiedKeys.remove(key);pictureReadAt.removeValue(forKey:key)
        }
        cacheSelections(values)
        settingsBusy=false;userError=nil;status=compatibility ? "Compatibility request sent; TV result unverified." : verifyPictureWrites ? "Sent · reading back from TV." : "Sent · read-back off."
        if verifyPictureWrites {readPicture(keys:Array(values.keys),priority:true)}
    }
    // Cache the route only after an explicit permission/unsupported response.
    // Never retry a timed-out or interrupted write: its result is ambiguous.
    private func writeSettings(category:String,encoded:[String:Any],completion:@escaping(Result<Bool,Error>)->Void){
        let token=epoch,revision=contextRevision,audio=audioRevision
        let valid:()->Bool = { [weak self] in
            guard let self=self,self.connected,self.epoch==token,self.contextRevision==revision else{return false}
            return category != "sound" || self.audioRevision==audio
        }
        let compatible:()->Void = { [weak self] in
            guard let self=self,valid() else{completion(.failure(TVFailure(message:"The TV context changed.")));return}
            self.performLuna(uri:"luna://com.webos.settingsservice/setSystemSettings",params:["category":category,"settings":encoded]){result in
                switch result {
                case .success:self.compatibilityCategories.insert(category);completion(.success(true))
                case .failure(let error):completion(.failure(error))
                }
            }
        }
        if useLunaFallback,compatibilityCategories.contains(category) {compatible();return}
        request("settings/setSystemSettings",payload:["category":category,"settings":encoded]){[weak self] result in
            guard let self=self,valid() else{completion(.failure(TVFailure(message:"The TV context changed.")));return}
            switch result {
            case .success:completion(.success(false))
            case .failure(let error):
                guard self.useLunaFallback,TVProtocol.shouldUseCompatibilityFallback(error) else{completion(.failure(error));return}
                self.log("Using compatible settings writes for \(category): \(error.localizedDescription)")
                compatible()
            }
        }
    }
    private func performLuna(uri:String,params:[String:Any],completion:@escaping(Result<Void,Error>)->Void){
        let token=epoch
        let action:[String:Any]=["uri":uri,"params":params]
        let body:[String:Any]=["message":" ","buttons":[["label":"","onClick":uri,"params":params]],"onclose":action,"onfail":action]
        request("system.notifications/createAlert",payload:body){[weak self] result in
            guard let self=self,self.epoch==token else{completion(.failure(TVFailure(message:"Disconnected")));return}
            switch result {
            case .failure(let error):completion(.failure(error))
            case .success(let payload):
                guard let id=payload["alertId"] as? String,!id.isEmpty else{completion(.failure(TVFailure(message:"TV compatibility response did not include an alert ID.")));return}
                let normalized=TVProtocol.closeAlertID(id)
                self.request("system.notifications/closeAlert",payload:["alertId":normalized]){[weak self] result in
                    guard let self=self,self.epoch==token else{completion(.failure(TVFailure(message:"Disconnected")));return}
                    // Some versions retain the public ID when closing alerts.
                    if case .failure(let error)=result,let failure=error as? TVFailure,failure.rejectedByTV,normalized != id {
                        self.request("system.notifications/closeAlert",payload:["alertId":id]){retry in
                            completion(retry.map{_ in ()})
                        }
                    }else{completion(result.map{_ in ()})}
                }
            }
        }
    }
    func applyRecommended(_ preset:B9Preset,whiteBalance:String?) {
        guard connected,!hasPendingPicture,!presetBusy else{status="Wait for the current change to finish.";return}
        setSignal(TVSignal(rawValue:preset.signal.rawValue) ?? .unknown)
        applySettingsInOrder(preset.values(whiteBalance:whiteBalance),name:preset.name)
    }
    func applyProfile(_ profile:PictureProfile){
        guard profile.device==selected else{status="This scene belongs to another TV.";return}
        if let expected=profile.signal,expected != TVSignal.unknown.rawValue,expected != signal.rawValue {status="Choose the scene's \(expected) signal before applying.";return}
        applySettingsInOrder(profile.settings,name:profile.name)
    }
    private func applySettingsInOrder(_ values:[String:String],name:String){
        guard connected,!hasPendingPicture,!presetBusy,!values.isEmpty else{status="Wait for the current change to finish.";return}
        guard (try? PictureSetting.payload(values)) != nil else{status="Scene contains unsupported values.";userError=status;return}
        let token=epoch
        presetBusy=true;status="Sending scene \(name)…"
        sceneWorker=Task{[weak self] in
            guard let self=self else{return}
            var revision=self.contextRevision
            var sent=0
            var failed:[String]=[]
            if let mode=values["pictureMode"] {
                let ok=await self.sceneWrite(["pictureMode":mode])
                guard self.epoch==token,!Task.isCancelled else{return}
                guard ok,self.contextRevision==revision+1 else{self.presetBusy=false;return}
                revision=self.contextRevision
                try? await Task.sleep(nanoseconds:1_250_000_000)
                guard self.epoch==token,self.contextRevision==revision,!Task.isCancelled else{self.presetBusy=false;return}
                let observed:String?=await withCheckedContinuation{continuation in
                    self.readOne("pictureMode",currentApp:false){value,_ in continuation.resume(returning:value)}
                }
                guard self.epoch==token,self.contextRevision==revision,!Task.isCancelled else{self.presetBusy=false;return}
                if let observed=observed {
                    guard TVProtocol.pictureMatches(observed,mode) else{
                        self.presetBusy=false;self.status="Scene stopped: the TV returned a different picture mode (\(observed)).";self.userError=self.status;return
                    }
                    self.picture["pictureMode"]=observed;self.pictureReadAt["pictureMode"]=Date()
                }
                // Older firmware cannot read pictureMode. An unavailable read
                // must not make every preset unusable; retain unverified state.
                sent += 1
            }
            for key in values.keys.filter({$0 != "pictureMode"}).sorted() {
                guard self.epoch==token,self.contextRevision==revision,!Task.isCancelled else{self.presetBusy=false;return}
                let ok=await self.sceneWrite([key:values[key]!])
                guard self.epoch==token,self.contextRevision==revision,!Task.isCancelled else{self.presetBusy=false;return}
                if ok {sent += 1}else{failed.append(key);self.failedPicture[key]=self.status}
            }
            self.presetBusy=false;self.sceneWorker=nil
            if failed.isEmpty {self.userError=nil;self.status="Scene \(name): \(sent) requests sent. Confirm the picture on your TV."}
            else {self.status="Scene incomplete: \(sent) sent, \(failed.count) rejected (\(failed.joined(separator:", "))).";self.userError=self.status}
        }
    }
    private func sceneWrite(_ values:[String:String]) async -> Bool {
        await withCheckedContinuation{continuation in writePicture(values){continuation.resume(returning:$0)}}
    }
    func setHDMIType(input:String,pc:Bool) {
        guard connected,!hasPendingPicture,!presetBusy else{return}
        settingsBusy=true
        let uri="luna://com.webos.service.eim/setDeviceInfo"
        let params:[String:Any]=["id":input,"icon":pc ? "pc.png" : "hdmi.png","label":pc ? "PC" : "HDMI"]
        let token=epoch
        performLuna(uri:uri,params:params){[weak self] result in
            guard let self=self,self.epoch==token else{return}
            self.settingsBusy=false
            switch result {
            case .success:self.userError=nil;self.status="HDMI type sent. Check it on your TV."
            case .failure(let error):self.showError(error)
            }
        }
    }
    private func selectionCacheKey(_ input:String)->String? {
        guard let device=selected else{return nil}
        guard !input.isEmpty,input != "_last",signal != .unknown,!contextMode.isEmpty else{return nil}
        return device.uuidString+"|v2|"+input+"|"+signal.rawValue+"|"+contextMode
    }
    private func restoreSelections(){
        guard let key=selectionCacheKey(foregroundApp.isEmpty ? "_last" : foregroundApp) else{requestedPicture=[:];savedSelectionKeys=[];return}
        requestedPicture=savedSelections[key] ?? [:]
        savedSelectionKeys=Set(requestedPicture.keys)
    }
    private func cacheSelections(_ values:[String:String]){
        guard let key=selectionCacheKey(foregroundApp) else{return}
        var existing=values["pictureMode"] == nil ? (savedSelections[key] ?? [:]) : [:]
        existing.merge(values){_,new in new}
        savedSelections[key]=existing
        defaults.set(try? JSONEncoder().encode(savedSelections),forKey:"prism.savedSelections")
    }
    func makeSceneDraft(includeSelection:Bool)->SceneDraft? {
        guard let device=selected else{return nil}
        var values=picture
        if includeSelection {
            values.merge(requestedPicture){_,new in new}
            values.merge(sendingPicture){_,new in new}
            values.merge(queuedPicture){_,new in new}
        }
        guard !values.isEmpty else{return nil}
        let confirmed=Set(values.compactMap{key,value -> String? in
            guard let observed=picture[key],pictureReadAt[key] != nil else{return nil}
            let matches=key=="blackLevel" ? TVProtocol.blackLevelValue(observed)==TVProtocol.blackLevelValue(value) : TVProtocol.pictureMatches(observed,value)
            return matches ? key : nil
        })
        return SceneDraft(device:device,context:contextRevision,settings:values,confirmedKeys:confirmed,sourceInput:foregroundApp,signal:signal.rawValue,mode:contextMode)
    }
    @discardableResult func saveProfile(_ name:String,includeSelection:Bool=false)->Bool {
        guard let draft=makeSceneDraft(includeSelection:includeSelection) else{status="No values are available to save.";return false}
        return saveProfile(name,draft:draft)
    }
    @discardableResult func saveProfile(_ name:String,draft:SceneDraft)->Bool {
        guard selected==draft.device,contextRevision==draft.context else{status="The input changed. Open a new scene preview.";return false}
        let cleanName=name.trimmingCharacters(in:.whitespacesAndNewlines)
        profiles.append(PictureProfile(name:cleanName.isEmpty ? "My scene" : cleanName,device:draft.device,settings:draft.settings,confirmed:draft.confirmedKeys.count==draft.settings.count,confirmedKeys:draft.confirmedKeys,sourceInput:draft.sourceInput,signal:draft.signal,mode:draft.mode))
        persist();status="Scene saved: \(draft.settings.count) values.";return true
    }
    func sendText(_ text:String,completion:@escaping(Bool)->Void) {
        guard !text.isEmpty else{completion(false);return}
        request("com.webos.service.ime/insertText",payload:["text":text,"replace":0]){[weak self] result in
            switch result {
            case .success:self?.userError=nil;self?.status="Text sent to TV.";completion(true)
            case .failure(let error):self?.showError(error);completion(false)
            }
        }
    }
    private func showError(_ error:Error){
        log(error.localizedDescription)
        status=error is URLError ? "Connection failed. Check Wi-Fi and try again." : error.localizedDescription
        userError=status
    }
    func invalidateSound(){
        audioRevision += 1;soundWorker?.cancel();soundWorker=nil;soundQueue=[]
        if soundBusy {settingsBusy=false}
        soundBusy=false;queuedSound=[:];sendingSound=[:];failedSound=[:]
        sound=[:];requestedSound=[:];soundReadAt=[:];soundUnavailable=[:]
        soundReadQueue=[];soundReadsInFlight=0;soundReading=[];soundAttempted=[];soundReadGeneration=[:]
    }
    var externalAudioOutput:Bool {
        guard let output=sound["soundOutput"] ?? requestedSound["soundOutput"] else{return false}
        return !["tv_speaker","tv_speakerbar","builtin_soundbar"].contains(output)
    }
    var canUseTVEqualizer:Bool {
        guard let output=sound["soundOutput"] ?? requestedSound["soundOutput"] else{return false}
        return ["tv_speaker","tv_speakerbar","builtin_soundbar"].contains(output)
    }
    func loadSoundIfNeeded(keys:[String]){
        readSound(keys:keys.filter{!soundAttempted.contains($0)})
    }
    func readSound(keys:[String]){
        guard connected,!inputSwitchPending else{return}
#if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--preview-picture") || ProcessInfo.processInfo.arguments.contains("--preview-sound") || ProcessInfo.processInfo.arguments.contains("--preview-home"){return}
#endif
        for key in keys where SoundSetting.all.contains(where:{$0.key==key}) && !soundReading.contains(key) {
            soundAttempted.insert(key);soundReading.insert(key);soundReadQueue.append(key)
        }
        pumpSoundReads()
    }
    private func pumpSoundReads(){
        guard connected else{return}
        while soundReadsInFlight<3,!soundReadQueue.isEmpty {
            let key=soundReadQueue.removeFirst(),token=epoch,revision=audioRevision
            let generation=soundReadGeneration[key,default:0]
            soundReadsInFlight += 1
            let uri=key=="soundOutput" ? "com.webos.service.apiadapter/audio/getSoundOutput" : "settings/getSystemSettings"
            let payload:[String:Any]=key=="soundOutput" ? [:] : ["category":"sound","keys":[key]]
            request(uri,payload:payload,timeout:3){[weak self] result in
                guard let self=self,self.epoch==token,self.audioRevision==revision else{return}
                self.soundReadsInFlight -= 1
                guard self.soundReadGeneration[key,default:0]==generation else{self.pumpSoundReads();return}
                self.soundReading.remove(key)
                var value:String?
                if case .success(let response)=result {
                    if key=="soundOutput" {value=response["soundOutput"] as? String}
                    else if let settings=response["settings"] as? [String:Any] {
                        if key=="userEqualizerValues",let array=settings[key] as? [Any],let data=try? JSONSerialization.data(withJSONObject:array),let text=String(data:data,encoding:.utf8),SoundSetting.bands(text) != nil {value=text}
                        else {value=TVProtocol.pictureValues(response,allowed:[key])[key]}
                    }
                }
                if let value=value {
                    self.sound[key]=value;self.soundReadAt[key]=Date();self.soundUnavailable.removeValue(forKey:key)
                }else{
                    self.sound.removeValue(forKey:key);self.soundReadAt.removeValue(forKey:key)
                    self.soundUnavailable[key]="The TV did not expose this value. Read support can differ from write support."
                }
                self.pumpSoundReads()
            }
        }
    }
    func enqueueSound(key:String,value:String){
        guard connected,!inputSwitchPending,!presetBusy,!pictureModePending,!soundContextChanging else{return}
        guard (try? SoundSetting.payload([key:value])) != nil else{return}
        if key=="userEqualizerValues",!canUseTVEqualizer {status="Read or choose TV speakers before changing the TV equalizer.";return}
        if ["soundOutput","soundMode"].contains(key),soundBusy || !queuedSound.isEmpty {
            status="Wait for the current sound change to finish.";return
        }
        queuedSound[key]=value;failedSound.removeValue(forKey:key)
        if !soundQueue.contains(key){soundQueue.append(key)}
        guard soundWorker==nil else{return}
        let token=epoch,revision=audioRevision
        soundWorker=Task{[weak self] in
            try? await Task.sleep(nanoseconds:120_000_000)
            while !Task.isCancelled {
                guard let self=self,self.epoch==token,self.audioRevision==revision,self.connected else{return}
                if self.settingsBusy || self.presetBusy {try? await Task.sleep(nanoseconds:60_000_000);continue}
                guard !self.soundQueue.isEmpty else{self.soundWorker=nil;return}
                let key=self.soundQueue.removeFirst()
                guard let value=self.queuedSound.removeValue(forKey:key) else{continue}
                self.sendingSound[key]=value
                self.writeSound(key:key,value:value){[weak self] ok in
                    guard let self=self,self.epoch==token,self.audioRevision==revision else{return}
                    self.sendingSound.removeValue(forKey:key)
                    if !ok {self.failedSound[key]=self.status}
                }
            }
        }
    }
    private func writeSound(key:String,value:String,completion:@escaping(Bool)->Void){
        guard connected,!settingsBusy,let encoded=try? SoundSetting.payload([key:value]) else{completion(false);return}
        settingsBusy=true;soundBusy=true
        let token=epoch,revision=audioRevision
        let finish:(Result<Bool,Error>)->Void = {[weak self] result in
            guard let self=self,self.epoch==token,self.audioRevision==revision else{completion(false);return}
            switch result {
            case .success(let compatibility):self.acceptSound(key:key,value:value,compatibility:compatibility);completion(true)
            case .failure(let error):self.settingsBusy=false;self.soundBusy=false;self.showError(error);completion(false)
            }
        }
        if key=="soundOutput" {
            request("com.webos.service.apiadapter/audio/changeSoundOutput",payload:["soundOutput":value]){finish($0.map{_ in false})}
        }else{writeSettings(category:"sound",encoded:encoded,completion:finish)}
    }
    private func acceptSound(key:String,value:String,compatibility:Bool){
        if ["soundOutput","soundMode"].contains(key){
            let previousOutput=sound["soundOutput"] ?? requestedSound["soundOutput"]
            // No previous processing/EQ reading can be treated as current after
            // changing the route or mode. Pending read replies are invalidated.
            audioRevision += 1;soundReadQueue=[];soundReadsInFlight=0;soundReading=[];soundAttempted=[]
            sound=[:];soundReadAt=[:];requestedSound=[:];soundUnavailable=[:]
            if key=="soundMode",let output=previousOutput {requestedSound["soundOutput"]=output}
            // Output/mode requests are serialized with an empty queue. Let the
            // old worker finish and permit the next explicit user operation.
            soundWorker?.cancel();soundWorker=nil;soundQueue=[];queuedSound=[:];sendingSound=[:]
        }
        soundReadGeneration[key,default:0] += 1;soundReading.remove(key)
        sound.removeValue(forKey:key);soundReadAt.removeValue(forKey:key)
        requestedSound[key]=value;settingsBusy=false;soundBusy=false;userError=nil
        status=compatibility ? "Sound compatibility request sent; result unverified." : "Sound request accepted; physical result unverified."
        if verifyPictureWrites {readSound(keys:[key])}
    }
    func deleteProfile(_ id:UUID) {profiles.removeAll{$0.id==id};persist()}
    func wake() {
        guard let tv=current else{return}
        guard let packet=TVProtocol.wakePacket(tv.mac) else {status="Add a valid TV MAC address to use Wake-on-LAN.";return}
        wakeConnection?.cancel()
        let c=NWConnection(host:NWEndpoint.Host(tv.host),port:9,using:.udp);wakeConnection=c
        c.stateUpdateHandler={ [weak self,weak c] state in
            guard let c=c else{return}
            switch state {
            case .ready:
                c.send(content:packet,completion:.contentProcessed{error in
                    Task{@MainActor in
                        guard let self=self,self.wakeConnection === c else{return}
                        self.status=error==nil ? "Wake packet sent. Connect in a few seconds; delivery is not confirmed." : "The wake packet could not be sent."
                        c.stateUpdateHandler=nil;c.cancel();self.wakeConnection=nil
                    }
                })
            case .failed:
                Task{@MainActor in
                    guard let self=self,self.wakeConnection === c else{return}
                    self.status="Wake failed. Check the TV MAC address and standby-network settings."
                    c.stateUpdateHandler=nil;c.cancel();self.wakeConnection=nil
                }
            default:break
            }
        }
        c.start(queue:.main);status="Sending wake request…"
        Task{[weak self,weak c] in
            try? await Task.sleep(nanoseconds:4_000_000_000)
            guard let self=self,let c=c,self.wakeConnection === c else{return}
            self.status="Wake delivery timed out. Check Wi-Fi and TV standby-network settings."
            c.stateUpdateHandler=nil;c.cancel();self.wakeConnection=nil
        }
    }
}
