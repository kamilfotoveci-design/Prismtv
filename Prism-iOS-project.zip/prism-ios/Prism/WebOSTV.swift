import Foundation
import Combine
import Network
import Security

private enum PairingStore {
    static func read(_ host: String) -> String? {
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&item) == errSecSuccess,let d = item as? Data else { return nil }
        return String(data:d,encoding:.utf8)
    }
    static func save(_ key: String,host: String) {
        delete(host)
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecValueData as String:Data(key.utf8),kSecAttrAccessible as String:kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        SecItemAdd(q as CFDictionary,nil)
    }
    static func delete(_ host: String) {
        SecItemDelete([kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host] as CFDictionary)
    }
}

@MainActor final class WebOSTV: ObservableObject {
    @Published var devices: [TVDevice] = []
    @Published var profiles: [PictureProfile] = []
    @Published var selected: UUID?
    @Published var connected = false
    @Published var connecting = false
    @Published var pointerReady = false
    @Published var status = "Add your TV to get started"
    @Published var model = "LG webOS"
    @Published var apps: [TVApp] = []
    @Published var inputs: [TVInput] = []
    @Published var volume: Double?
    @Published var muted:Bool? = nil
    @Published var picture: [String:String] = [:]
    @Published var verifiedKeys: Set<String> = []
    @Published var diagnostics: [String] = []
    @Published var settingsBusy = false
    @Published var presetBusy = false
    @Published var useLunaFallback = true
    private var socket:TVSocket?
    private var pointer:TVSocket?
    private let socketFactory:(URL)->TVSocket
    private let defaults:UserDefaults
    private let persistPairing:Bool
    private var pointerAttempt=0
    private var polling:Task<Void,Never>?
    private var pointerQueue:[String]=[]
    private var pointerSending=false
    private var readQueue:[String]=[]
    private var readsInFlight=0
    private var watchedKeys=["backlight","contrast","brightness","color"]
    @Published var requestedPicture:[String:String]=[:]
    @Published var readingKeys:Set<String>=[]
    @Published var unavailableKeys:[String:String]=[:]
    @Published var pictureReadAt:[String:Date]=[:]
    var contextID:Int {contextRevision}
    private var receiver: Task<Void,Never>?
    private var pointerReceiver: Task<Void,Never>?
    private var pending: [String:(Result<[String:Any],Error>)->Void] = [:]
    private var subscriptions: [String:([String:Any])->Void] = [:]
    private var counter = 0
    private var epoch = 0
    private var contextRevision = 0
    private var foregroundApp = ""
    private var timeouts: [String:Task<Void,Never>] = [:]
    private var pairTimeout: Task<Void,Never>?
    private var wakeConnection: NWConnection?
    var current: TVDevice? { devices.first { $0.id == selected } }
    init(defaults:UserDefaults = .standard,persistPairing:Bool=true,socketFactory:((URL)->TVSocket)? = nil) {
        self.defaults=defaults;self.persistPairing=persistPairing
        self.socketFactory=socketFactory ?? {NativeTVSocket(url:$0)}
        if let data = defaults.data(forKey:"prism.devices"),let v = try? JSONDecoder().decode([TVDevice].self,from:data) { devices = v }
        if let data = defaults.data(forKey:"prism.profiles"),let v = try? JSONDecoder().decode([PictureProfile].self,from:data) { profiles = v }
        if let raw = defaults.string(forKey:"prism.selected"),let id=UUID(uuidString:raw),devices.contains(where:{$0.id==id}) { selected=id } else { selected=devices.first?.id }
    }
    func persist() {
        defaults.set(try? JSONEncoder().encode(devices),forKey:"prism.devices")
        defaults.set(try? JSONEncoder().encode(profiles),forKey:"prism.profiles")
        defaults.set(selected?.uuidString,forKey:"prism.selected")
    }
    static func isLocalIP(_ host:String)->Bool {TVProtocol.isLocalIP(host)}
    func add(name: String,host: String,mac: String) -> Bool {
        let host=host.trimmingCharacters(in:.whitespacesAndNewlines)
        guard Self.isLocalIP(host) else {status="Enter a private IPv4 address, for example 192.168.0.110";return false}
        if let index=devices.firstIndex(where:{$0.host==host}) {
            if !mac.isEmpty {devices[index].mac=mac}
            if !name.isEmpty && name != "LG webOS TV" {devices[index].name=name}
            select(devices[index].id);persist();return true
        }
        let d=TVDevice(name:name.isEmpty ? "LG OLED" : name,host:host,mac:mac)
        devices.append(d);select(d.id);persist();return true
    }
    func select(_ id: UUID) { if selected != id { disconnect();selected=id;persist() } }
    func remove(_ id: UUID) {
        if selected==id {disconnect()}
        if persistPairing,let d=devices.first(where:{$0.id==id}) {PairingStore.delete(d.host)}
        let wasSelected=selected==id
        devices.removeAll{$0.id==id};profiles.removeAll{$0.device==id}
        if wasSelected {selected=devices.first?.id}
        persist()
    }
    func log(_ message: String) {
        diagnostics.insert(message,at:0);if diagnostics.count>40 {diagnostics.removeLast()}
    }
    func connect() {
        guard let tv=current else {status="Add a TV first";return}
        disconnect();connecting=true;status="Connecting to \(tv.name)…"
        guard Self.isLocalIP(tv.host),let url=URL(string:"ws://\(tv.host):3000") else {connecting=false;return}
        let token=epoch
        let ws=socketFactory(url);socket=ws;ws.connect()
        receiver=Task { [weak self] in
            do {
                while !Task.isCancelled {
                    let message=try await ws.receive()
                    guard let self=self,self.epoch==token else{return}
                    self.handle(message)
                }
            } catch {
                guard let self=self,self.epoch==token,!Task.isCancelled else{return}
                self.disconnect();self.status="Connection lost. Check Wi-Fi, TV power and IP address.";self.log("WebSocket: \(error.localizedDescription)")
            }
        }
        let permissions=["LAUNCH","LAUNCH_WEBAPP","APP_TO_APP","CONTROL_AUDIO","CONTROL_DISPLAY","CONTROL_INPUT_TV","CONTROL_INPUT_MEDIA_PLAYBACK","CONTROL_INPUT_TEXT","CONTROL_MOUSE_AND_KEYBOARD","CONTROL_POWER","CONTROL_TV_SCREEN","READ_APP_STATUS","READ_INSTALLED_APPS","READ_RUNNING_APPS","READ_INPUT_DEVICE_LIST","READ_CURRENT_CHANNEL","READ_TV_CHANNEL_LIST","READ_POWER_STATE","READ_SETTINGS","WRITE_SETTINGS","WRITE_NOTIFICATION_ALERT","WRITE_NOTIFICATION_TOAST"]
        var payload:[String:Any]=["forcePairing":false,"pairingType":"PROMPT","manifest":["manifestVersion":1,"appVersion":"1.0","permissions":permissions]]
        if persistPairing,let key=PairingStore.read(tv.host) {payload["client-key"]=key}
        send(["id":"register","type":"register","payload":payload])
        pairTimeout=Task { [weak self] in
            try? await Task.sleep(nanoseconds:60_000_000_000)
            guard !Task.isCancelled,let self=self,self.epoch==token,!self.connected else{return}
            self.disconnect();self.status="Pairing timed out. Accept the request on your TV, then retry."
        }
    }
    func forgetPairing() { if persistPairing,let host=current?.host {PairingStore.delete(host)};disconnect();status="Pairing cleared. Connect and approve again on the TV." }
    func disconnect() {
        epoch += 1;pointerAttempt += 1;receiver?.cancel();pointerReceiver?.cancel();pairTimeout?.cancel()
        socket?.close();pointer?.close();polling?.cancel();polling=nil;pointerQueue=[];pointerSending=false
        socket=nil;pointer=nil;connected=false;connecting=false;pointerReady=false;settingsBusy=false;presetBusy=false
        apps=[];inputs=[];volume=nil;muted=nil;foregroundApp="";invalidatePicture()
        let callbacks=Array(pending.values);pending=[:];subscriptions=[:]
        timeouts.values.forEach{$0.cancel()};timeouts=[:]
        callbacks.forEach{$0(.failure(TVFailure(message:"Disconnected")))}
        status="Disconnected"
    }
    private func send(_ object:[String:Any]) {
        guard let ws=socket,let data=try? JSONSerialization.data(withJSONObject:object),let text=String(data:data,encoding:.utf8) else{return}
        let token=epoch
        Task { [weak self] in
            do {try await ws.send(text)}
            catch {guard let self=self,self.epoch==token else{return};self.status="Could not send command";self.log(error.localizedDescription)
                let id=TVProtocol.messageID(object["id"])
                self.timeouts.removeValue(forKey:id)?.cancel()
                self.pending.removeValue(forKey:id)?(.failure(error))}
        }
    }
    private func handle(_ data:Data) {
        guard let obj=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{return}
        let type=obj["type"] as? String ?? "",id=TVProtocol.messageID(obj["id"])
        let payload=obj["payload"] as? [String:Any] ?? [:]
        if type=="registered" {
            guard !connected else{return}
            if persistPairing,let key=payload["client-key"] as? String,let host=current?.host {PairingStore.save(key,host:host)}
            pairTimeout?.cancel();connected=true;connecting=false;status="Connected to \(current?.name ?? "TV")";refresh();return
        }
        if id=="register",type=="response" {status="Accept the pairing request on your TV";return}
        if type=="error" || (payload["returnValue"] as? Bool)==false {
            let error=(obj["error"] as? String) ?? (payload["errorText"] as? String) ?? "TV rejected the command"
            log(error)
            if id=="register" {disconnect();status="Pairing rejected. Clear pairing and try again.";return}
            timeouts.removeValue(forKey:id)?.cancel()
            if let cb=pending.removeValue(forKey:id) {cb(.failure(TVFailure(message:error)))}
            subscriptions.removeValue(forKey:id)
            return
        }
        timeouts.removeValue(forKey:id)?.cancel()
        if let cb=pending.removeValue(forKey:id) {cb(.success(payload))}
        subscriptions[id]?(payload)
    }
    func request(_ uri:String,payload:[String:Any]=[:],timeout:UInt64=10,completion:@escaping(Result<[String:Any],Error>)->Void) {
        guard connected else {completion(.failure(TVFailure(message:"Connect the TV first")));return}
        counter += 1;let id="r\(counter)"
        let token=epoch
        pending[id]={[weak self] result in guard self?.epoch==token else{return};completion(result)}
        send(TVProtocol.request(id:id,uri:uri,payload:payload))
        timeouts[id]=Task { [weak self] in
            try? await Task.sleep(nanoseconds:timeout*1_000_000_000)
            guard !Task.isCancelled,let self=self,let cb=self.pending.removeValue(forKey:id) else{return}
            self.timeouts.removeValue(forKey:id);cb(.failure(TVFailure(message:"TV did not reply in time")))
        }
    }
    private func subscribe(_ uri:String,callback:@escaping([String:Any])->Void) {
        counter += 1;let id="s\(counter)";subscriptions[id]=callback
        send(["id":id,"type":"subscribe","uri":"ssap://"+uri,"payload":[:]])
    }
    func command(_ uri:String,payload:[String:Any]=[:],success:String="Command accepted") {
        request(uri,payload:payload) { [weak self] r in
            switch r {
            case .success:
                self?.status=success
                if uri.hasPrefix("audio/") {self?.readVolume()}
                if uri=="tv/switchInput" || uri=="com.webos.applicationManager/launch" {
                    self?.invalidatePicture();self?.readPicture()
                }
            case .failure(let e):self?.status=e.localizedDescription
            }
        }
    }
    func refresh() {
        guard connected else{return}
        request("system/getSystemInfo") { [weak self] r in if case .success(let p)=r,let name=p["modelName"] as? String {self?.model=name} }
        request("com.webos.applicationManager/listApps") { [weak self] r in
            if case .success(let p)=r,let list=p["apps"] as? [[String:Any]] {self?.apps=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVApp(id:id,title:v["title"] as? String ?? id)}.sorted{$0.title.localizedCaseInsensitiveCompare($1.title) == ComparisonResult.orderedAscending}}
        }
        request("tv/getExternalInputList") { [weak self] r in
            if case .success(let p)=r,let list=p["devices"] as? [[String:Any]] {self?.inputs=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVInput(id:id,title:v["label"] as? String ?? id)}}
        }
        subscribe("com.webos.applicationManager/getForegroundAppInfo") { [weak self] p in
            guard let self=self,let app=p["appId"] as? String,app != self.foregroundApp else{return}
            self.foregroundApp=app;self.invalidatePicture();self.readPicture()
        }
        subscribe("audio/getVolume") { [weak self] p in
            self?.acceptVolume(p)
        }
        reconnectPointer()
        readPicture();startPolling()
    }
    func reconnectPointer(){
        guard connected else{return}
        pointerAttempt += 1;let attempt=pointerAttempt
        pointer?.close();pointerReady=false;pointerQueue=[];pointerSending=false
        request("com.webos.service.networkinput/getPointerInputSocket"){[weak self] result in
            guard let self=self,self.pointerAttempt==attempt else{return}
            if case .success(let payload)=result,let path=payload["socketPath"] as? String,let url=URL(string:path),url.scheme=="ws",url.host==self.current?.host {self.openPointer(url)}
            else {self.status="TV denied remote navigation. Try clearing pairing in Devices."}
        }
    }
    private func openPointer(_ url:URL){
        pointerReceiver?.cancel();pointer?.close();pointerReady=false;pointerQueue=[];pointerSending=false
        let p=socketFactory(url),token=epoch
        pointer=p
        p.onOpen={[weak self,weak p] in guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=true;self.drainPointer()}
        p.onClose={[weak self,weak p] in guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=false}
        p.connect()
        pointerReceiver=Task{[weak self] in
            do {while !Task.isCancelled {_=try await p.receive()}}
            catch {guard let self=self,self.epoch==token,self.pointer === p,!Task.isCancelled else{return};self.pointerReady=false}
        }
    }
    func button(_ name:String){pointerSend(TVProtocol.button(name))}
    func move(dx:Int,dy:Int){pointerSend("type:move\ndx:\(dx)\ndy:\(dy)\ndown:0\n\n")}
    func click(){pointerSend("type:click\n\n")}
    private func pointerSend(_ text:String){
        guard connected,pointerReady else{status="Navigation is not ready. Tap Repair remote.";return}
        guard pointerQueue.count<32 else{status="Remote is busy; try again in a moment";return}
        pointerQueue.append(text);drainPointer()
    }
    private func drainPointer(){
        guard !pointerSending,connected,pointerReady,let p=pointer,!pointerQueue.isEmpty else{return}
        pointerSending=true;let text=pointerQueue.removeFirst(),token=epoch
        Task{[weak self] in
            do {try await p.send(text)}
            catch {guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=false;self.pointerQueue=[];self.status="Navigation connection lost. Tap Repair remote."}
            guard let self=self,self.epoch==token,self.pointer === p else{return}
            self.pointerSending=false;self.drainPointer()
        }
    }
    func invalidatePicture(){
        contextRevision += 1;picture=[:];verifiedKeys=[];requestedPicture=[:];pictureReadAt=[:];unavailableKeys=[:];readingKeys=[];readQueue=[];readsInFlight=0
    }
    func readPicture(keys:[String]=["backlight","contrast","brightness","color"],force:Bool=true,priority:Bool=false){
        guard connected else{return}
        if priority {
            let queued=keys.filter{readQueue.contains($0)}
            readQueue.removeAll{queued.contains($0)};readQueue.insert(contentsOf:queued,at:0)
        }
        for key in keys where !readingKeys.contains(key) {
            if !force,let time=pictureReadAt[key],Date().timeIntervalSince(time)<5 {continue}
            readingKeys.insert(key);unavailableKeys.removeValue(forKey:key);if priority {readQueue.insert(key,at:0)}else{readQueue.append(key)}
        }
        pumpReads()
    }
    private func pumpReads(){
        guard connected else{return}
        while readsInFlight<3,!readQueue.isEmpty {
            let key=readQueue.removeFirst(),revision=contextRevision,token=epoch
            readsInFlight += 1
            readOne(key,currentApp:false){[weak self] value,error in
                guard let self=self,self.epoch==token,self.contextRevision==revision else{return}
                self.readsInFlight -= 1;self.readingKeys.remove(key)
                if let value=value {self.picture[key]=value;self.verifiedKeys.insert(key);self.pictureReadAt[key]=Date();self.unavailableKeys.removeValue(forKey:key)}
                else {self.picture.removeValue(forKey:key);self.verifiedKeys.remove(key);self.pictureReadAt.removeValue(forKey:key);self.unavailableKeys[key]=error ?? "This value is not exposed by the TV"}
                self.pumpReads()
            }
        }
    }
    private func readOne(_ key:String,currentApp:Bool,completion:@escaping(String?,String?)->Void){
        let revision=contextRevision,token=epoch
        var payload:[String:Any]=["category":"picture","keys":[key]]
        if currentApp {payload["current_app"]=true}
        request("settings/getSystemSettings",payload:payload,timeout:3){[weak self] result in
            guard let self=self,self.epoch==token,self.contextRevision==revision else{return}
            if case .success(let data)=result,let value=TVProtocol.pictureValues(data,allowed:[key])[key] {completion(value,nil)}
            else if !currentApp {self.readOne(key,currentApp:true,completion:completion)}
            else {
                let message:String
                switch result {case .failure(let error):message=error.localizedDescription;case .success:message="TV did not return this setting"}
                completion(nil,message)
            }
        }
    }
    func watchPicture(keys:[String]){watchedKeys=keys}
    func startPolling(){
        polling?.cancel()
        guard connected else{return}
        polling=Task{[weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds:8_000_000_000)
                guard !Task.isCancelled,let self=self,self.connected else{return}
                self.readPicture(keys:self.watchedKeys,force:false);self.readVolume()
            }
        }
    }
    func stopPolling(){polling?.cancel();polling=nil}
    func readVolume(){request("audio/getVolume"){[weak self] result in if case .success(let p)=result {self?.acceptVolume(p)}}}
    private func acceptVolume(_ payload:[String:Any]){
        let value=payload["volumeStatus"] as? [String:Any] ?? payload
        if let number=value["volume"] as? NSNumber {volume=(0...100).contains(number.doubleValue) ? number.doubleValue : nil}
        if let mute=value["mute"] as? Bool ?? value["muted"] as? Bool ?? value["muteStatus"] as? Bool {muted=mute}
    }
    func toggleMute(){
        if let value=muted {command("audio/setMute",payload:["mute":!value])}
        else {request("audio/getVolume"){[weak self] result in
            guard let self=self else{return}
            if case .success(let p)=result {self.acceptVolume(p)}
            guard let value=self.muted else{self.status="TV did not report mute state";return}
            self.command("audio/setMute",payload:["mute":!value])
        }}
    }
    func writePicture(_ settings:[String:String],completion:((Bool)->Void)?=nil) {
        guard connected,!settingsBusy,!settings.isEmpty else{completion?(false);return}
        settingsBusy=true
        let writeContext=contextRevision
        request("settings/setSystemSettings",payload:["category":"picture","settings":settings]) { [weak self] r in
            guard let self=self else{completion?(false);return}
            guard self.contextRevision==writeContext else{self.settingsBusy=false;self.status="Input changed during the request · verify the TV";completion?(false);return}
            switch r {
            case .success:self.accepted(settings);completion?(true)
            case .failure(let error):
                if self.useLunaFallback {self.lunaWrite(settings,completion:completion)}
                else {self.settingsBusy=false;self.status=error.localizedDescription;completion?(false)}
            }
        }
    }
    private func accepted(_ values:[String:String]){
        invalidatePicture()
        for(key,value) in values {requestedPicture[key]=value;picture.removeValue(forKey:key);verifiedKeys.remove(key);pictureReadAt.removeValue(forKey:key)}
        settingsBusy=false;status="Request sent · reading back from TV"
        readPicture(keys:Array(values.keys))
    }
    private func lunaWrite(_ values:[String:String],completion:((Bool)->Void)?=nil) {
        let writeContext=contextRevision
        let uri="luna://com.webos.settingsservice/setSystemSettings"
        let params:[String:Any]=["category":"picture","settings":values]
        let body:[String:Any]=["message":" ","buttons":[["label":"","onClick":uri,"params":params]],"onclose":["uri":uri,"params":params],"onfail":["uri":uri,"params":params]]
        request("system.notifications/createAlert",payload:body) { [weak self] r in
            guard let self=self else{completion?(false);return}
            guard case .success(let p)=r,let alert=p["alertId"] as? String else {self.settingsBusy=false;self.status="TV blocked picture writes on this firmware";completion?(false);return}
            self.request("system.notifications/closeAlert",payload:["alertId":TVProtocol.closeAlertID(alert)]) { [weak self] result in
                guard let self=self else{completion?(false);return}
                guard self.contextRevision==writeContext else{self.settingsBusy=false;self.status="Input changed during the request · verify the TV";completion?(false);return}
                if case .success=result {self.accepted(values);completion?(true)}
                else {self.settingsBusy=false;self.status="Could not complete picture setting request";completion?(false)}
            }
        }
    }
    func applyRecommended(_ preset:B9Preset,whiteBalance:String?) {
        guard connected,!settingsBusy,!presetBusy else{return}
        let token=epoch
        let initialContext=contextRevision
        presetBusy=true
        status="Requesting \(preset.name)…"
        writePicture(["pictureMode":preset.mode]) { [weak self] ok in
            guard let self=self,self.epoch==token else{return}
            guard ok else {self.presetBusy=false;self.status="Preset stopped: picture mode request failed";return}
            guard self.contextRevision==initialContext+1 else{self.presetBusy=false;self.status="Preset stopped: input changed during mode selection";return}
            let revision=self.contextRevision
            self.status="Picture mode requested · preparing values…"
            Task { [weak self] in
                try? await Task.sleep(nanoseconds:1_200_000_000)
                guard let self=self,self.epoch==token,self.connected else{return}
                guard self.contextRevision==revision else{self.presetBusy=false;self.status="Preset stopped because the input changed";return}
                if let observed=self.picture["pictureMode"],observed != preset.mode {
                    self.presetBusy=false;self.status="Preset stopped: TV reported a different picture mode";return
                }
                var values=preset.values(whiteBalance:whiteBalance);values.removeValue(forKey:"pictureMode")
                self.writePicture(values) { [weak self] finished in
                    guard let self=self,self.epoch==token else{return}
                    self.presetBusy=false
                    self.status=finished ? "\(preset.name) requested · verify the picture on TV" : "Preset incomplete · mode may have changed; check the TV"
                }
            }
        }
    }
    func setHDMIType(input:String,pc:Bool) {
        guard connected,!settingsBusy,!presetBusy else{return}
        settingsBusy=true
        let uri="luna://com.webos.service.eim/setDeviceInfo"
        let params:[String:Any]=["id":input,"icon":pc ? "pc.png" : "hdmi.png","label":pc ? "PC" : "HDMI"]
        let body:[String:Any]=["message":" ","buttons":[["label":"","onClick":uri,"params":params]],"onclose":["uri":uri,"params":params],"onfail":["uri":uri,"params":params]]
        request("system.notifications/createAlert",payload:body) { [weak self] r in
            guard let self=self else{return}
            guard case .success(let p)=r,let id=p["alertId"] as? String else{self.settingsBusy=false;self.status="TV blocked the HDMI type request";return}
            self.request("system.notifications/closeAlert",payload:["alertId":TVProtocol.closeAlertID(id)]) { [weak self] result in
                guard let self=self else{return};self.settingsBusy=false
                if case .success=result {self.status="HDMI type requested · verify on the TV"} else {self.status="HDMI type request failed"}
            }
        }
    }
    func saveProfile(_ name:String) {
        guard let tv=current,!picture.isEmpty else{status="No confirmed TV values to save";return}
        profiles.append(PictureProfile(name:name.isEmpty ? "My picture" : name,device:tv.id,settings:picture,confirmed:true));persist();status="Confirmed TV values saved"
    }
    func deleteProfile(_ id:UUID) {profiles.removeAll{$0.id==id};persist()}
    func wake() {
        guard let tv=current else{return}
        guard let packet=TVProtocol.wakePacket(tv.mac) else {status="Add a valid TV MAC address to use Wake-on-LAN";return}
        wakeConnection?.cancel()
        let c=NWConnection(host:NWEndpoint.Host(tv.host),port:9,using:.udp);wakeConnection=c
        c.stateUpdateHandler={ [weak self] state in if case .ready=state {c.send(content:packet,completion:.contentProcessed{error in Task { @MainActor in self?.status=error==nil ? "Wake packet sent · try Connect in a few seconds" : "Wake packet could not be sent";c.cancel()}})} }
        c.start(queue:.main)
        status="Sending Wake-on-LAN…"
        Task {try? await Task.sleep(nanoseconds:4_000_000_000);c.cancel()}
    }
}

