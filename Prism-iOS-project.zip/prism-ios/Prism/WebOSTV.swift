import Foundation
import Combine
import Network
import Security

private enum PairingStore {
    static func read(_ host: String) -> String? {
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&item) == errSecSuccess,let d = item as? Data else { return nil }
        return String(data:d,encoding:.utf8)
    }
    static func save(_ key: String,host: String) {
        delete(host)
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecValueData as String:Data(key.utf8),kSecAttrAccessible as String:kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        SecItemAdd(q as CFDictionary,nil)
    }
    static func delete(_ host: String) {
        SecItemDelete([kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host] as CFDictionary)
    }
}

@MainActor final class WebOSTV: ObservableObject {
    @Published var devices: [TVDevice] = []
    @Published var profiles: [PictureProfile] = []
    @Published var selected: UUID?
    @Published var connected = false
    @Published var connecting = false
    @Published var pointerReady = false
    @Published var userError:String?
    @Published var status = "Začni pridaním televízora."
    @Published var model = "LG webOS"
    @Published var apps: [TVApp] = []
    @Published var inputs: [TVInput] = []
    @Published var volume: Double?
    @Published var muted:Bool? = nil
    @Published var picture: [String:String] = [:]
    @Published var verifiedKeys: Set<String> = []
    @Published var diagnostics: [String] = []
    @Published var settingsBusy = false
    @Published var presetBusy = false
    @Published var modeSettling=false
    private var modeSettleTask:Task<Void,Never>?
    @Published var useLunaFallback = true
    @Published var autoRefreshPicture=false
    @Published var verifyPictureWrites=false
    private var socket:TVSocket?
    private var pointer:TVSocket?
    private let socketFactory:(URL)->TVSocket
    private let defaults:UserDefaults
    private let persistPairing:Bool
    private var pointerAttempt=0
    private var polling:Task<Void,Never>?
    private var pointerQueue:[String]=[]
    private var pointerSending=false
    private var readQueue:[String]=[]
    private var readsInFlight=0
    private var readGeneration:[String:Int]=[:]
    private var writeQueue:[String]=[]
    private var writeWorker:Task<Void,Never>?
    @Published var queuedPicture:[String:String]=[:]
    @Published var sendingPicture:[String:String]=[:]
    @Published var failedPicture:[String:String]=[:]
    private var watchedKeys=["backlight","contrast","brightness","color"]
    @Published var requestedPicture:[String:String]=[:]
    @Published var readingKeys:Set<String>=[]
    @Published var unavailableKeys:[String:String]=[:]
    @Published var pictureReadAt:[String:Date]=[:]
    var contextID:Int {contextRevision}
    private var receiver: Task<Void,Never>?
    private var pointerReceiver: Task<Void,Never>?
    private var pending: [String:(Result<[String:Any],Error>)->Void] = [:]
    private var subscriptions: [String:([String:Any])->Void] = [:]
    private var counter = 0
    private var epoch = 0
    private var contextRevision = 0
    private var foregroundApp = ""
    private var timeouts: [String:Task<Void,Never>] = [:]
    private var pairTimeout: Task<Void,Never>?
    private var wakeConnection: NWConnection?
    var pictureModePending:Bool {modeSettling || queuedPicture["pictureMode"] != nil || sendingPicture["pictureMode"] != nil}
    var hasPendingPicture:Bool {settingsBusy || pictureModePending || !queuedPicture.isEmpty || !sendingPicture.isEmpty}
    var current: TVDevice? { devices.first { $0.id == selected } }
    init(defaults:UserDefaults = .standard,persistPairing:Bool=true,socketFactory:((URL)->TVSocket)? = nil) {
        self.defaults=defaults;self.persistPairing=persistPairing
        self.socketFactory=socketFactory ?? {NativeTVSocket(url:$0)}
        autoRefreshPicture=defaults.bool(forKey:"prism.autoRefreshPicture")
        verifyPictureWrites=defaults.bool(forKey:"prism.verifyPictureWrites")
        if let data = defaults.data(forKey:"prism.devices"),let v = try? JSONDecoder().decode([TVDevice].self,from:data) { devices = v }
        if let data = defaults.data(forKey:"prism.profiles"),let v = try? JSONDecoder().decode([PictureProfile].self,from:data) { profiles = v }
        if let raw = defaults.string(forKey:"prism.selected"),let id=UUID(uuidString:raw),devices.contains(where:{$0.id==id}) { selected=id } else { selected=devices.first?.id }
    }
    func persist() {
        defaults.set(try? JSONEncoder().encode(devices),forKey:"prism.devices")
        defaults.set(try? JSONEncoder().encode(profiles),forKey:"prism.profiles")
        defaults.set(selected?.uuidString,forKey:"prism.selected")
    }
    static func isLocalIP(_ host:String)->Bool {TVProtocol.isLocalIP(host)}
    func add(name: String,host: String,mac: String) -> Bool {
        let host=host.trimmingCharacters(in:.whitespacesAndNewlines)
        guard Self.isLocalIP(host) else {status="Zadaj lokálnu IPv4 adresu, napríklad 192.168.0.110.";return false}
        if let index=devices.firstIndex(where:{$0.host==host}) {
            if !mac.isEmpty {devices[index].mac=mac}
            if !name.isEmpty && name != "LG webOS TV" {devices[index].name=name}
            select(devices[index].id);persist();return true
        }
        let d=TVDevice(name:name.isEmpty ? "LG OLED" : name,host:host,mac:mac)
        devices.append(d);select(d.id);persist();return true
    }
    func select(_ id: UUID) { if selected != id { disconnect();selected=id;persist() } }
    func remove(_ id: UUID) {
        if selected==id {disconnect()}
        if persistPairing,let d=devices.first(where:{$0.id==id}) {PairingStore.delete(d.host)}
        let wasSelected=selected==id
        devices.removeAll{$0.id==id};profiles.removeAll{$0.device==id}
        if wasSelected {selected=devices.first?.id}
        persist()
    }
    func log(_ message: String) {
        diagnostics.insert(message,at:0);if diagnostics.count>40 {diagnostics.removeLast()}
    }
    func connect() {
        guard let tv=current else {status="Najprv pridaj televízor.";return}
        disconnect();userError=nil;connecting=true;status="Pripájam \(tv.name)…"
        guard Self.isLocalIP(tv.host),let url=URL(string:"ws://\(tv.host):3000") else {connecting=false;return}
        let token=epoch
        let ws=socketFactory(url);socket=ws;ws.connect()
        receiver=Task { [weak self] in
            do {
                while !Task.isCancelled {
                    let message=try await ws.receive()
                    guard let self=self,self.epoch==token else{return}
                    self.handle(message)
                }
            } catch {
                guard let self=self,self.epoch==token,!Task.isCancelled else{return}
                self.disconnect();self.status="Spojenie sa prerušilo. Skontroluj Wi-Fi, zapnutie TV a IP adresu.";self.userError=self.status;self.log("WebSocket: \(error.localizedDescription)")
            }
        }
        let permissions=["LAUNCH","LAUNCH_WEBAPP","APP_TO_APP","CONTROL_AUDIO","CONTROL_DISPLAY","CONTROL_INPUT_TV","CONTROL_INPUT_MEDIA_PLAYBACK","CONTROL_INPUT_TEXT","CONTROL_MOUSE_AND_KEYBOARD","CONTROL_POWER","CONTROL_TV_SCREEN","READ_APP_STATUS","READ_INSTALLED_APPS","READ_RUNNING_APPS","READ_INPUT_DEVICE_LIST","READ_CURRENT_CHANNEL","READ_TV_CHANNEL_LIST","READ_POWER_STATE","READ_SETTINGS","WRITE_SETTINGS","WRITE_NOTIFICATION_ALERT","WRITE_NOTIFICATION_TOAST"]
        var payload:[String:Any]=["forcePairing":false,"pairingType":"PROMPT","manifest":["manifestVersion":1,"appVersion":"1.0","permissions":permissions]]
        if persistPairing,let key=PairingStore.read(tv.host) {payload["client-key"]=key}
        send(["id":"register","type":"register","payload":payload])
        pairTimeout=Task { [weak self] in
            try? await Task.sleep(nanoseconds:60_000_000_000)
            guard !Task.isCancelled,let self=self,self.epoch==token,!self.connected else{return}
            self.disconnect();self.status="Párovanie vypršalo. Potvrď požiadavku na TV a skús to znova."
        }
    }
    func forgetPairing() { if persistPairing,let host=current?.host {PairingStore.delete(host)};disconnect();status="Párovanie je zrušené. Pripoj TV a znovu potvrď požiadavku na obrazovke." }
    func disconnect() {
        epoch += 1;pointerAttempt += 1;receiver?.cancel();pointerReceiver?.cancel();pairTimeout?.cancel()
        socket?.close();pointer?.close();polling?.cancel();polling=nil;pointerQueue=[];pointerSending=false
        socket=nil;pointer=nil;connected=false;connecting=false;pointerReady=false;settingsBusy=false;presetBusy=false
        apps=[];inputs=[];volume=nil;muted=nil;foregroundApp="";invalidatePicture()
        let callbacks=Array(pending.values);pending=[:];subscriptions=[:]
        timeouts.values.forEach{$0.cancel()};timeouts=[:]
        callbacks.forEach{$0(.failure(TVFailure(message:"Odpojené")))}
        status="Odpojené"
    }
    private func send(_ object:[String:Any]) {
        guard let ws=socket,let data=try? JSONSerialization.data(withJSONObject:object),let text=String(data:data,encoding:.utf8) else{return}
        let token=epoch
        Task { [weak self] in
            do {try await ws.send(text)}
            catch {guard let self=self,self.epoch==token else{return};self.status="Príkaz sa nepodarilo odoslať.";self.log(error.localizedDescription)
                let id=TVProtocol.messageID(object["id"])
                self.timeouts.removeValue(forKey:id)?.cancel()
                self.pending.removeValue(forKey:id)?(.failure(error))}
        }
    }
    private func handle(_ data:Data) {
        guard let obj=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{return}
        let type=obj["type"] as? String ?? "",id=TVProtocol.messageID(obj["id"])
        let payload=obj["payload"] as? [String:Any] ?? [:]
        if type=="registered" {
            guard !connected else{return}
            if persistPairing,let key=payload["client-key"] as? String,let host=current?.host {PairingStore.save(key,host:host)}
            pairTimeout?.cancel();connected=true;connecting=false;status="Pripojené k \(current?.name ?? "TV")";refresh();return
        }
        if id=="register",type=="response" {status="Potvrď párovanie na obrazovke televízora.";return}
        if type=="error" || (payload["returnValue"] as? Bool)==false {
            let error=(obj["error"] as? String) ?? (payload["errorText"] as? String) ?? "TV požiadavku odmietla."
            log(error)
            if id=="register" {disconnect();status="Párovanie bolo odmietnuté. Zruš uložené párovanie a skús to znova.";return}
            timeouts.removeValue(forKey:id)?.cancel()
            if let cb=pending.removeValue(forKey:id) {cb(.failure(TVFailure(message:error)))}
            subscriptions.removeValue(forKey:id)
            return
        }
        timeouts.removeValue(forKey:id)?.cancel()
        if let cb=pending.removeValue(forKey:id) {cb(.success(payload))}
        subscriptions[id]?(payload)
    }
    func request(_ uri:String,payload:[String:Any]=[:],timeout:UInt64=10,completion:@escaping(Result<[String:Any],Error>)->Void) {
        guard connected else {completion(.failure(TVFailure(message:"Najprv pripoj televízor.")));return}
        counter += 1;let id="r\(counter)"
        let token=epoch
        pending[id]={[weak self] result in guard self?.epoch==token else{return};completion(result)}
        send(TVProtocol.request(id:id,uri:uri,payload:payload))
        timeouts[id]=Task { [weak self] in
            try? await Task.sleep(nanoseconds:timeout*1_000_000_000)
            guard !Task.isCancelled,let self=self,let cb=self.pending.removeValue(forKey:id) else{return}
            self.timeouts.removeValue(forKey:id);cb(.failure(TVFailure(message:"Televízor neodpovedal včas.")))
        }
    }
    private func subscribe(_ uri:String,callback:@escaping([String:Any])->Void) {
        counter += 1;let id="s\(counter)";subscriptions[id]=callback
        send(["id":id,"type":"subscribe","uri":"ssap://"+uri,"payload":[:]])
    }
    func command(_ uri:String,payload:[String:Any]=[:],success:String="Príkaz odoslaný.") {
        request(uri,payload:payload) { [weak self] r in
            switch r {
            case .success:
                self?.userError=nil;self?.status=success
                if uri.hasPrefix("audio/") {self?.readVolume()}
                if uri=="tv/switchInput" || uri=="com.webos.applicationManager/launch" {
                    self?.invalidatePicture();if self?.autoRefreshPicture==true {self?.readPicture()}
                }
            case .failure(let e):self?.showError(e)
            }
        }
    }
    func refresh() {
        guard connected else{return}
        request("system/getSystemInfo") { [weak self] r in if case .success(let p)=r,let name=p["modelName"] as? String {self?.model=name} }
        request("com.webos.applicationManager/listApps") { [weak self] r in
            if case .success(let p)=r,let list=p["apps"] as? [[String:Any]] {self?.apps=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVApp(id:id,title:v["title"] as? String ?? id)}.sorted{$0.title.localizedCaseInsensitiveCompare($1.title) == ComparisonResult.orderedAscending}}
        }
        request("tv/getExternalInputList") { [weak self] r in
            if case .success(let p)=r,let list=p["devices"] as? [[String:Any]] {self?.inputs=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVInput(id:id,title:v["label"] as? String ?? id)}}
        }
        subscribe("com.webos.applicationManager/getForegroundAppInfo") { [weak self] p in
            guard let self=self,let app=p["appId"] as? String,app != self.foregroundApp else{return}
            guard !app.isEmpty else{return}
            let firstReply=self.foregroundApp.isEmpty
            self.foregroundApp=app
            if !firstReply {self.invalidatePicture();if self.autoRefreshPicture {self.readPicture()}}
        }
        subscribe("audio/getVolume") { [weak self] p in
            self?.acceptVolume(p)
        }
        reconnectPointer()
        readPicture();startPolling()
    }
    func reconnectPointer(){
        guard connected else{return}
        pointerAttempt += 1;let attempt=pointerAttempt
        pointer?.close();pointerReady=false;pointerQueue=[];pointerSending=false
        request("com.webos.service.networkinput/getPointerInputSocket"){[weak self] result in
            guard let self=self,self.pointerAttempt==attempt else{return}
            if case .success(let payload)=result,let path=payload["socketPath"] as? String,let url=URL(string:path),url.scheme=="ws",url.host==self.current?.host {self.openPointer(url)}
            else {self.status="TV odmietla navigáciu. V nastaveniach TV zruš párovanie a pripoj ju znova."}
        }
    }
    private func openPointer(_ url:URL){
        pointerReceiver?.cancel();pointer?.close();pointerReady=false;pointerQueue=[];pointerSending=false
        let p=socketFactory(url),token=epoch
        pointer=p
        p.onOpen={[weak self,weak p] in guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=true;self.drainPointer()}
        p.onClose={[weak self,weak p] in guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=false}
        p.connect()
        pointerReceiver=Task{[weak self] in
            do {while !Task.isCancelled {_=try await p.receive()}}
            catch {guard let self=self,self.epoch==token,self.pointer === p,!Task.isCancelled else{return};self.pointerReady=false}
        }
    }
    func button(_ name:String){pointerSend(TVProtocol.button(name))}
    func move(dx:Int,dy:Int){pointerSend("type:move\ndx:\(dx)\ndy:\(dy)\ndown:0\n\n")}
    func click(){pointerSend("type:click\n\n")}
    private func pointerSend(_ text:String){
        guard connected,pointerReady else{status="Navigácia nie je pripravená. Ťukni na Opraviť navigáciu.";return}
        guard pointerQueue.count<32 else{status="Ovládač je zaneprázdnený. Skús to o chvíľu.";return}
        pointerQueue.append(text);drainPointer()
    }
    private func drainPointer(){
        guard !pointerSending,connected,pointerReady,let p=pointer,!pointerQueue.isEmpty else{return}
        pointerSending=true;let text=pointerQueue.removeFirst(),token=epoch
        Task{[weak self] in
            do {try await p.send(text)}
            catch {guard let self=self,self.epoch==token,self.pointer === p else{return};self.pointerReady=false;self.pointerQueue=[];self.status="Navigácia sa odpojila. Ťukni na Opraviť navigáciu."}
            guard let self=self,self.epoch==token,self.pointer === p else{return}
            self.pointerSending=false;self.drainPointer()
        }
    }
    func invalidatePicture(){
        modeSettleTask?.cancel();modeSettleTask=nil;modeSettling=false
        writeWorker?.cancel();writeWorker=nil;writeQueue=[];queuedPicture=[:];sendingPicture=[:];failedPicture=[:];readGeneration=[:]
        contextRevision += 1;picture=[:];verifiedKeys=[];requestedPicture=[:];pictureReadAt=[:];unavailableKeys=[:];readingKeys=[];readQueue=[];readsInFlight=0
    }
    func readPicture(keys:[String]=["backlight","contrast","brightness","color"],force:Bool=true,priority:Bool=false){
        guard connected else{return}
        if priority {
            let queued=keys.filter{readQueue.contains($0)}
            readQueue.removeAll{queued.contains($0)};readQueue.insert(contentsOf:queued,at:0)
        }
        for key in keys where !readingKeys.contains(key) {
            if !force,let time=pictureReadAt[key],Date().timeIntervalSince(time)<5 {continue}
            readingKeys.insert(key);unavailableKeys.removeValue(forKey:key);if priority {readQueue.insert(key,at:0)}else{readQueue.append(key)}
        }
        pumpReads()
    }
    private func pumpReads(){
        guard connected else{return}
        while readsInFlight<3,!readQueue.isEmpty {
            let key=readQueue.removeFirst(),revision=contextRevision,token=epoch
            let generation=readGeneration[key,default:0]
            readsInFlight += 1
            readOne(key,currentApp:false){[weak self] value,error in
                guard let self=self,self.epoch==token,self.contextRevision==revision else{return}
                self.readsInFlight -= 1
                guard self.readGeneration[key,default:0]==generation else{self.pumpReads();return}
                self.readingKeys.remove(key)
                if let value=value {self.picture[key]=value;self.verifiedKeys.insert(key);self.pictureReadAt[key]=Date();self.unavailableKeys.removeValue(forKey:key)}
                else {self.picture.removeValue(forKey:key);self.verifiedKeys.remove(key);self.pictureReadAt.removeValue(forKey:key);self.unavailableKeys[key]=error ?? "TV túto hodnotu neposkytla."}
                self.pumpReads()
            }
        }
    }
    private func readOne(_ key:String,currentApp:Bool,completion:@escaping(String?,String?)->Void){
        let revision=contextRevision,token=epoch
        var payload:[String:Any]=["category":"picture","keys":[key]]
        if currentApp {payload["current_app"]=true}
        request("settings/getSystemSettings",payload:payload,timeout:3){[weak self] result in
            guard let self=self,self.epoch==token,self.contextRevision==revision else{return}
            if case .success(let data)=result,let value=TVProtocol.pictureValues(data,allowed:[key])[key] {completion(value,nil)}
            else if !currentApp {self.readOne(key,currentApp:true,completion:completion)}
            else {
                let message:String
                switch result {case .failure(let error):message=error.localizedDescription;case .success:message="TV toto nastavenie nevrátila."}
                completion(nil,message)
            }
        }
    }
    func watchPicture(keys:[String]){watchedKeys=keys}
    func saveReadPreferences(){
        defaults.set(autoRefreshPicture,forKey:"prism.autoRefreshPicture")
        defaults.set(verifyPictureWrites,forKey:"prism.verifyPictureWrites")
        if autoRefreshPicture {startPolling()}else{stopPolling()}
    }
    func startPolling(){
        polling?.cancel();polling=nil
        guard connected,autoRefreshPicture else{return}
        polling=Task{[weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds:8_000_000_000)
                guard !Task.isCancelled,let self=self,self.connected else{return}
                self.readPicture(keys:self.watchedKeys,force:false);self.readVolume()
            }
        }
    }
    func stopPolling(){polling?.cancel();polling=nil}
    func readVolume(){request("audio/getVolume"){[weak self] result in if case .success(let p)=result {self?.acceptVolume(p)}}}
    private func acceptVolume(_ payload:[String:Any]){
        let value=payload["volumeStatus"] as? [String:Any] ?? payload
        if let number=value["volume"] as? NSNumber {volume=(0...100).contains(number.doubleValue) ? number.doubleValue : nil}
        if let mute=value["mute"] as? Bool ?? value["muted"] as? Bool ?? value["muteStatus"] as? Bool {muted=mute}
    }
    func toggleMute(){
        if let value=muted {command("audio/setMute",payload:["mute":!value])}
        else {request("audio/getVolume"){[weak self] result in
            guard let self=self else{return}
            if case .success(let p)=result {self.acceptVolume(p)}
            guard let value=self.muted else{self.status="TV nevrátila stav stlmenia.";return}
            self.command("audio/setMute",payload:["mute":!value])
        }}
    }
    func writePicture(_ settings:[String:String],completion:((Bool)->Void)?=nil) {
        guard connected,!settingsBusy,!settings.isEmpty else{completion?(false);return}
        for (key,value) in settings {
            if let range=PictureSetting.all.first(where:{$0.key==key})?.range {
                guard let number=Double(value),number.isFinite,range.contains(number),number.rounded()==number else{status="Scéna obsahuje neplatnú číselnú hodnotu.";completion?(false);return}
            }
        }
        settingsBusy=true
        let writeContext=contextRevision
        request("settings/setSystemSettings",payload:["category":"picture","settings":settings]) { [weak self] r in
            guard let self=self else{completion?(false);return}
            guard self.contextRevision==writeContext else{self.settingsBusy=false;self.status="Počas zmeny sa zmenil vstup. Skontroluj obraz na TV.";completion?(false);return}
            switch r {
            case .success:self.accepted(settings);completion?(true)
            case .failure(let error):
                if self.useLunaFallback {self.lunaWrite(settings,completion:completion)}
                else {self.settingsBusy=false;self.showError(error);completion?(false)}
            }
        }
    }
    func enqueuePicture(key:String,value:String) {
        guard !pictureModePending else{status="Počkaj na dokončenie zmeny obrazového režimu.";return}
        guard connected,!presetBusy,let setting=PictureSetting.all.first(where:{$0.key==key}) else{return}
        let value=key=="blackLevel" ? TVProtocol.blackLevelValue(value) : value
        if let range=setting.range {
            guard let number=Double(value),number.isFinite,number.rounded()==number,range.contains(number) else{return}
        } else if !setting.options.contains(value) {return}
        queuedPicture[key]=value;failedPicture.removeValue(forKey:key)
        if !writeQueue.contains(key) {writeQueue.append(key)}
        guard writeWorker==nil else{return}
        let token=epoch,revision=contextRevision
        writeWorker=Task{[weak self] in
            try? await Task.sleep(nanoseconds:150_000_000)
            while !Task.isCancelled {
                guard let self=self,self.epoch==token,self.contextRevision==revision,self.connected else{return}
                if self.settingsBusy || self.presetBusy {try? await Task.sleep(nanoseconds:80_000_000);continue}
                guard !self.writeQueue.isEmpty else{self.writeWorker=nil;return}
                let key=self.writeQueue.removeFirst()
                guard let value=self.queuedPicture.removeValue(forKey:key) else{continue}
                self.sendingPicture[key]=value
                self.writePicture([key:value]){[weak self] ok in
                    guard let self=self,self.epoch==token,(self.contextRevision==revision || (ok && key=="pictureMode" && self.contextRevision==revision+1)) else{return}
                    self.sendingPicture.removeValue(forKey:key)
                    if !ok {self.failedPicture[key]=self.status}
                }
            }
        }
    }
    private func accepted(_ values:[String:String]){
        if values["pictureMode"] != nil {
            invalidatePicture();modeSettling=true
            let token=epoch,revision=contextRevision
            modeSettleTask=Task{[weak self] in
                try? await Task.sleep(nanoseconds:1_200_000_000)
                guard !Task.isCancelled,let self=self,self.epoch==token,self.contextRevision==revision else{return}
                self.modeSettling=false;self.modeSettleTask=nil
            }
        }
        for(key,value) in values {
            readGeneration[key,default:0] += 1
            readQueue.removeAll{$0==key};readingKeys.remove(key)
            requestedPicture[key]=value;picture.removeValue(forKey:key);verifiedKeys.remove(key);pictureReadAt.removeValue(forKey:key)
        }
        settingsBusy=false;status=verifyPictureWrites ? "Odoslané · overujem z TV." : "Odoslané · bez overenia."
        if verifyPictureWrites {readPicture(keys:Array(values.keys),priority:true)}
    }
    private func lunaWrite(_ values:[String:String],completion:((Bool)->Void)?=nil) {
        let writeContext=contextRevision
        let uri="luna://com.webos.settingsservice/setSystemSettings"
        let params:[String:Any]=["category":"picture","settings":values]
        let body:[String:Any]=["message":" ","buttons":[["label":"","onClick":uri,"params":params]],"onclose":["uri":uri,"params":params],"onfail":["uri":uri,"params":params]]
        request("system.notifications/createAlert",payload:body) { [weak self] r in
            guard let self=self else{completion?(false);return}
            guard case .success(let p)=r,let alert=p["alertId"] as? String else {self.settingsBusy=false;self.status="Firmvér TV odmietol zápis obrazu.";completion?(false);return}
            self.request("system.notifications/closeAlert",payload:["alertId":TVProtocol.closeAlertID(alert)]) { [weak self] result in
                guard let self=self else{completion?(false);return}
                guard self.contextRevision==writeContext else{self.settingsBusy=false;self.status="Počas zmeny sa zmenil vstup. Skontroluj obraz na TV.";completion?(false);return}
                if case .success=result {self.accepted(values);completion?(true)}
                else {self.settingsBusy=false;self.status="Zmenu obrazu sa nepodarilo dokončiť.";completion?(false)}
            }
        }
    }
    func applyRecommended(_ preset:B9Preset,whiteBalance:String?) {
        applySettingsInOrder(preset.values(whiteBalance:whiteBalance),name:preset.name)
    }
    func applyProfile(_ profile:PictureProfile){
        guard profile.device==selected else{status="Táto scéna patrí inému televízoru.";return}
        applySettingsInOrder(profile.settings,name:profile.name)
    }
    private func applySettingsInOrder(_ values:[String:String],name:String){
        guard connected,!hasPendingPicture,!presetBusy,!values.isEmpty else{status="Počkaj na dokončenie prebiehajúcej zmeny.";return}
        let token=epoch,initialContext=contextRevision
        presetBusy=true;status="Odosielam scénu \(name)…"
        guard let mode=values["pictureMode"] else {
            writePicture(values){[weak self] ok in
                guard let self=self,self.epoch==token else{return}
                self.presetBusy=false
                if ok {self.status="Scéna \(name) odoslaná."}
            }
            return
        }
        writePicture(["pictureMode":mode]){[weak self] ok in
            guard let self=self,self.epoch==token else{return}
            guard ok,self.contextRevision==initialContext+1 else{self.presetBusy=false;self.status="Scéna zastavená: režim alebo vstup sa nepodarilo zmeniť.";return}
            let revision=self.contextRevision
            Task{[weak self] in
                try? await Task.sleep(nanoseconds:1_200_000_000)
                guard let self=self,self.epoch==token,self.connected else{return}
                guard self.contextRevision==revision else{self.presetBusy=false;self.status="Scéna zastavená: vstup sa zmenil.";return}
                if let observed=self.picture["pictureMode"],observed != mode {self.presetBusy=false;self.status="Scéna zastavená: TV vrátila iný obrazový režim.";return}
                var rest=values;rest.removeValue(forKey:"pictureMode")
                if rest.isEmpty {self.presetBusy=false;self.status="Obrazový režim odoslaný.";return}
                self.writePicture(rest){[weak self] finished in
                    guard let self=self,self.epoch==token else{return}
                    self.presetBusy=false
                    self.status=finished ? "Scéna \(name) odoslaná. Overenie závisí od nastavenia čítania." : "Scéna je neúplná. Skontroluj obraz na TV."
                }
            }
        }
    }
    func setHDMIType(input:String,pc:Bool) {
        guard connected,!hasPendingPicture,!presetBusy else{return}
        settingsBusy=true
        let uri="luna://com.webos.service.eim/setDeviceInfo"
        let params:[String:Any]=["id":input,"icon":pc ? "pc.png" : "hdmi.png","label":pc ? "PC" : "HDMI"]
        let body:[String:Any]=["message":" ","buttons":[["label":"","onClick":uri,"params":params]],"onclose":["uri":uri,"params":params],"onfail":["uri":uri,"params":params]]
        request("system.notifications/createAlert",payload:body) { [weak self] r in
            guard let self=self else{return}
            guard case .success(let p)=r,let id=p["alertId"] as? String else{self.settingsBusy=false;self.status="TV odmietla zmenu typu HDMI.";return}
            self.request("system.notifications/closeAlert",payload:["alertId":TVProtocol.closeAlertID(id)]) { [weak self] result in
                guard let self=self else{return};self.settingsBusy=false
                if case .success=result {self.status="Typ HDMI odoslaný. Skontroluj ho na TV."} else {self.status="Zmena typu HDMI zlyhala."}
            }
        }
    }
    func makeSceneDraft(includeSelection:Bool)->SceneDraft? {
        guard let device=selected else{return nil}
        var values=picture
        if includeSelection {
            values.merge(requestedPicture){_,new in new}
            values.merge(sendingPicture){_,new in new}
            values.merge(queuedPicture){_,new in new}
        }
        guard !values.isEmpty else{return nil}
        let confirmed=Set(values.compactMap{key,value -> String? in
            guard let observed=picture[key],pictureReadAt[key] != nil else{return nil}
            let matches=key=="blackLevel" ? TVProtocol.blackLevelValue(observed)==TVProtocol.blackLevelValue(value) : TVProtocol.pictureMatches(observed,value)
            return matches ? key : nil
        })
        return SceneDraft(device:device,context:contextRevision,settings:values,confirmedKeys:confirmed,sourceInput:foregroundApp)
    }
    @discardableResult func saveProfile(_ name:String,includeSelection:Bool=false)->Bool {
        guard let draft=makeSceneDraft(includeSelection:includeSelection) else{status="Nie sú dostupné hodnoty na uloženie.";return false}
        return saveProfile(name,draft:draft)
    }
    @discardableResult func saveProfile(_ name:String,draft:SceneDraft)->Bool {
        guard selected==draft.device,contextRevision==draft.context else{status="Vstup sa zmenil. Otvor nový náhľad scény.";return false}
        let cleanName=name.trimmingCharacters(in:.whitespacesAndNewlines)
        profiles.append(PictureProfile(name:cleanName.isEmpty ? "Moja scéna" : cleanName,device:draft.device,settings:draft.settings,confirmed:draft.confirmedKeys.count==draft.settings.count,confirmedKeys:draft.confirmedKeys,sourceInput:draft.sourceInput))
        persist();status="Scéna uložená: \(draft.settings.count) hodnôt.";return true
    }
    func sendText(_ text:String,completion:@escaping(Bool)->Void) {
        guard !text.isEmpty else{completion(false);return}
        request("com.webos.service.ime/insertText",payload:["text":text,"replace":0]){[weak self] result in
            switch result {
            case .success:self?.userError=nil;self?.status="Text odoslaný do TV.";completion(true)
            case .failure(let error):self?.showError(error);completion(false)
            }
        }
    }
    private func showError(_ error:Error){
        log(error.localizedDescription)
        status=error is URLError ? "Spojenie zlyhalo. Skontroluj Wi-Fi a skús to znova." : "TV požiadavku odmietla. Podrobnosti sú v diagnostike."
        userError=status
    }
    func deleteProfile(_ id:UUID) {profiles.removeAll{$0.id==id};persist()}
    func wake() {
        guard let tv=current else{return}
        guard let packet=TVProtocol.wakePacket(tv.mac) else {status="Pre prebudenie doplň platnú MAC adresu televízora.";return}
        wakeConnection?.cancel()
        let c=NWConnection(host:NWEndpoint.Host(tv.host),port:9,using:.udp);wakeConnection=c
        c.stateUpdateHandler={ [weak self] state in if case .ready=state {c.send(content:packet,completion:.contentProcessed{error in Task { @MainActor in self?.status=error==nil ? "Prebudenie odoslané. O chvíľu skús pripojenie." : "Prebudenie sa nepodarilo odoslať.";c.cancel()}})} }
        c.start(queue:.main)
        status="Odosielam prebudenie…"
        Task {try? await Task.sleep(nanoseconds:4_000_000_000);c.cancel()}
    }
}

