import SwiftUI

private enum Ink {
    static let backdrop=LinearGradient(colors:[Color(red:0.07,green:0.15,blue:0.16),Color(red:0.035,green:0.065,blue:0.085),Color(red:0.035,green:0.045,blue:0.065)],startPoint:.topLeading,endPoint:.bottomTrailing)
    static let background=Color(red:0.045,green:0.05,blue:0.055)
    static let surface=Color(red:0.075,green:0.105,blue:0.12)
    static let raised=Color(red:0.12,green:0.16,blue:0.17)
    static let lime=Color(red:0.74,green:0.94,blue:0.39)
    static let secondary=Color(red:0.66,green:0.71,blue:0.72)
}
private struct PrismGlass:ViewModifier {
    var radius:CGFloat=24
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @ViewBuilder func body(content:Content)->some View {
        if reduceTransparency {
            content.background(Ink.surface,in:RoundedRectangle(cornerRadius:radius))
        } else if #available(iOS 26.0,*) {
            content.glassEffect(.regular,in:RoundedRectangle(cornerRadius:radius))
        } else {
            content.background(.ultraThinMaterial,in:RoundedRectangle(cornerRadius:radius))
                .overlay(RoundedRectangle(cornerRadius:radius).stroke(Color.white.opacity(0.12),lineWidth:0.5))
        }
    }
}
private struct ControlStyle:ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    var accent=false
    func makeBody(configuration:Configuration)->some View {
        configuration.label.font(.body.weight(.semibold)).frame(minHeight:52)
            .frame(maxWidth:.infinity).contentShape(Rectangle())
            .foregroundStyle(accent ? Ink.background : Color.white)
            .background(accent ? Ink.lime : Ink.raised,in:RoundedRectangle(cornerRadius:16))
            .overlay(RoundedRectangle(cornerRadius:16).stroke(Color.white.opacity(accent ? 0 : 0.065),lineWidth:0.5))
            .opacity(!enabled ? 0.35 : (configuration.isPressed ? 0.65 : 1))
    }
}
private struct SectionLabel:View {
    let text:String
    var body:some View {Text(text.uppercased()).font(.caption.weight(.bold)).tracking(2).foregroundStyle(Ink.secondary).frame(maxWidth:.infinity,alignment:.leading).padding(.top,16)}
}
private struct Surface<Content:View>:View {
    var compact=false
    @ViewBuilder var content:Content
    var body:some View {VStack(alignment:.leading,spacing:compact ? 6 : 16){content}.padding(compact ? 12 : 20).frame(maxWidth:.infinity,alignment:.leading).background(LinearGradient(colors:[Ink.raised.opacity(0.65),Ink.surface],startPoint:.topLeading,endPoint:.bottomTrailing),in:RoundedRectangle(cornerRadius:24)).overlay(RoundedRectangle(cornerRadius:24).stroke(Color.white.opacity(0.085),lineWidth:0.5))}
}
private struct Page<Content:View>:View {
    let title:String
    let subtitle:String
    @ViewBuilder var content:Content
    var body:some View {
        ScrollView {VStack(alignment:.leading,spacing:20){
            VStack(alignment:.leading,spacing:8){Text(title).font(.largeTitle.bold());Text(subtitle).font(.subheadline).foregroundStyle(Ink.secondary)}.padding(.top,16)
            content
        }.padding(.horizontal,24).padding(.bottom,32).frame(maxWidth:620).frame(maxWidth:.infinity)}.background(Ink.backdrop)
    }
}
@main struct PrismApp:App {
    @StateObject private var tv=WebOSTV()
    var body:some Scene {WindowGroup {PrismRoot().environmentObject(tv).preferredColorScheme(.dark).tint(Ink.lime).environment(\.locale,Locale(identifier:"en"))}}
}
private enum Destination:String,CaseIterable {case remote="Remote",picture="Picture",scenes="Scenes",devices="TV"}
struct PrismRoot:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.scenePhase) private var phase
    @State private var tab:Destination = .remote
    @State private var discoveryRequested=false
    var body:some View {
        VStack(spacing:0){
            HStack(spacing:12){
                Text(tab == .picture ? "Picture" : "prism").font(.title2.weight(.bold)).tracking(-0.8)
                Spacer()
                Button{
                    if tv.connecting {tv.disconnect()}
                    else if !tv.connected,tv.current != nil {tv.connect()}
                    else {tab = .devices}
                }label:{
                    HStack(spacing:8){Circle().fill(tv.connected ? Ink.lime : Ink.secondary).frame(width:6,height:6);Text(tv.connecting ? "Cancel connection" : (tv.connected ? (tv.current?.name ?? "TV") : "Connect TV")).font(.subheadline.weight(.medium)).lineLimit(1)}.padding(.horizontal,14).frame(minHeight:44).modifier(PrismGlass(radius:24))
                }.buttonStyle(.plain).accessibilityLabel(tv.connecting ? "Cancel connection" : (tv.connected ? "Manage TVs. Connected" : "Connect TV. Disconnected"))
            }.padding(.horizontal,22).padding(.vertical,8)
            if let error=tv.userError,tv.connected,tab != .picture {
                HStack(alignment:.top,spacing:10){Image(systemName:"exclamationmark.circle");Text(error).font(.footnote).frame(maxWidth:.infinity,alignment:.leading);Button{tv.userError=nil}label:{Image(systemName:"xmark").frame(width:44,height:44)}.accessibilityLabel("Dismiss notice")}.foregroundStyle(.orange).padding(.leading,16).background(Ink.surface,in:RoundedRectangle(cornerRadius:16)).padding(.horizontal,20)
            }
            TabView(selection:$tab){
                RemotePage(onDevices:{discoveryRequested=true;tab = .devices})
                    .tabItem{Label("Remote",systemImage:"dot.radiowaves.left.and.right")}.tag(Destination.remote)
                PicturePage(onDevices:{discoveryRequested=true;tab = .devices})
                    .tabItem{Label("Picture",systemImage:"slider.horizontal.3")}.tag(Destination.picture)
                ScenesPage().tabItem{Label("Scenes",systemImage:"square.stack")}.tag(Destination.scenes)
                DevicesPage(autoSearch:discoveryRequested,onSearchStarted:{discoveryRequested=false})
                    .tabItem{Label("TV",systemImage:"tv")}.tag(Destination.devices)
            }
            .tint(Ink.lime)
        }.background(Ink.backdrop)
        .onChange(of:phase){_,state in
            if state == .active,tv.connected {tv.startPolling();tv.readVolume();if !tv.pointerReady{tv.reconnectPointer()}}
            else if state != .active {tv.stopPolling()}
        }
    }
}
private struct RemotePage:View {
    var onDevices:()->Void
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dynamicTypeSize) private var textSize
    @State private var library=false
    @State private var touchpad=false
    @State private var keyboard=false
    @State private var power=false
    var body:some View {
        ScrollView{
            VStack(alignment:.leading,spacing:16){
                HStack(alignment:.center){
                    VStack(alignment:.leading,spacing:5){Text("Remote").font(.largeTitle.bold());Text(tv.connected ? tv.model : "Connect your big screen.").font(.subheadline).foregroundStyle(Ink.secondary)}
                    Spacer()
                    Button{if tv.connected{power=true}else{tv.wake()}}label:{Image(systemName:"power").font(.title3).frame(width:48,height:48).background(Ink.raised,in:Circle())}.buttonStyle(.plain).accessibilityLabel(tv.connected ? "Turn off TV" : "Wake TV")
                }
                if !tv.connected {
                    Surface(compact:true){
                        Text(tv.status).font(.footnote).foregroundStyle(Ink.secondary)
                        Button(tv.current==nil ? "Find TV" : (tv.connecting ? "Cancel connection" : "Connect TV")){if tv.current==nil{onDevices()}else if tv.connecting{tv.disconnect()}else{tv.connect()}}.buttonStyle(ControlStyle(accent:true))
                    }
                }
                if textSize.isAccessibilitySize {
                    VStack(spacing:14){RemotePad().frame(maxWidth:300);volumeRow}
                } else {
                    ViewThatFits(in:.horizontal){
                        HStack(alignment:.center,spacing:16){RemotePad().frame(width:248);volumeColumn.frame(width:64)}.fixedSize(horizontal:true,vertical:false)
                        VStack(spacing:14){RemotePad().frame(maxWidth:300);volumeRow}
                    }.frame(maxWidth:.infinity)
                }
                if tv.connected && !tv.pointerReady {Button("Repair navigation"){tv.reconnectPointer()}.buttonStyle(ControlStyle())}
                HStack(spacing:12){nav("Back","arrow.uturn.backward","BACK");nav("Home","house","HOME");nav("Menu","gearshape","MENU")}
                HStack(spacing:12){media("play.fill","play");media("pause.fill","pause");media("stop.fill","stop")}.disabled(!tv.connected)
                Button{if tv.connected{library=true}else{onDevices()}}label:{HStack{Label("Apps & inputs",systemImage:"square.grid.2x2");Spacer();Image(systemName:"chevron.right").font(.caption)}.padding(.horizontal,16)}.buttonStyle(ControlStyle()).disabled(tv.hasPendingPicture || tv.presetBusy)
                Surface(compact:true){
                    DisclosureGroup("More controls"){
                        VStack(spacing:14){
                            HStack(spacing:12){Button{touchpad=true}label:{Label("Touchpad",systemImage:"hand.draw")};Button{keyboard=true}label:{Label("Text",systemImage:"keyboard")}}.buttonStyle(ControlStyle())
                            HStack(spacing:12){Button("Channel −"){tv.command("tv/channelDown")};Button("Channel +"){tv.command("tv/channelUp")}}.buttonStyle(ControlStyle())
                        }.padding(.top,14).disabled(!tv.connected)
                    }.font(.subheadline.weight(.medium))
                }
            }.padding(.horizontal,20).padding(.top,12).padding(.bottom,24).frame(maxWidth:580).frame(maxWidth:.infinity)
        }.background(Ink.backdrop)
        .sheet(isPresented:$library){LibrarySheet()}.sheet(isPresented:$touchpad){TouchpadSheet()}.sheet(isPresented:$keyboard){KeyboardSheet()}
        .confirmationDialog("Turn off the TV?",isPresented:$power,titleVisibility:.visible){Button("Turn off TV",role:.destructive){tv.command("system/turnOff")}}
    }
    private var volumeColumn:some View {
        VStack(spacing:10){
            volumeButton("plus","audio/volumeUp","Volume up").frame(height:68)
            Button{tv.toggleMute()}label:{VStack(spacing:5){Text(tv.volume.map{String(Int($0))} ?? "—").font(.title2.bold()).monospacedDigit();Image(systemName:tv.muted==true ? "speaker.slash.fill" : "speaker.wave.2").font(.caption)}.frame(maxWidth:.infinity,minHeight:68)}.buttonStyle(ControlStyle()).accessibilityLabel(tv.muted==true ? "Unmute" : "Mute").accessibilityValue(tv.volume.map{String(Int($0))} ?? "Volume unavailable")
            volumeButton("minus","audio/volumeDown","Volume down").frame(height:68)
        }.disabled(!tv.connected)
    }
    private var volumeRow:some View {
        HStack(spacing:12){
            volumeButton("minus","audio/volumeDown","Volume down")
            Button{tv.toggleMute()}label:{HStack(spacing:8){Image(systemName:tv.muted==true ? "speaker.slash.fill" : "speaker.wave.2");Text(tv.volume.map{String(Int($0))} ?? "—").monospacedDigit()}}.buttonStyle(ControlStyle()).accessibilityLabel(tv.muted==true ? "Unmute" : "Mute")
            volumeButton("plus","audio/volumeUp","Volume up")
        }.disabled(!tv.connected)
    }
    private func volumeButton(_ symbol:String,_ command:String,_ label:String)->some View {Button{tv.command(command)}label:{Image(systemName:symbol).font(.title3).frame(maxWidth:.infinity,minHeight:68)}.buttonStyle(ControlStyle()).accessibilityLabel(label)}
    private func nav(_ title:String,_ symbol:String,_ command:String)->some View {Button{tv.button(command)}label:{VStack(spacing:7){Image(systemName:symbol).font(.title3);Text(title).font(.caption)}.frame(maxWidth:.infinity,minHeight:60)}.buttonStyle(ControlStyle()).disabled(!tv.pointerReady)}
    private func media(_ symbol:String,_ command:String)->some View {Button{tv.command("media.controls/"+command)}label:{Image(systemName:symbol)}.buttonStyle(ControlStyle()).accessibilityLabel(["play":"Play","pause":"Pause","stop":"Stop"][command] ?? command)}
}
private struct RemotePad:View {
    @EnvironmentObject private var tv:WebOSTV
    var body:some View {
        VStack(spacing:10){
            HStack(spacing:10){Color.clear.frame(maxWidth:.infinity);key("chevron.up","UP");Color.clear.frame(maxWidth:.infinity)}
            HStack(spacing:10){key("chevron.left","LEFT");Button{tv.button("ENTER")}label:{Text("OK").font(.title3.bold()).frame(maxWidth:.infinity,minHeight:72)}.buttonStyle(ControlStyle(accent:true)).disabled(!tv.pointerReady);key("chevron.right","RIGHT")}
            HStack(spacing:10){Color.clear.frame(maxWidth:.infinity);key("chevron.down","DOWN");Color.clear.frame(maxWidth:.infinity)}
        }
    }
    private func key(_ symbol:String,_ name:String)->some View {Button{tv.button(name)}label:{Image(systemName:symbol).font(.title3.weight(.semibold)).frame(maxWidth:.infinity,minHeight:72)}.buttonStyle(ControlStyle()).disabled(!tv.pointerReady).accessibilityLabel(["UP":"Up","DOWN":"Down","LEFT":"Left","RIGHT":"Right"][name] ?? name)}
}

private struct LibrarySheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var query=""
    var body:some View {NavigationStack {List {
        Section("Inputs"){ForEach(tv.inputs){input in Button {tv.command("tv/switchInput",payload:["inputId":input.id]);dismiss()} label:{Label(input.title,systemImage:"cable.connector").frame(minHeight:48)}}}
        Section("Apps"){ForEach(tv.apps.filter{query.isEmpty || $0.title.localizedCaseInsensitiveContains(query)}){app in Button {tv.command("com.webos.applicationManager/launch",payload:["id":app.id]);dismiss()} label:{Text(app.title).frame(minHeight:48)}}}
        if tv.apps.isEmpty && tv.inputs.isEmpty {Text("Connect your TV to load apps and inputs.").foregroundStyle(Ink.secondary)}
    }.scrollContentBackground(.hidden).background(Ink.backdrop).disabled(tv.settingsBusy || tv.presetBusy || tv.pictureModePending).searchable(text:$query,prompt:"Find an app").navigationTitle("Apps & inputs").toolbar {ToolbarItem(placement:.confirmationAction){Button("Done"){dismiss()}}}}}
}
private struct TouchpadSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var previous=CGSize.zero
    @State private var last=Date.distantPast
    var body:some View {NavigationStack {VStack(spacing:24){Text("Move your finger to navigate. Tap to select.").foregroundStyle(Ink.secondary)
        RoundedRectangle(cornerRadius:32).fill(Ink.surface).overlay(Image(systemName:"hand.draw").font(.system(size:48)).foregroundStyle(Ink.secondary)).frame(height:340).contentShape(Rectangle()).onTapGesture{tv.click()}.gesture(DragGesture(minimumDistance:4).onChanged{value in
            guard Date().timeIntervalSince(last)>0.04 else{return}
            let dx=Int(value.translation.width-previous.width),dy=Int(value.translation.height-previous.height)
            previous=value.translation;last=Date();tv.move(dx:dx,dy:dy)
        }.onEnded{_ in previous = .zero})
        if !tv.pointerReady {Button("Repair navigation"){tv.reconnectPointer()}.buttonStyle(ControlStyle())}
    }.padding(24).navigationTitle("Touchpad").toolbar{ToolbarItem(placement:.confirmationAction){Button("Done"){dismiss()}}}.background(Ink.background)}}
}
private struct KeyboardSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var draft=KeyboardDraft()
    var body:some View {
        NavigationStack {
            VStack(alignment:.leading,spacing:20){
                Text("Open a text field on your TV first.").foregroundStyle(Ink.secondary)
                TextField("Text for TV",text:$draft.text,axis:.vertical).lineLimit(3...6).textFieldStyle(.roundedBorder).disabled(draft.sending).accessibilityLabel("Text to send to your TV")
                if let error=draft.error {Label(error,systemImage:"exclamationmark.circle").font(.footnote).foregroundStyle(.orange)}
                Button(draft.sending ? "Sending…" : (draft.error==nil ? "Send text" : "Try again")){send()}.buttonStyle(ControlStyle(accent:true)).disabled(draft.text.isEmpty || !tv.connected || draft.sending)
                Spacer()
            }.padding(24).navigationTitle("Keyboard").toolbar{ToolbarItem(placement:.confirmationAction){Button("Done"){dismiss()}}}
        }
        .onChange(of:tv.connected){_,connected in if !connected{draft.disconnected()}}
    }
    private func send(){
        guard let submission=draft.begin() else{return}
        tv.sendText(submission.text){ok in draft.finish(id:submission.id,success:ok)}
    }
}
private enum PictureGroup:String,CaseIterable {
    case basics="Picture",gaming="Gaming",advanced="Advanced",all="All"
    var keys:[String] {
        switch self {
        case .basics:return ["pictureMode","backlight","contrast","brightness","dynamicContrast","peakBrightness","gamma","blackLevel","motionEyeCare","color","colorGamut","tint","colorTemperature","whiteBalanceColorTemperature","dynamicColor","sharpness","superResolution","noiseReduction","mpegNoiseReduction","smoothGradation","realCinema","truMotionMode","truMotionJudder","truMotionBlur","motionPro"]
        case .gaming:return ["pictureMode","blackLevel","hdrDynamicToneMapping","peakBrightness","sharpness","superResolution","motionPro"]
        case .advanced:return ["energySaving","eyeComfortMode","whiteBalanceColorTemperature","colorGamut","gamma","hdrDynamicToneMapping"]
        case .all:return PictureGroup.basics.keys + ["hdrDynamicToneMapping","energySaving","eyeComfortMode"]
        }
    }
    var symbol:String {
        switch self {case .basics:return "photo.on.rectangle";case .gaming:return "gamecontroller";case .advanced:return "gearshape.2";case .all:return "slider.horizontal.3"}
    }
}
private struct PicturePage:View {
    @EnvironmentObject private var tv:WebOSTV
    var onDevices:()->Void
    @State private var group:PictureGroup = .basics
    @State private var query=""
    private var settings:[PictureSetting]{
        let list=query.isEmpty ? group.keys.compactMap{key in PictureSetting.all.first{$0.key==key}} : PictureSetting.all
        return list.filter{query.isEmpty || $0.title.localizedCaseInsensitiveContains(query) || $0.key.localizedCaseInsensitiveContains(query)}
    }
    private var showHDMI:Bool {query.isEmpty ? (group == .advanced || group == .all) : ["hdmi","vstup","pc"].contains(where:{query.localizedCaseInsensitiveContains($0)})}
    var body:some View {
        VStack(spacing:0){
            VStack(alignment:.leading,spacing:8){
                HStack(spacing:8){
                    HStack(spacing:8){
                        Image(systemName:"magnifyingglass").foregroundStyle(Ink.secondary)
                        TextField("Search settings",text:$query).frame(minHeight:44).accessibilityLabel("Search all settings")
                        if !query.isEmpty {Button{query=""}label:{Image(systemName:"xmark.circle.fill").frame(width:44,height:44)}.buttonStyle(.plain).accessibilityLabel("Clear search")}
                    }.padding(.horizontal,12).background(Ink.raised.opacity(0.7),in:RoundedRectangle(cornerRadius:14))
                    Menu{
                        Toggle("Automatic refresh",isOn:$tv.autoRefreshPicture)
                        Toggle("Read back after each change",isOn:$tv.verifyPictureWrites)
                    }label:{Image(systemName:"gearshape").frame(width:44,height:44)}.accessibilityLabel("Read preferences")
                    Button{tv.readPicture(keys:settings.map(\.key))}label:{Image(systemName:"arrow.clockwise").frame(width:44,height:44)}.disabled(!tv.connected).accessibilityLabel("Read displayed values from the TV")
                }
                ScrollView(.horizontal,showsIndicators:false){HStack(spacing:8){ForEach(PictureGroup.allCases,id:\.self){item in
                    Button{group=item}label:{Text(item.rawValue).font(.subheadline.weight(.semibold)).padding(.horizontal,16).frame(minHeight:44).foregroundStyle(group==item ? Ink.background : Ink.secondary).background(group==item ? Ink.lime : Color.clear,in:Capsule()).overlay(Capsule().stroke(Ink.secondary.opacity(group==item ? 0 : 0.15),lineWidth:1))}.buttonStyle(.plain).accessibilityAddTraits(group==item ? .isSelected : [])
                }}}
            }.padding(.horizontal,20).padding(.top,6).padding(.bottom,10)
            ScrollView{
                LazyVStack(alignment:.leading,spacing:14){
                    connection
                    if tv.pictureModePending {Label("Changing picture mode. Other controls will be available shortly.",systemImage:"hourglass").font(.footnote).foregroundStyle(Ink.secondary).padding(.vertical,8)}
                    if settings.isEmpty && !showHDMI {Text("No settings match your search.").foregroundStyle(Ink.secondary).padding(.vertical,24)}
                    ForEach(Array(settings.enumerated()),id:\.element.id){index,setting in
                        if query.isEmpty && (group == .basics || group == .all),let title=sectionTitle(setting.key),index==0 || sectionTitle(settings[index-1].key) != title {SectionLabel(text:title)}
                        InlinePictureControl(setting:setting)
                    }
                    if showHDMI {HDMITypeControl()}
                }.padding(.horizontal,20).padding(.bottom,24).frame(maxWidth:620).frame(maxWidth:.infinity)
            }.scrollDismissesKeyboard(.interactively).id(group.rawValue+"|"+query)
        }.background(Ink.backdrop)
        .onAppear{watch()}.onChange(of:group){_,_ in watch()}.onChange(of:query){_,_ in watch()}
        .onChange(of:tv.connected){_,_ in watch()}.onChange(of:tv.contextID){_,_ in watch()}
        .onChange(of:tv.autoRefreshPicture){_,_ in tv.saveReadPreferences()}.onChange(of:tv.verifyPictureWrites){_,_ in tv.saveReadPreferences()}
    }
    @ViewBuilder private var connection:some View {
        if !tv.connected {Surface(compact:true){
            Text(tv.connecting ? "Connecting…" : "TV disconnected").font(.headline)
            Text(tv.status).font(.footnote).foregroundStyle(Ink.secondary)
            Button(tv.connecting ? "Cancel connection" : "Connect TV"){if tv.connecting{tv.disconnect()}else if tv.current != nil{tv.connect()}else{onDevices()}}.buttonStyle(ControlStyle(accent:true))
        }}
    }
    private func watch(){tv.watchPicture(keys:settings.map(\.key))}
    private func sectionTitle(_ key:String)->String? {
        if key=="pictureMode"{return nil}
        if ["backlight","contrast","brightness","dynamicContrast","peakBrightness","gamma","blackLevel","motionEyeCare"].contains(key){return "Brightness & range"}
        if ["color","colorGamut","tint","colorTemperature","whiteBalanceColorTemperature","dynamicColor"].contains(key){return "Color"}
        if ["sharpness","superResolution","noiseReduction","mpegNoiseReduction","smoothGradation"].contains(key){return "Clarity"}
        return "Motion & advanced"
    }
}

private func display(_ value:String,key:String)->String {PictureSetting.label(value,key:key)}

private struct InlinePictureControl:View {
    @EnvironmentObject private var tv:WebOSTV
    let setting:PictureSetting
    @State private var draft:Double?
    @State private var dragging=false
    @Environment(\.dynamicTypeSize) private var textSize
    @State private var information=false
    @State private var exact=""
    @State private var showExact=false
    private var actual:String? {tv.picture[setting.key]}
    private var actualNumber:Double? {
        guard let text=actual,let number=Double(text),number.isFinite,let range=setting.range,range.contains(number) else{return nil}
        return number
    }
    private var requested:String? {tv.queuedPicture[setting.key] ?? tv.sendingPicture[setting.key] ?? tv.requestedPicture[setting.key]}
    private var proposal:Double? {
        if let draft=draft {return draft}
        if let text=tv.queuedPicture[setting.key] ?? tv.sendingPicture[setting.key],let value=Double(text) {return value}
        return actualNumber ?? requested.flatMap{text in
            guard let value=Double(text),value.isFinite,let range=setting.range,range.contains(value) else{return nil}
            return value
        }
    }
    private var enabled:Bool {tv.connected && !tv.presetBusy && !tv.pictureModePending}
    var body:some View {
        Surface(compact:true) {
            header
            if let range=setting.range {numericControl(range)}
            else if setting.key=="pictureMode" {Menu {ForEach(setting.options,id:\.self){option in Button(display(option,key:setting.key)){submit(option)}}}label:{HStack{Image(systemName:"circle.lefthalf.filled");Text((tv.queuedPicture[setting.key] ?? tv.sendingPicture[setting.key] ?? actual ?? requested).map{display($0,key:setting.key)} ?? "Choose picture mode");Spacer();Image(systemName:"chevron.down")}.font(.body).padding(.horizontal,16).frame(minHeight:56).background(Ink.raised,in:RoundedRectangle(cornerRadius:18))}.disabled(!enabled)}
            else {options}
            requestStatus
            if information {
                Text(setting.help).font(.footnote).foregroundStyle(Ink.secondary)
                readStatus
                if tv.savedSelectionKeys.contains(setting.key){Text("Saved choice from a previous session, not a live TV value.").font(.footnote).foregroundStyle(Ink.secondary)}
                if let requested=requested {Text("Last choice: \(display(requested,key:setting.key)). \(tv.verifyPictureWrites ? "Read-back is enabled." : "Sent without read-back.")").font(.footnote).foregroundStyle(Ink.secondary)}
            }
        }
        .onChange(of:actual){_,_ in if !dragging {draft=nil}}
        .onChange(of:tv.contextID){_,_ in draft=nil;dragging=false;exact="";showExact=false}
    }
    private var header:some View {
        VStack(alignment:.leading,spacing:8){
            HStack(alignment:.center,spacing:8){
                Image(systemName:setting.symbol).foregroundStyle(Ink.secondary).frame(width:22).padding(.top,2)
                Text(setting.title).font(.headline).frame(maxWidth:.infinity,alignment:.leading)
                if !textSize.isAccessibilitySize {valueBadge}
                Button{information.toggle()}label:{Image(systemName:information ? "xmark.circle" : "info.circle").frame(width:44,height:44)}.buttonStyle(.plain).foregroundStyle(Ink.secondary).accessibilityLabel("Info: \(setting.title)")
            }
            if textSize.isAccessibilitySize {valueBadge}

        }
    }
    private var valueBadge:some View {
        HStack(spacing:6){
            if setting.range != nil {Button{showExact.toggle()}label:{Text(proposal.map{String(Int($0))} ?? "—").font(.title3.bold()).monospacedDigit().foregroundStyle(.white).frame(minWidth:44,minHeight:44)}.buttonStyle(.plain).accessibilityLabel("Enter an exact value for \(setting.title)")}
            if tv.queuedPicture[setting.key] != nil || tv.sendingPicture[setting.key] != nil {ProgressView().controlSize(.mini).frame(width:14)}
            if actual != nil || requested != nil || draft != nil {
                Text(actual != nil && draft==nil && tv.queuedPicture[setting.key]==nil && tv.sendingPicture[setting.key]==nil ? "TV" : (tv.savedSelectionKeys.contains(setting.key) && draft==nil && tv.queuedPicture[setting.key]==nil && tv.sendingPicture[setting.key]==nil ? "SAVED" : "SET"))
                    .font(.caption.weight(.medium)).foregroundStyle(Ink.secondary)
            }
        }.fixedSize(horizontal:true,vertical:false)
    }
    private func numericControl(_ range:ClosedRange<Double>)->some View {
        VStack(spacing:10) {
            HStack(spacing:10) {
                stepButton(-1,range:range)
                ZStack {
                Slider(value:Binding(get:{min(range.upperBound,max(range.lowerBound,proposal ?? range.lowerBound))},set:{draft=$0}),in:range,step:1,onEditingChanged:{editing in
                    dragging=editing
                    if !editing,let value=draft {submit(String(Int(value)))}
                })
                .frame(minHeight:44).disabled(!enabled)
                .accessibilityLabel(setting.title)
                .accessibilityValue(proposal.map{String(Int($0))} ?? "Value not loaded")
                .accessibilityHint("Release the slider to send a new value.")
                .opacity(proposal==nil ? 0.01 : 1)
                if proposal==nil {
                    Capsule().fill(Ink.secondary.opacity(0.22)).frame(height:4).allowsHitTesting(false).accessibilityHidden(true)
                }
                }
                stepButton(1,range:range)
            }
            if showExact {
                HStack(spacing:12){
                    TextField("Enter value",text:$exact).keyboardType(.numbersAndPunctuation).font(.subheadline).frame(minHeight:44).accessibilityLabel("New numeric value: \(setting.title)")
                    Button("Apply"){
                        if let number=Double(exact),number.isFinite,range.contains(number),number.rounded()==number {draft=number;submit(String(Int(number)));exact="";showExact=false}
                    }.frame(minHeight:44).disabled(!enabled || !validExact(range))
                }.padding(.horizontal,12).background(Ink.background.opacity(0.4),in:RoundedRectangle(cornerRadius:12))
            }
        }
    }
    private func validExact(_ range:ClosedRange<Double>)->Bool {
        guard let number=Double(exact),number.isFinite,number.rounded()==number else{return false}
        return range.contains(number)
    }
    private func stepButton(_ delta:Int,range:ClosedRange<Double>)->some View {
        Button {
            guard let value=proposal else{return}
            let next=min(range.upperBound,max(range.lowerBound,value+Double(delta)))
            draft=next;submit(String(Int(next)))
        } label:{Image(systemName:delta<0 ? "minus" : "plus").font(.title3).frame(width:44,height:44)}
        .buttonStyle(.plain).frame(width:44,height:44).foregroundStyle(enabled ? Color.white : Ink.secondary).background(Ink.raised,in:RoundedRectangle(cornerRadius:13))
        .disabled(!enabled || proposal==nil || (delta<0 ? (proposal ?? range.lowerBound)<=range.lowerBound : (proposal ?? range.upperBound)>=range.upperBound))
        .accessibilityLabel(delta<0 ? "Decrease \(setting.title)" : "Increase \(setting.title)")
    }
    private var visibleChoice:String? {tv.queuedPicture[setting.key] ?? tv.sendingPicture[setting.key] ?? actual ?? requested}
    private var options:some View {
        Group{
            if textSize.isAccessibilitySize {
                LazyVGrid(columns:[GridItem(.adaptive(minimum:150),spacing:8)],spacing:8){ForEach(setting.options,id:\.self){option in optionButton(option)}}
            } else {
                ViewThatFits(in:.horizontal){
                    HStack(spacing:8){ForEach(setting.options,id:\.self){option in optionButton(option)}}.fixedSize(horizontal:true,vertical:false)
                    LazyVGrid(columns:[GridItem(.adaptive(minimum:78),spacing:8)],spacing:8){ForEach(setting.options,id:\.self){option in optionButton(option)}}
                }.frame(maxWidth:.infinity,alignment:.leading)
            }
        }
    }
    private func optionButton(_ option:String)->some View {
        let selected=matches(visibleChoice,option)
        return Button{submit(option)}label:{
            Text(display(option,key:setting.key)).font(.subheadline.weight(.semibold)).multilineTextAlignment(.center).padding(.horizontal,14).padding(.vertical,10).frame(minWidth:44,minHeight:48)
                .foregroundStyle(selected ? Ink.background : Color.white)
                .background(selected ? Ink.lime : Ink.raised,in:RoundedRectangle(cornerRadius:14))
                .opacity(enabled ? 1 : 0.65)
        }.buttonStyle(.plain).disabled(!enabled)
        .accessibilityLabel(option=="off" ? "Off" : (option=="on" ? "On" : display(option,key:setting.key)))
        .accessibilityValue(selected ? (actual==visibleChoice ? "Received from TV" : "My choice") : "Not selected")
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
    private var readStatus:some View {
        HStack(spacing:6) {
            if !tv.connected {Text("Not connected")}
            else if tv.readingKeys.contains(setting.key) {ProgressView().controlSize(.mini);Text("Reading from TV…")}
            else if let time=tv.pictureReadAt[setting.key] {Text("TV ·");Text(time,style:.time)}
            else if tv.unavailableKeys[setting.key] != nil {Text("The TV did not expose this value")}
            else {Text("No TV response yet")}
        }.font(.caption2).foregroundStyle(Ink.secondary)
    }
    @ViewBuilder private var requestStatus:some View {
        if let error=tv.failedPicture[setting.key] {Label(error,systemImage:"exclamationmark.circle").font(.footnote).foregroundStyle(.orange)}
        else if let value=requested,let observed=actual,!matches(observed,value),tv.queuedPicture[setting.key]==nil,tv.sendingPicture[setting.key]==nil {Label("The TV returned a different value: \(display(observed,key:setting.key))",systemImage:"exclamationmark.circle").font(.footnote).foregroundStyle(.orange)}
    }
    private func matches(_ observed:String?,_ value:String)->Bool {
        guard let observed=observed else{return false}
        if setting.key=="blackLevel" {return TVProtocol.blackLevelValue(observed)==TVProtocol.blackLevelValue(value)}
        return TVProtocol.pictureMatches(observed,value)
    }
    private func submit(_ value:String){tv.enqueuePicture(key:setting.key,value:value)}
}
private struct HDMITypeControl:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var input=""
    @State private var confirm:String?
    @State private var confirmation=false
    var body:some View {
        Surface(compact:true) {
            DisclosureGroup {
            Label("HDMI input type",systemImage:"cable.connector").font(.headline)
            Picker("Choose input",selection:$input) {
                Text("Choose an HDMI input").tag("")
                ForEach(tv.inputs.filter{$0.id.uppercased().hasPrefix("HDMI")}) {item in Text(item.title).tag(item.id)}
            }.pickerStyle(.menu).frame(minHeight:48)
            HStack(spacing:14) {
                Button("PC"){confirm="PC";confirmation=true}
                Button("HDMI"){confirm="HDMI";confirmation=true}
            }.buttonStyle(ControlStyle()).disabled(input.isEmpty || !tv.connected || tv.hasPendingPicture || tv.presetBusy)
            Text("Request a new type for the selected input. This does not show its current type. Auto range availability on the B9 can depend on the input type.").font(.footnote).foregroundStyle(Ink.secondary)
            } label:{Label("HDMI input type",systemImage:"cable.connector").font(.subheadline.weight(.medium))}
        }
        .confirmationDialog("Set \(input) ako \(confirm ?? "HDMI")?",isPresented:$confirmation,titleVisibility:.visible) {
            Button("Set \(confirm ?? "HDMI")"){tv.setHDMIType(input:input,pc:confirm=="PC")}
        }
        .onChange(of:tv.selected){_,_ in input=""}
        .onChange(of:tv.inputs.map(\.id)){_,ids in if !ids.contains(input){input=""}}
    }
}

private struct ScenesPage:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var signal:B9Signal = .sdr
    @State private var preset:B9Preset?
    @State private var draft:SceneDraft?
    @State private var profile:PictureProfile?
    @State private var confirmedOnly=false
    var body:some View {
        Page(title:"Scenes",subtitle:"Your scenes and LG B9 presets."){
            Surface {
                Text("Save a scene").font(.headline)
                Toggle("Received TV values only",isOn:$confirmedOnly)
                Text(confirmedOnly ? "Only values received from the TV will be saved." : "Save your latest choices with available TV values. Review the complete contents before saving.").font(.footnote).foregroundStyle(Ink.secondary)
                Button("Review before saving"){draft=tv.makeSceneDraft(includeSelection:!confirmedOnly)}.buttonStyle(ControlStyle(accent:true)).disabled(tv.makeSceneDraft(includeSelection:!confirmedOnly)==nil)
            }
            SectionLabel(text:"My scenes")
            if tv.profiles.filter({$0.device==tv.selected}).isEmpty {Text("You have no saved scenes yet.").foregroundStyle(Ink.secondary)}
            ForEach(tv.profiles.filter{$0.device==tv.selected}){item in
                Surface {
                    Text(item.name).font(.headline)
                    Text("\(item.settings.count) settings · \(item.confirmed==true ? "saved from a TV response" : "includes unverified choices")").font(.footnote).foregroundStyle(Ink.secondary)
                    HStack(spacing:14){
                        Button("Review & apply"){profile=item}.buttonStyle(ControlStyle()).disabled(!tv.connected || tv.hasPendingPicture || tv.presetBusy)
                        Button(role:.destructive){tv.deleteProfile(item.id)}label:{Image(systemName:"trash").frame(width:48)}.buttonStyle(ControlStyle()).frame(width:56).accessibilityLabel("Delete scene \(item.name)")
                    }
                }
            }
            SectionLabel(text:"LG B9 presets")
            Picker("Signal",selection:$signal){ForEach(B9Signal.allCases){Text($0.rawValue).tag($0)}}.pickerStyle(.segmented).frame(minHeight:48)
            ForEach(B9Preset.all.filter{$0.signal==signal}){item in
                Button{preset=item}label:{Surface{HStack(spacing:16){Image(systemName:item.symbol).font(.title).foregroundStyle(Ink.lime);VStack(alignment:.leading,spacing:6){Text(item.name).font(.headline).foregroundStyle(.white);Text(item.subtitle).font(.footnote).foregroundStyle(Ink.secondary)};Spacer();Image(systemName:"chevron.right").foregroundStyle(Ink.secondary)}}}.buttonStyle(.plain)
            }
            Text("Start content with the matching signal first. SDR, HDR10 and Dolby Vision are not detected automatically.").font(.footnote).foregroundStyle(Ink.secondary)
        }
        .sheet(item:$draft){SaveSceneSheet(draft:$0)}
        .sheet(item:$profile){ProfileSheet(profile:$0)}
        .sheet(item:$preset){PresetSheet(preset:$0)}
    }
}
private struct SaveSceneSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let draft:SceneDraft
    @State private var name=""
    private var valid:Bool {tv.selected==draft.device && tv.contextID==draft.context}
    var body:some View {
        NavigationStack{
            List{
                Section{TextField("Scene name",text:$name);Text("\(draft.settings.count) settings · \(draft.confirmedKeys.count) received from TV").font(.footnote)}
                Section("Exactly what will be saved"){
                    ForEach(draft.settings.sorted(by:{$0.key<$1.key}),id:\.key){key,value in
                        VStack(alignment:.leading,spacing:6){
                            HStack{Text(PictureSetting.all.first{$0.key==key}?.title ?? key);Spacer();Text(display(value,key:key)).foregroundStyle(Ink.lime)}
                            Text(draft.confirmedKeys.contains(key) ? "Received from TV" : "My choice · TV state unverified").font(.caption).foregroundStyle(Ink.secondary)
                        }.padding(.vertical,6)
                    }
                }
                if !valid {Text("The TV or input changed. Close this preview and open a new one.").foregroundStyle(.orange)}
            }.scrollContentBackground(.hidden).background(Ink.backdrop).navigationTitle("Scene preview").toolbar{ToolbarItem(placement:.cancellationAction){Button("Close"){dismiss()}};ToolbarItem(placement:.confirmationAction){Button("Save"){if tv.saveProfile(name,draft:draft){dismiss()}}.disabled(!valid)}}
        }
    }
}
private struct ProfileSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let profile:PictureProfile
    @State private var agreed=false
    var body:some View {
        NavigationStack{
            List{
                Section{
                    Text(profile.name).font(.title2.bold())
                    Text("Applies to the current input and signal. Picture mode is sent before the remaining values.").font(.footnote).foregroundStyle(Ink.secondary)
                }
                Section("Saved values"){
                    ForEach(profile.settings.sorted(by:{$0.key<$1.key}),id:\.key){key,value in HStack(alignment:.firstTextBaseline){Text(PictureSetting.all.first{$0.key==key}?.title ?? key);Spacer(minLength:16);Text(display(value,key:key)).foregroundStyle(Ink.secondary)}.font(.subheadline).padding(.vertical,8)}
                }
            }.scrollContentBackground(.hidden).background(Ink.backdrop)
            .safeAreaInset(edge:.bottom){
                VStack(alignment:.leading,spacing:12){
                    Toggle("Apply to the current input and signal",isOn:$agreed).font(.subheadline).frame(minHeight:44)
                    Button(tv.presetBusy ? "Sending…" : "Apply scene"){tv.applyProfile(profile)}.buttonStyle(ControlStyle(accent:true)).disabled(!agreed || !tv.connected || tv.hasPendingPicture || tv.presetBusy || tv.selected != profile.device)
                    Text(tv.status).font(.caption).foregroundStyle(Ink.secondary).lineLimit(3)
                }.padding(20).background(Ink.surface)
            }
            .navigationTitle("Custom scene").navigationBarTitleDisplayMode(.inline)
            .toolbar{ToolbarItem(placement:.confirmationAction){Button("Done"){dismiss()}}}
        }
    }
}

private struct PresetSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let preset:B9Preset
    @State private var confirmed=false
    @State private var balance="preset"
    var body:some View {
        NavigationStack{
            ScrollView{
                VStack(alignment:.leading,spacing:20){
                    HStack(spacing:12){Image(systemName:preset.symbol).font(.title).foregroundStyle(Ink.secondary);Text(preset.signal.rawValue).font(.subheadline.weight(.semibold)).foregroundStyle(Ink.secondary)}
                    Text(preset.name).font(.largeTitle.bold())
                    Text(preset.subtitle).font(.headline).foregroundStyle(Ink.secondary)
                    Text(preset.notes).font(.body).foregroundStyle(Ink.secondary)
                    Surface(compact:true){Picker("White balance",selection:$balance){Text("Preset default").tag("preset");Text("Warm 1").tag("warm1");Text("Warm 2").tag("warm2")}.pickerStyle(.menu).frame(minHeight:48)}
                    SectionLabel(text:"Values to send")
                    ForEach(preset.values(whiteBalance:balance=="preset" ? nil : balance).sorted(by:{$0.key<$1.key}),id:\.key){key,value in
                        HStack(alignment:.firstTextBaseline){Text(PictureSetting.all.first{$0.key==key}?.title ?? key);Spacer(minLength:16);Text(display(value,key:key)).foregroundStyle(Ink.secondary)}.font(.subheadline).padding(.vertical,8)
                    }
                }.padding(22)
            }.background(Ink.backdrop)
            .safeAreaInset(edge:.bottom){
                VStack(alignment:.leading,spacing:12){
                    Toggle("Currently playing \(preset.signal.rawValue)",isOn:$confirmed).font(.subheadline).frame(minHeight:44)
                    Button(tv.presetBusy ? "Sending…" : "Apply preset"){tv.applyRecommended(preset,whiteBalance:balance=="preset" ? nil : balance)}.buttonStyle(ControlStyle(accent:true)).disabled(!confirmed || !tv.connected || tv.hasPendingPicture || tv.presetBusy)
                    Text(tv.status).font(.caption).foregroundStyle(Ink.secondary).lineLimit(3)
                }.padding(20).background(Ink.surface)
            }
            .navigationTitle("LG B9 preset").navigationBarTitleDisplayMode(.inline)
            .toolbar{ToolbarItem(placement:.confirmationAction){Button("Done"){dismiss()}}}
        }
    }
}

private struct DevicesPage:View {
    var autoSearch=false
    var onSearchStarted:()->Void = {}
    @EnvironmentObject private var tv:WebOSTV
    @StateObject private var discovery=TVDiscovery()
    @State private var name="LG OLED"
    @State private var host=""
    @State private var details:TVDevice?
    @State private var log=false
    var body:some View {
        Page(title:"TVs",subtitle:"Your screens. One place."){
            ForEach(tv.devices){device in
                Surface{
                    HStack(alignment:.top,spacing:14){
                        Image(systemName:"tv").font(.title2).foregroundStyle(Ink.secondary).padding(.top,3)
                        VStack(alignment:.leading,spacing:6){
                            Text(device.name).font(.title3.bold())
                            Text(device.host).font(.caption).foregroundStyle(Ink.secondary)
                            if tv.selected==device.id {Label(tv.connected ? "Connected" : (tv.connecting ? "Connecting" : "Selected TV"),systemImage:tv.connected ? "checkmark.circle.fill" : "circle").font(.caption).foregroundStyle(Ink.secondary)}
                        }
                        Spacer()
                        Button{details=device}label:{Image(systemName:"ellipsis").frame(width:48,height:48)}.buttonStyle(.plain).accessibilityLabel("Edit \(device.name)")
                    }
                    Button(tv.selected==device.id && tv.connected ? "Disconnect" : (tv.selected==device.id && tv.connecting ? "Cancel connection" : "Connect")){
                        if tv.selected==device.id && (tv.connected || tv.connecting){tv.disconnect()}else{tv.select(device.id);tv.connect()}
                    }.buttonStyle(ControlStyle(accent:tv.selected==device.id && !tv.connected && !tv.connecting))
                }
            }
            SectionLabel(text:tv.devices.isEmpty ? "First connection" : "Add another TV")
            Surface{
                Text("Your iPhone and powered-on TV must be on the same Wi-Fi.").font(.subheadline).foregroundStyle(Ink.secondary)
                Button(discovery.searching ? "Stop search" : "Find TV"){if discovery.searching{discovery.stop()}else{discovery.start()}}.buttonStyle(ControlStyle(accent:tv.devices.isEmpty))
                if discovery.searching {ProgressView(value:discovery.progress)}
                Text(discovery.message).font(.footnote).foregroundStyle(Ink.secondary)
                if tv.connecting {Text(tv.status).font(.footnote)}
                ForEach(discovery.found){found in
                    Button{if tv.add(name:found.name,host:found.host,mac:""){discovery.stop();tv.connect()}}label:{HStack{Text(found.name);Spacer();Text(found.host).font(.caption);Image(systemName:"plus.circle")}.frame(minHeight:56)}.buttonStyle(.plain)
                }
            }
            Surface(compact:true){
                DisclosureGroup("Add by IP address"){
                    VStack(spacing:14){
                        TextField("TV name",text:$name).frame(minHeight:48)
                        TextField("192.168.0.110",text:$host).keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled().frame(minHeight:48).accessibilityLabel("TV IP address")
                        Button("Add & connect"){if tv.add(name:name,host:host,mac:""){host="";tv.connect()}}.buttonStyle(ControlStyle()).disabled(!WebOSTV.isLocalIP(host.trimmingCharacters(in:.whitespacesAndNewlines)))
                        Text("Allow Local Network access and approve pairing on the TV.").font(.footnote).foregroundStyle(Ink.secondary)
                    }.padding(.top,12)
                }.font(.subheadline.weight(.medium))
            }
            Surface(compact:true){
                DisclosureGroup("Advanced & diagnostics"){
                    VStack(alignment:.leading,spacing:16){
                        Toggle("Compatible picture writes",isOn:$tv.useLunaFallback)
                        Text("Use the webOS alert fallback when direct writes are rejected. Read-back is configured separately in Picture.").font(.footnote).foregroundStyle(Ink.secondary)
                        Button("Open diagnostics"){log=true}.frame(minHeight:44)
                        Text("Prism 2.4 · local Wi-Fi only").font(.caption).foregroundStyle(Ink.secondary)
                    }.padding(.top,12)
                }.font(.subheadline.weight(.medium))
            }
            if !tv.connected {Text(tv.status).font(.footnote).foregroundStyle(Ink.secondary)}
        }
        .onAppear{startRequestedSearch()}.onChange(of:autoSearch){_,requested in if requested{startRequestedSearch()}}
        .onDisappear{discovery.stop()}.sheet(item:$details){DeviceSheet(device:$0)}
        .sheet(isPresented:$log){NavigationStack{List{Text(tv.status);ForEach(Array(tv.diagnostics.enumerated()),id:\.offset){_,line in Text(line).font(.caption).textSelection(.enabled)}}.scrollContentBackground(.hidden).background(Ink.backdrop).navigationTitle("Diagnostics").toolbar{ToolbarItem(placement:.confirmationAction){Button("Done"){log=false}}}}}
    }
    private func startRequestedSearch(){if autoSearch{discovery.start();onSearchStarted()}}
}

private struct DeviceSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let device:TVDevice
    @State private var name=""
    @State private var mac=""
    @State private var remove=false
    var body:some View {NavigationStack {Form {
        Section("TV"){TextField("Name",text:$name);Text(device.host);TextField("MAC adresa pre Wake-on-LAN",text:$mac).textInputAutocapitalization(.never).autocorrectionDisabled()}
        Button("Save"){if let index=tv.devices.firstIndex(where:{$0.id==device.id}) {tv.devices[index].name=name.isEmpty ? device.name : name;tv.devices[index].mac=mac;tv.persist()};dismiss()}.frame(minHeight:48)
        if tv.selected==device.id {Button("Clear pairing"){tv.forgetPairing();dismiss()}.frame(minHeight:48);Button("Wake TV"){tv.wake()}.frame(minHeight:48)}
        Button("Remove TV",role:.destructive){remove=true}.frame(minHeight:48)
    }.scrollContentBackground(.hidden).background(Ink.backdrop).navigationTitle("Edit TV").toolbar{ToolbarItem(placement:.cancellationAction){Button("Close"){dismiss()}}}.onAppear{name=device.name;mac=device.mac}.confirmationDialog("Remove this TV and its scenes?",isPresented:$remove,titleVisibility:.visible){Button("Remove",role:.destructive){tv.remove(device.id);dismiss()}}}}
}
