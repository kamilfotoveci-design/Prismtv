import SwiftUI

private enum Ink {
    static let background=Color(red:0.045,green:0.05,blue:0.055)
    static let surface=Color(red:0.09,green:0.10,blue:0.105)
    static let raised=Color(red:0.14,green:0.15,blue:0.16)
    static let lime=Color(red:0.74,green:0.94,blue:0.39)
    static let secondary=Color(red:0.63,green:0.66,blue:0.65)
}
private struct ControlStyle:ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    var accent=false
    func makeBody(configuration:Configuration)->some View {
        configuration.label.font(.body.weight(.semibold)).frame(minHeight:52)
            .frame(maxWidth:.infinity).contentShape(Rectangle())
            .foregroundStyle(accent ? Ink.background : Color.white)
            .background(accent ? Ink.lime : Ink.raised,in:RoundedRectangle(cornerRadius:16))
            .opacity(!enabled ? 0.35 : (configuration.isPressed ? 0.65 : 1))
    }
}
private struct SectionLabel:View {
    let text:String
    var body:some View {Text(text.uppercased()).font(.caption.weight(.bold)).tracking(2).foregroundStyle(Ink.secondary).frame(maxWidth:.infinity,alignment:.leading).padding(.top,16)}
}
private struct Surface<Content:View>:View {
    @ViewBuilder var content:Content
    var body:some View {VStack(alignment:.leading,spacing:16){content}.padding(20).frame(maxWidth:.infinity,alignment:.leading).background(Ink.surface,in:RoundedRectangle(cornerRadius:24))}
}
private struct Page<Content:View>:View {
    let title:String
    let subtitle:String
    @ViewBuilder var content:Content
    var body:some View {
        ScrollView {VStack(alignment:.leading,spacing:20){
            VStack(alignment:.leading,spacing:8){Text(title).font(.system(size:36,weight:.bold));Text(subtitle).font(.subheadline).foregroundStyle(Ink.secondary)}.padding(.top,16)
            content
        }.padding(.horizontal,24).padding(.bottom,32).frame(maxWidth:620).frame(maxWidth:.infinity)}.background(Ink.background)
    }
}
@main struct PrismApp:App {
    @StateObject private var tv=WebOSTV()
    var body:some Scene {WindowGroup {PrismRoot().environmentObject(tv).preferredColorScheme(.dark).tint(Ink.lime)}}
}
private enum Destination:String,CaseIterable {case remote="Ovládač",picture="Obraz",scenes="Scény",devices="TV"}
struct PrismRoot:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.scenePhase) private var phase
    @State private var tab:Destination = .remote
    var body:some View {
        VStack(spacing:0){
            HStack {
                Text("prism").font(.system(size:23,weight:.black,design:.rounded)).tracking(-1)
                Spacer()
                Button {tab = .devices} label:{HStack(spacing:8){Circle().fill(tv.connected ? Ink.lime : Ink.secondary).frame(width:7,height:7);Text(tv.connected ? (tv.current?.name ?? "TV") : "Pripojiť TV").font(.subheadline.weight(.medium)).lineLimit(1)}.padding(.horizontal,14).frame(minHeight:44).background(Ink.surface,in:Capsule())}.buttonStyle(.plain)
            }.padding(.horizontal,24).padding(.vertical,8)
            Group {switch tab {case .remote:RemotePage();case .picture:PicturePage();case .scenes:ScenesPage();case .devices:DevicesPage()}}.frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack(spacing:0){
                Text(tv.status).font(.caption).foregroundStyle(Ink.secondary).lineLimit(2).frame(maxWidth:.infinity,minHeight:34).padding(.horizontal,24).accessibilityIdentifier("connectionStatus")
                HStack(spacing:4){ForEach(Destination.allCases,id:\.self){destination in
                    Button {tab=destination} label:{VStack(spacing:6){Image(systemName:symbol(destination)).font(.system(size:20,weight:.semibold));Text(destination.rawValue).font(.caption2.weight(.semibold))}.foregroundStyle(tab==destination ? Ink.lime : Ink.secondary).frame(maxWidth:.infinity,minHeight:60).contentShape(Rectangle())}.buttonStyle(.plain).accessibilityIdentifier("tab-\(destination)")
                }}.padding(.horizontal,12)
            }.background(Ink.background)
        }.background(Ink.background).onChange(of:phase){_,state in
            if state == .active,tv.connected {tv.startPolling();tv.readPicture();tv.readVolume();if !tv.pointerReady {tv.reconnectPointer()}}
            else if state != .active {tv.stopPolling()}
        }
    }
    private func symbol(_ destination:Destination)->String {switch destination {case .remote:return "dot.radiowaves.left.and.right";case .picture:return "slider.horizontal.3";case .scenes:return "square.stack";case .devices:return "tv"}}
}
private struct RemotePage:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var library=false
    @State private var touchpad=false
    @State private var keyboard=false
    @State private var power=false
    var body:some View {
        Page(title:"Take control.",subtitle:tv.connected ? tv.model : "Tvoj televízor. Jednoducho."){
            HStack(spacing:16){
                Button {library=true} label:{Label("Aplikácie",systemImage:"square.grid.2x2")}.buttonStyle(ControlStyle()).disabled(tv.settingsBusy || tv.presetBusy)
                Button {if tv.connected {power=true}else{tv.wake()}} label:{Image(systemName:"power").frame(width:56)}.buttonStyle(ControlStyle()).frame(width:64)
            }
            if !tv.connected {Surface {Text("Najprv pripoj TV").font(.title3.bold());Text("iPhone a televízor musia byť na rovnakej Wi-Fi. Pripojenie nájdeš na karte TV.").foregroundStyle(Ink.secondary);Button(tv.connecting ? "Pripája sa…" : "Pripojiť uloženú TV"){tv.connect()}.buttonStyle(ControlStyle(accent:true)).disabled(tv.current==nil || tv.connecting)}}
            VStack(spacing:14){
                HStack(spacing:14){Color.clear.frame(maxWidth:.infinity);direction("chevron.up","UP");Color.clear.frame(maxWidth:.infinity)}
                HStack(spacing:14){direction("chevron.left","LEFT");Button {tv.button("ENTER")} label:{Text("OK").font(.title3.bold())}.buttonStyle(ControlStyle(accent:true)).frame(height:76).disabled(!tv.pointerReady);direction("chevron.right","RIGHT")}
                HStack(spacing:14){Color.clear.frame(maxWidth:.infinity);direction("chevron.down","DOWN");Color.clear.frame(maxWidth:.infinity)}
            }.frame(maxWidth:360).frame(maxWidth:.infinity).padding(.vertical,10)
            if tv.connected && !tv.pointerReady {Button("Opraviť navigáciu"){tv.reconnectPointer()}.buttonStyle(ControlStyle())}
            HStack(spacing:14){nav("Späť","arrow.uturn.backward","BACK");nav("Domov","house","HOME");nav("Menu","gearshape","MENU")}
            SectionLabel(text:"Hlasitosť")
            HStack {Text(tv.volume.map{String(Int($0))} ?? "—").font(.system(size:42,weight:.bold,design:.rounded));Spacer();Text(tv.volume == nil ? "TV zatiaľ neposlala hodnotu" : (tv.muted == true ? "Stlmené" : "Hodnota z TV")).font(.caption).foregroundStyle(Ink.secondary)}
            HStack(spacing:14){
                Button {tv.command("audio/volumeDown")} label:{Image(systemName:"minus")}.buttonStyle(ControlStyle())
                Button {tv.toggleMute()} label:{Image(systemName:tv.muted == true ? "speaker.slash.fill" : "speaker.wave.2.fill")}.buttonStyle(ControlStyle())
                Button {tv.command("audio/volumeUp")} label:{Image(systemName:"plus")}.buttonStyle(ControlStyle())
            }.disabled(!tv.connected)
            HStack(spacing:14){media("play.fill","play");media("pause.fill","pause");media("stop.fill","stop")}.disabled(!tv.connected)
            SectionLabel(text:"Viac ovládania")
            HStack(spacing:14){Button {touchpad=true} label:{Label("Touchpad",systemImage:"hand.draw")};Button {keyboard=true} label:{Label("Text",systemImage:"keyboard")}}.buttonStyle(ControlStyle()).disabled(!tv.connected)
            HStack(spacing:14){Button("Kanál −"){tv.command("tv/channelDown")};Button("Kanál +"){tv.command("tv/channelUp")}}.buttonStyle(ControlStyle()).disabled(!tv.connected)
        }.sheet(isPresented:$library){LibrarySheet()}.sheet(isPresented:$touchpad){TouchpadSheet()}.sheet(isPresented:$keyboard){KeyboardSheet()}
        .confirmationDialog("Vypnúť televízor?",isPresented:$power,titleVisibility:.visible){Button("Vypnúť TV",role:.destructive){tv.command("system/turnOff")}}
    }
    private func direction(_ symbol:String,_ key:String)->some View {Button {tv.button(key)} label:{Image(systemName:symbol).font(.title2.weight(.semibold)).frame(maxWidth:.infinity,minHeight:76)}.buttonStyle(ControlStyle()).disabled(!tv.pointerReady).accessibilityLabel(key)}
    private func nav(_ title:String,_ symbol:String,_ key:String)->some View {Button {tv.button(key)} label:{VStack(spacing:8){Image(systemName:symbol).font(.title3);Text(title).font(.caption)}.frame(maxWidth:.infinity,minHeight:68)}.buttonStyle(ControlStyle()).disabled(!tv.pointerReady)}
    private func media(_ symbol:String,_ action:String)->some View {Button {tv.command("media.controls/"+action)} label:{Image(systemName:symbol)}.buttonStyle(ControlStyle()).accessibilityLabel(action)}
}
private struct LibrarySheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var query=""
    var body:some View {NavigationStack {List {
        Section("Vstupy"){ForEach(tv.inputs){input in Button {tv.command("tv/switchInput",payload:["inputId":input.id]);dismiss()} label:{Label(input.title,systemImage:"cable.connector").frame(minHeight:48)}}}
        Section("Aplikácie"){ForEach(tv.apps.filter{query.isEmpty || $0.title.localizedCaseInsensitiveContains(query)}){app in Button {tv.command("com.webos.applicationManager/launch",payload:["id":app.id]);dismiss()} label:{Text(app.title).frame(minHeight:48)}}}
        if tv.apps.isEmpty && tv.inputs.isEmpty {Text("Zoznam sa načíta po pripojení TV.").foregroundStyle(Ink.secondary)}
    }.disabled(tv.settingsBusy || tv.presetBusy).searchable(text:$query,prompt:"Nájsť aplikáciu").navigationTitle("Na veľkej obrazovke").toolbar {ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}}}
}
private struct TouchpadSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var previous=CGSize.zero
    @State private var last=Date.distantPast
    var body:some View {NavigationStack {VStack(spacing:24){Text("Posúvaj prstom. Ťuknutím vyber.").foregroundStyle(Ink.secondary)
        RoundedRectangle(cornerRadius:32).fill(Ink.surface).overlay(Image(systemName:"hand.draw").font(.system(size:48)).foregroundStyle(Ink.secondary)).frame(height:340).contentShape(Rectangle()).onTapGesture{tv.click()}.gesture(DragGesture(minimumDistance:4).onChanged{value in
            guard Date().timeIntervalSince(last)>0.04 else{return}
            let dx=Int(value.translation.width-previous.width),dy=Int(value.translation.height-previous.height)
            previous=value.translation;last=Date();tv.move(dx:dx,dy:dy)
        }.onEnded{_ in previous = .zero})
        if !tv.pointerReady {Button("Opraviť navigáciu"){tv.reconnectPointer()}.buttonStyle(ControlStyle())}
    }.padding(24).navigationTitle("Touchpad").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}.background(Ink.background)}}
}
private struct KeyboardSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var text=""
    var body:some View {NavigationStack {VStack(alignment:.leading,spacing:24){Text("Najprv otvor textové pole na TV.").foregroundStyle(Ink.secondary);TextField("Text pre TV",text:$text).textFieldStyle(.roundedBorder);Button("Odoslať text"){tv.command("com.webos.service.ime/insertText",payload:["text":text,"replace":0]);text=""}.buttonStyle(ControlStyle(accent:true)).disabled(text.isEmpty || !tv.connected);Spacer()}.padding(24).navigationTitle("Klávesnica").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}}}
}
private enum PictureGroup:String,CaseIterable {case basics="Základ",colour="Farby",clarity="Detaily",motion="Pohyb"
    var keys:[String] {switch self {
    case .basics:return ["pictureMode","backlight","contrast","brightness","gamma","blackLevel","peakBrightness","hdrDynamicToneMapping"]
    case .colour:return ["color","tint","colorTemperature","whiteBalanceColorTemperature","colorGamut","dynamicColor"]
    case .clarity:return ["sharpness","superResolution","noiseReduction","mpegNoiseReduction","smoothGradation","dynamicContrast"]
    case .motion:return ["realCinema","truMotionMode","truMotionJudder","truMotionBlur","motionEyeCare","motionPro"]}}
}
private struct PicturePage:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var group:PictureGroup = .basics
    @State private var query=""
    @State private var editing:PictureSetting?
    private var settings:[PictureSetting] {group.keys.compactMap{key in PictureSetting.all.first{$0.key==key}}.filter{query.isEmpty || $0.title.localizedCaseInsensitiveContains(query)}}
    var body:some View {
        Page(title:"Picture, your way.",subtitle:"Zobrazené hodnoty pochádzajú z odpovedí TV."){
            HStack {Image(systemName:"magnifyingglass").foregroundStyle(Ink.secondary);TextField("Hľadať v kategórii",text:$query).frame(minHeight:48)}.padding(.horizontal,16).background(Ink.surface,in:RoundedRectangle(cornerRadius:16))
            Picker("Kategória",selection:$group){ForEach(PictureGroup.allCases,id:\.self){Text($0.rawValue).tag($0)}}.pickerStyle(.menu).frame(minHeight:48).frame(maxWidth:.infinity,alignment:.leading)
            HStack {Text(tv.connected ? "Aktuálny vstup TV" : "TV nie je pripojená").font(.caption).foregroundStyle(Ink.secondary);Spacer();Button {refresh()} label:{Label("Obnoviť",systemImage:"arrow.clockwise").font(.subheadline).frame(minHeight:44)}.disabled(!tv.connected)}
            VStack(spacing:0){ForEach(settings){setting in
                Button {editing=setting} label:{HStack(spacing:16){
                    VStack(alignment:.leading,spacing:8){Text(setting.title).font(.body.weight(.semibold)).foregroundStyle(.white)
                        if let value=tv.picture[setting.key] {Text(display(value,key:setting.key)).foregroundStyle(Ink.lime).font(.subheadline)}
                        else {Text(tv.readingKeys.contains(setting.key) ? "Načítava sa…" : "TV hodnotu neposkytla").font(.caption).foregroundStyle(Ink.secondary)}
                    }
                    Spacer(minLength:8)
                    if tv.readingKeys.contains(setting.key){ProgressView().controlSize(.small)}else{Image(systemName:"chevron.right").font(.caption).foregroundStyle(Ink.secondary)}
                }.padding(.vertical,22).contentShape(Rectangle())}.buttonStyle(.plain).disabled(!tv.connected)
                if setting.id != settings.last?.id {Rectangle().fill(Ink.raised).frame(height:1)}
            }}
            Text("Dostupnosť nastavení závisí od režimu, signálu a firmvéru. „TV hodnotu neposkytla“ neznamená nulu. Požiadavka na zmenu sa overuje novým čítaním.").font(.caption).foregroundStyle(Ink.secondary)
        }.onAppear{refresh()}.onChange(of:group){_,_ in refresh()}.onChange(of:tv.connected){_,value in if value{refresh()}}.onChange(of:tv.contextID){_,_ in refresh()}.sheet(item:$editing){SettingEditor(setting:$0)}
    }
    private func refresh(){tv.watchPicture(keys:group.keys);tv.readPicture(keys:group.keys,force:false)}
}
private func display(_ value:String,key:String)->String {
    if key=="gamma" {return ["low":"1.9","medium":"2.2","high1":"2.4","high2":"BT.1886"][value] ?? value}
    return ["off":"Vypnuté","on":"Zapnuté","warm1":"Warm 1","warm2":"Warm 2","cool":"Cool","medium":"Medium","low":"Low","high":"High","expert1":"Expert Bright","expert2":"Expert Dark","hdrGame":"HDR Game","hdrCinema":"HDR Cinema","dolbyHdrCinema":"Dolby Vision Cinema","dolbyHdrCinemaBright":"Dolby Vision Cinema Home"][value] ?? value
}
private struct SettingEditor:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let setting:PictureSetting
    @State private var draft=""
    @State private var touched=false
    @State private var context=0
    private var numeric:Double? {guard let value=Double(draft),value.isFinite,let range=setting.range,range.contains(value),value.rounded()==value else{return nil};return value}
    private var valid:Bool {setting.range != nil ? numeric != nil : setting.options.contains(draft)}
    var body:some View {NavigationStack {ScrollView {VStack(alignment:.leading,spacing:24){
        Surface {
            Text("POSLEDNÁ ODPOVEĎ TV").font(.caption.weight(.bold)).tracking(1.5).foregroundStyle(Ink.secondary)
            Text(tv.picture[setting.key].map{display($0,key:setting.key)} ?? "Nedostupná").font(.title.bold())
            if let time=tv.pictureReadAt[setting.key]{Text(time,style:.time).font(.caption).foregroundStyle(Ink.secondary)}
            if tv.readingKeys.contains(setting.key){ProgressView("Čítam z TV…")}
            if let error=tv.unavailableKeys[setting.key]{Text(error).font(.caption).foregroundStyle(Ink.secondary)}
            Button("Znovu načítať"){tv.readPicture(keys:[setting.key],priority:true)}.frame(minHeight:44)
        }
        if let requested=tv.requestedPicture[setting.key] {
            VStack(alignment:.leading,spacing:8){
                Text("Posledná požiadavka: \(display(requested,key:setting.key))").font(.caption).foregroundStyle(Ink.secondary)
                if let observed=tv.picture[setting.key] {
                    let matched=TVProtocol.pictureMatches(observed,requested)
                    Label(matched ? "Potvrdené odpoveďou TV" : "TV vrátila inú hodnotu. Zmena nie je potvrdená.",systemImage:matched ? "checkmark.circle" : "exclamationmark.circle").font(.footnote).foregroundStyle(matched ? Ink.lime : Color.orange)
                } else if !tv.readingKeys.contains(setting.key) {Text("Bez čítania z TV nevieme zmenu potvrdiť.").font(.footnote).foregroundStyle(.orange)}
            }
        }
        SectionLabel(text:"Nová požiadavka")
        if let range=setting.range {
            TextField("Zadaj hodnotu \(Int(range.lowerBound)) – \(Int(range.upperBound))",text:$draft).keyboardType(range.lowerBound<0 ? .numbersAndPunctuation : .numberPad).font(.largeTitle.bold()).padding(18).background(Ink.surface,in:RoundedRectangle(cornerRadius:16)).onChange(of:draft){_,_ in touched=true}
            if let value=numeric {
                Slider(value:Binding(get:{numeric ?? value},set:{draft=String(Int($0));touched=true}),in:range,step:1).frame(minHeight:44)
                HStack(spacing:20){Button {adjust(-1)} label:{Image(systemName:"minus")}.disabled(value<=range.lowerBound);Button {adjust(1)} label:{Image(systemName:"plus")}.disabled(value>=range.upperBound)}.buttonStyle(ControlStyle())
            } else {Text("Bez hodnoty z TV zadaj vlastné číslo. Appka nevymýšľa východiskovú hodnotu.").font(.caption).foregroundStyle(Ink.secondary)}
        } else {
            VStack(spacing:12){ForEach(setting.options,id:\.self){option in
                Button {draft=option;touched=true} label:{HStack{Text(display(option,key:setting.key));Spacer();if tv.picture[setting.key]==option {Text("TV").font(.caption).foregroundStyle(Ink.secondary)};Image(systemName:draft==option ? "checkmark.circle.fill" : "circle").foregroundStyle(draft==option ? Ink.lime : Ink.secondary)}.padding(.horizontal,18).frame(minHeight:60).background(Ink.surface,in:RoundedRectangle(cornerRadius:16))}.buttonStyle(.plain)
            }}
        }
        Button(tv.settingsBusy ? "Odosiela sa…" : "Odoslať zmenu"){tv.writePicture([setting.key:draft]);touched=false}.buttonStyle(ControlStyle(accent:true)).disabled(!valid || !tv.connected || tv.settingsBusy || tv.presetBusy || context != tv.contextID)
        Text(tv.status).font(.footnote).foregroundStyle(Ink.secondary)
    }.padding(24)}.background(Ink.background).navigationTitle(setting.title).navigationBarTitleDisplayMode(.inline).toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}
    .onAppear{context=tv.contextID;draft=tv.picture[setting.key] ?? "";tv.readPicture(keys:[setting.key],priority:true)}
    .onChange(of:tv.picture[setting.key]){_,value in if !touched {draft=value ?? ""}}
    .onChange(of:tv.contextID){_,value in context=value;draft="";touched=false;tv.readPicture(keys:[setting.key],priority:true)}}
    private func adjust(_ amount:Int){guard let value=numeric,let range=setting.range else{return};draft=String(Int(min(range.upperBound,max(range.lowerBound,value+Double(amount)))));touched=true}
}
private struct ScenesPage:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var signal:B9Signal = .sdr
    @State private var preset:B9Preset?
    @State private var name=""
    var body:some View {Page(title:"Set the mood.",subtitle:"Východiskové presety pre LG B9."){
        Picker("Signál",selection:$signal){ForEach(B9Signal.allCases){Text($0.rawValue).tag($0)}}.pickerStyle(.segmented).frame(minHeight:48)
        ForEach(B9Preset.all.filter{$0.signal==signal}){item in
            Button {preset=item} label:{Surface {HStack(alignment:.top,spacing:18){Image(systemName:item.symbol).font(.system(size:28)).foregroundStyle(Ink.lime).frame(width:40,height:48);VStack(alignment:.leading,spacing:8){Text(item.name).font(.title3.bold()).foregroundStyle(.white);Text(item.subtitle).font(.subheadline).foregroundStyle(Ink.secondary)};Spacer(minLength:0)};HStack{Text(item.signal.rawValue).font(.caption.bold()).foregroundStyle(Ink.lime);Spacer();Image(systemName:"arrow.up.right").foregroundStyle(Ink.secondary)}}}.buttonStyle(.plain)
        }
        Text("Najprv spusti obsah so správnym signálom. Appka automaticky nerozpoznáva SDR, HDR10 ani Dolby Vision. Presety sú východiská, nie meraná kalibrácia panela.").font(.caption).foregroundStyle(Ink.secondary)
        SectionLabel(text:"Tvoje uložené hodnoty")
        ForEach(tv.profiles.filter{$0.device==tv.selected}){profile in
            Surface {Text(profile.name).font(.headline);Text(profile.confirmed==true ? "\(profile.settings.count) hodnôt uložených z odpovede TV" : "Staršia scéna · pôvod hodnôt neoverený").font(.caption).foregroundStyle(Ink.secondary)
                HStack(spacing:16){Button("Použiť"){tv.writePicture(profile.settings)}.buttonStyle(ControlStyle()).disabled(!tv.connected || tv.settingsBusy || tv.presetBusy);Button(role:.destructive){tv.deleteProfile(profile.id)} label:{Image(systemName:"trash").frame(width:52)}.buttonStyle(ControlStyle()).frame(width:60)}
            }
        }
        Surface {TextField("Názov vlastnej scény",text:$name).frame(minHeight:48);Button("Uložiť prijaté hodnoty"){tv.saveProfile(name);name=""}.buttonStyle(ControlStyle()).disabled(tv.picture.isEmpty || !tv.connected);Text("Ukladajú sa iba hodnoty, ktoré TV skutočne vrátila pre aktuálny vstup.").font(.caption).foregroundStyle(Ink.secondary)}
    }.sheet(item:$preset){PresetSheet(preset:$0)}}
}
private struct PresetSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let preset:B9Preset
    @State private var confirmed=false
    @State private var balance="preset"
    var body:some View {NavigationStack {ScrollView {VStack(alignment:.leading,spacing:24){
        Image(systemName:preset.symbol).font(.system(size:44)).foregroundStyle(Ink.lime)
        Text(preset.name).font(.largeTitle.bold());Text(preset.notes).font(.body).foregroundStyle(Ink.secondary)
        Picker("Biela",selection:$balance){Text("Podľa presetu").tag("preset");Text("Warm 1").tag("warm1");Text("Warm 2").tag("warm2")}.pickerStyle(.menu).frame(minHeight:48)
        Toggle("Na TV práve prehrávam \(preset.signal.rawValue)",isOn:$confirmed).frame(minHeight:60)
        Button(tv.presetBusy ? "Odosiela sa…" : "Použiť preset"){tv.applyRecommended(preset,whiteBalance:balance=="preset" ? nil : balance)}.buttonStyle(ControlStyle(accent:true)).disabled(!confirmed || !tv.connected || tv.settingsBusy || tv.presetBusy)
        Text(tv.status).font(.footnote).foregroundStyle(Ink.secondary)
        SectionLabel(text:"Odosielané hodnoty")
        ForEach(preset.values(whiteBalance:balance=="preset" ? nil : balance).sorted(by:{$0.key<$1.key}),id:\.key){key,value in HStack{Text(PictureSetting.all.first{$0.key==key}?.title ?? key);Spacer();Text(display(value,key:key)).foregroundStyle(Ink.lime)}.font(.caption).padding(.vertical,8)}
    }.padding(24)}.background(Ink.background).navigationTitle("LG B9").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}}}
}
private struct DevicesPage:View {
    @EnvironmentObject private var tv:WebOSTV
    @StateObject private var discovery=TVDiscovery()
    @State private var name="LG OLED"
    @State private var host=""
    @State private var mac=""
    @State private var details:TVDevice?
    @State private var log=false
    var body:some View {Page(title:"Your big screen.",subtitle:"Lokálne pripojenie cez Wi-Fi. Bez účtu."){
        ForEach(tv.devices){device in Surface {
            HStack(alignment:.top){Image(systemName:"tv").font(.title).foregroundStyle(Ink.lime);VStack(alignment:.leading,spacing:6){Text(device.name).font(.title3.bold());Text(device.host).font(.caption).foregroundStyle(Ink.secondary)};Spacer();Button {details=device} label:{Image(systemName:"ellipsis").frame(width:48,height:48)}.buttonStyle(.plain)}
            Button(tv.selected==device.id && tv.connected ? "Odpojiť" : (tv.selected==device.id && tv.connecting ? "Zrušiť pripájanie" : "Pripojiť")){
                if tv.selected==device.id && (tv.connected || tv.connecting) {tv.disconnect()}else{tv.select(device.id);tv.connect()}
            }.buttonStyle(ControlStyle(accent:tv.selected==device.id))
        }}
        SectionLabel(text:"Nájsť televízor")
        Surface {Text("iPhone aj TV pripoj na rovnakú Wi-Fi. Televízor musí byť zapnutý.").foregroundStyle(Ink.secondary)
            Button(discovery.searching ? "Zastaviť hľadanie" : "Vyhľadať TV"){if discovery.searching{discovery.stop()}else{discovery.start()}}.buttonStyle(ControlStyle(accent:true))
            if discovery.searching {ProgressView(value:discovery.progress)}
            Text(discovery.message).font(.caption).foregroundStyle(Ink.secondary)
            ForEach(discovery.found){found in Button {if tv.add(name:found.name,host:found.host,mac:""){discovery.stop();tv.connect()}} label:{HStack{Text(found.name);Spacer();Text(found.host).font(.caption);Image(systemName:"plus.circle")}.frame(minHeight:56)}.buttonStyle(.plain)}
        }
        SectionLabel(text:"Alebo pridať IP adresu")
        Surface {TextField("Názov TV",text:$name).frame(minHeight:48);TextField("192.168.0.110",text:$host).keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled().frame(minHeight:48)
            Button("Pridať a pripojiť"){if tv.add(name:name,host:host,mac:mac){host="";tv.connect()}}.buttonStyle(ControlStyle()).disabled(!WebOSTV.isLocalIP(host.trimmingCharacters(in:.whitespacesAndNewlines)))
            Text("Povoľ prístup k lokálnej sieti a potvrď párovanie na obrazovke TV.").font(.caption).foregroundStyle(Ink.secondary)
        }
        Surface {Toggle("Kompatibilný zápis obrazu",isOn:$tv.useLunaFallback);Text("Ak TV odmietne priamy zápis, skúsi sa alternatívna metóda cez webOS alert. Úspech sa vždy overuje čítaním, ak ho TV sprístupní.").font(.caption).foregroundStyle(Ink.secondary);Button("Diagnostika"){log=true}.frame(minHeight:48)}
        Text("Prism 2.0 · Wi-Fi remote").font(.caption).foregroundStyle(Ink.secondary)
    }.onDisappear{discovery.stop()}.sheet(item:$details){DeviceSheet(device:$0)}.sheet(isPresented:$log){NavigationStack {List {Text(tv.status);ForEach(Array(tv.diagnostics.enumerated()),id:\.offset){_,line in Text(line).font(.caption).textSelection(.enabled)}}.navigationTitle("Diagnostika").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){log=false}}}}}}
}
private struct DeviceSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let device:TVDevice
    @State private var name=""
    @State private var mac=""
    @State private var remove=false
    var body:some View {NavigationStack {Form {
        Section("Televízor"){TextField("Názov",text:$name);Text(device.host);TextField("MAC adresa pre Wake-on-LAN",text:$mac).textInputAutocapitalization(.never).autocorrectionDisabled()}
        Button("Uložiť"){if let index=tv.devices.firstIndex(where:{$0.id==device.id}) {tv.devices[index].name=name.isEmpty ? device.name : name;tv.devices[index].mac=mac;tv.persist()};dismiss()}.frame(minHeight:48)
        if tv.selected==device.id {Button("Zrušiť párovanie"){tv.forgetPairing();dismiss()}.frame(minHeight:48);Button("Prebudiť TV"){tv.wake()}.frame(minHeight:48)}
        Button("Odstrániť TV",role:.destructive){remove=true}.frame(minHeight:48)
    }.navigationTitle("Upraviť TV").toolbar{ToolbarItem(placement:.cancellationAction){Button("Zavrieť"){dismiss()}}}.onAppear{name=device.name;mac=device.mac}.confirmationDialog("Odstrániť TV aj jej scény?",isPresented:$remove,titleVisibility:.visible){Button("Odstrániť",role:.destructive){tv.remove(device.id);dismiss()}}}}
}
