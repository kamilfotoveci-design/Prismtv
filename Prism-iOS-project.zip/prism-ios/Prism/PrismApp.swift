import SwiftUI

private enum Ink {
    static let backdrop=LinearGradient(colors:[Color(red:0.07,green:0.14,blue:0.13),Color(red:0.045,green:0.055,blue:0.08),Color(red:0.08,green:0.065,blue:0.11)],startPoint:.topLeading,endPoint:.bottomTrailing)
    static let background=Color(red:0.045,green:0.05,blue:0.055)
    static let surface=Color(red:0.09,green:0.10,blue:0.105)
    static let raised=Color(red:0.14,green:0.15,blue:0.16)
    static let lime=Color(red:0.74,green:0.94,blue:0.39)
    static let secondary=Color(red:0.63,green:0.66,blue:0.65)
}
private struct PrismGlass:ViewModifier {
    var radius:CGFloat=24
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @ViewBuilder func body(content:Content)->some View {
        if reduceTransparency {
            content.background(Ink.surface,in:RoundedRectangle(cornerRadius:radius))
        } else if #available(iOS 26.0,*) {
            content.glassEffect(.regular,in:RoundedRectangle(cornerRadius:radius))
        } else {
            content.background(.ultraThinMaterial,in:RoundedRectangle(cornerRadius:radius))
                .overlay(RoundedRectangle(cornerRadius:radius).stroke(Color.white.opacity(0.12),lineWidth:0.5))
        }
    }
}
private struct PrismButtonGlass:ViewModifier {
    let accent:Bool
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @ViewBuilder func body(content:Content)->some View {
        if #available(iOS 26.0,*),!reduceTransparency {
            content.glassEffect(.regular.tint(accent ? Ink.lime : Color.white.opacity(0.05)).interactive(),in:RoundedRectangle(cornerRadius:16))
        } else {
            content.background(accent ? Ink.lime : Ink.raised,in:RoundedRectangle(cornerRadius:16))
        }
    }
}
private struct ControlStyle:ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    var accent=false
    func makeBody(configuration:Configuration)->some View {
        configuration.label.font(.body.weight(.semibold)).frame(minHeight:52)
            .frame(maxWidth:.infinity).contentShape(Rectangle())
            .foregroundStyle(accent ? Ink.background : Color.white)
            .modifier(PrismButtonGlass(accent:accent))
            .opacity(!enabled ? 0.35 : (configuration.isPressed ? 0.65 : 1))
    }
}
private struct SectionLabel:View {
    let text:String
    var body:some View {Text(text.uppercased()).font(.caption.weight(.bold)).tracking(2).foregroundStyle(Ink.secondary).frame(maxWidth:.infinity,alignment:.leading).padding(.top,16)}
}
private struct Surface<Content:View>:View {
    @ViewBuilder var content:Content
    var body:some View {VStack(alignment:.leading,spacing:16){content}.padding(20).frame(maxWidth:.infinity,alignment:.leading).modifier(PrismGlass())}
}
private struct Page<Content:View>:View {
    let title:String
    let subtitle:String
    @ViewBuilder var content:Content
    var body:some View {
        ScrollView {VStack(alignment:.leading,spacing:20){
            VStack(alignment:.leading,spacing:8){Text(title).font(.system(size:36,weight:.bold));Text(subtitle).font(.subheadline).foregroundStyle(Ink.secondary)}.padding(.top,16)
            content
        }.padding(.horizontal,24).padding(.bottom,32).frame(maxWidth:620).frame(maxWidth:.infinity)}.background(Ink.backdrop)
    }
}
@main struct PrismApp:App {
    @StateObject private var tv=WebOSTV()
    var body:some Scene {WindowGroup {PrismRoot().environmentObject(tv).preferredColorScheme(.dark).tint(Ink.lime)}}
}
private enum Destination:String,CaseIterable {case remote="Ovládač",picture="Obraz",scenes="Scény",devices="TV"}
struct PrismRoot:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.scenePhase) private var phase
    @State private var tab:Destination = .remote
    var body:some View {
        if #available(iOS 26.0,*) {GlassEffectContainer(spacing:16){layout}}
        else {layout}
    }
    private var layout:some View {
        VStack(spacing:0){
            HStack {
                Text("prism").font(.system(size:23,weight:.black,design:.rounded)).tracking(-1)
                Spacer()
                Button {tab = .devices} label:{HStack(spacing:8){Circle().fill(tv.connected ? Ink.lime : Ink.secondary).frame(width:7,height:7);Text(tv.connected ? (tv.current?.name ?? "TV") : "Pripojiť TV").font(.subheadline.weight(.medium)).lineLimit(1)}.padding(.horizontal,14).frame(minHeight:44).modifier(PrismGlass(radius:28))}.buttonStyle(.plain)
            }.padding(.horizontal,24).padding(.vertical,8)
            Group {switch tab {case .remote:RemotePage();case .picture:PicturePage(onDevices:{tab = .devices});case .scenes:ScenesPage();case .devices:DevicesPage()}}.frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack(spacing:0){
                Text(tv.status).font(.caption).foregroundStyle(Ink.secondary).lineLimit(2).frame(maxWidth:.infinity,minHeight:34).padding(.horizontal,24).accessibilityIdentifier("connectionStatus")
                HStack(spacing:4){ForEach(Destination.allCases,id:\.self){destination in
                    Button {tab=destination} label:{VStack(spacing:6){Image(systemName:symbol(destination)).font(.system(size:20,weight:.semibold));Text(destination.rawValue).font(.caption2.weight(.semibold))}.foregroundStyle(tab==destination ? Ink.lime : Ink.secondary).frame(maxWidth:.infinity,minHeight:60).contentShape(Rectangle())}.buttonStyle(.plain).accessibilityIdentifier("tab-\(destination)")
                }}.padding(.horizontal,12)
            }.modifier(PrismGlass(radius:30)).padding(.horizontal,12).padding(.bottom,6)
        }.background(Ink.backdrop).onChange(of:phase){_,state in
            if state == .active,tv.connected {tv.startPolling();tv.readVolume();if !tv.pointerReady {tv.reconnectPointer()}}
            else if state != .active {tv.stopPolling()}
        }
    }
    private func symbol(_ destination:Destination)->String {switch destination {case .remote:return "dot.radiowaves.left.and.right";case .picture:return "slider.horizontal.3";case .scenes:return "square.stack";case .devices:return "tv"}}
}
private struct RemotePage:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var library=false
    @State private var touchpad=false
    @State private var keyboard=false
    @State private var power=false
    var body:some View {
        Page(title:"Take control.",subtitle:tv.connected ? tv.model : "Tvoj televízor. Jednoducho."){
            HStack(spacing:16){
                Button {library=true} label:{Label("Aplikácie",systemImage:"square.grid.2x2")}.buttonStyle(ControlStyle()).disabled(tv.settingsBusy || tv.presetBusy)
                Button {if tv.connected {power=true}else{tv.wake()}} label:{Image(systemName:"power").frame(width:56)}.buttonStyle(ControlStyle()).frame(width:64)
            }
            if !tv.connected {Surface {Text("Najprv pripoj TV").font(.title3.bold());Text("iPhone a televízor musia byť na rovnakej Wi-Fi. Pripojenie nájdeš na karte TV.").foregroundStyle(Ink.secondary);Button(tv.connecting ? "Pripája sa…" : "Pripojiť uloženú TV"){tv.connect()}.buttonStyle(ControlStyle(accent:true)).disabled(tv.current==nil || tv.connecting)}}
            VStack(spacing:14){
                HStack(spacing:14){Color.clear.frame(maxWidth:.infinity);direction("chevron.up","UP");Color.clear.frame(maxWidth:.infinity)}
                HStack(spacing:14){direction("chevron.left","LEFT");Button {tv.button("ENTER")} label:{Text("OK").font(.title3.bold())}.buttonStyle(ControlStyle(accent:true)).frame(height:76).disabled(!tv.pointerReady);direction("chevron.right","RIGHT")}
                HStack(spacing:14){Color.clear.frame(maxWidth:.infinity);direction("chevron.down","DOWN");Color.clear.frame(maxWidth:.infinity)}
            }.frame(maxWidth:360).frame(maxWidth:.infinity).padding(.vertical,10)
            if tv.connected && !tv.pointerReady {Button("Opraviť navigáciu"){tv.reconnectPointer()}.buttonStyle(ControlStyle())}
            HStack(spacing:14){nav("Späť","arrow.uturn.backward","BACK");nav("Domov","house","HOME");nav("Menu","gearshape","MENU")}
            SectionLabel(text:"Hlasitosť")
            HStack {Text(tv.volume.map{String(Int($0))} ?? "—").font(.system(size:42,weight:.bold,design:.rounded));Spacer();Text(tv.volume == nil ? "TV zatiaľ neposlala hodnotu" : (tv.muted == true ? "Stlmené" : "Hodnota z TV")).font(.caption).foregroundStyle(Ink.secondary)}
            HStack(spacing:14){
                Button {tv.command("audio/volumeDown")} label:{Image(systemName:"minus")}.buttonStyle(ControlStyle())
                Button {tv.toggleMute()} label:{Image(systemName:tv.muted == true ? "speaker.slash.fill" : "speaker.wave.2.fill")}.buttonStyle(ControlStyle())
                Button {tv.command("audio/volumeUp")} label:{Image(systemName:"plus")}.buttonStyle(ControlStyle())
            }.disabled(!tv.connected)
            HStack(spacing:14){media("play.fill","play");media("pause.fill","pause");media("stop.fill","stop")}.disabled(!tv.connected)
            SectionLabel(text:"Viac ovládania")
            HStack(spacing:14){Button {touchpad=true} label:{Label("Touchpad",systemImage:"hand.draw")};Button {keyboard=true} label:{Label("Text",systemImage:"keyboard")}}.buttonStyle(ControlStyle()).disabled(!tv.connected)
            HStack(spacing:14){Button("Kanál −"){tv.command("tv/channelDown")};Button("Kanál +"){tv.command("tv/channelUp")}}.buttonStyle(ControlStyle()).disabled(!tv.connected)
        }.sheet(isPresented:$library){LibrarySheet()}.sheet(isPresented:$touchpad){TouchpadSheet()}.sheet(isPresented:$keyboard){KeyboardSheet()}
        .confirmationDialog("Vypnúť televízor?",isPresented:$power,titleVisibility:.visible){Button("Vypnúť TV",role:.destructive){tv.command("system/turnOff")}}
    }
    private func direction(_ symbol:String,_ key:String)->some View {Button {tv.button(key)} label:{Image(systemName:symbol).font(.title2.weight(.semibold)).frame(maxWidth:.infinity,minHeight:76)}.buttonStyle(ControlStyle()).disabled(!tv.pointerReady).accessibilityLabel(key)}
    private func nav(_ title:String,_ symbol:String,_ key:String)->some View {Button {tv.button(key)} label:{VStack(spacing:8){Image(systemName:symbol).font(.title3);Text(title).font(.caption)}.frame(maxWidth:.infinity,minHeight:68)}.buttonStyle(ControlStyle()).disabled(!tv.pointerReady)}
    private func media(_ symbol:String,_ action:String)->some View {Button {tv.command("media.controls/"+action)} label:{Image(systemName:symbol)}.buttonStyle(ControlStyle()).accessibilityLabel(action)}
}
private struct LibrarySheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var query=""
    var body:some View {NavigationStack {List {
        Section("Vstupy"){ForEach(tv.inputs){input in Button {tv.command("tv/switchInput",payload:["inputId":input.id]);dismiss()} label:{Label(input.title,systemImage:"cable.connector").frame(minHeight:48)}}}
        Section("Aplikácie"){ForEach(tv.apps.filter{query.isEmpty || $0.title.localizedCaseInsensitiveContains(query)}){app in Button {tv.command("com.webos.applicationManager/launch",payload:["id":app.id]);dismiss()} label:{Text(app.title).frame(minHeight:48)}}}
        if tv.apps.isEmpty && tv.inputs.isEmpty {Text("Zoznam sa načíta po pripojení TV.").foregroundStyle(Ink.secondary)}
    }.disabled(tv.settingsBusy || tv.presetBusy).searchable(text:$query,prompt:"Nájsť aplikáciu").navigationTitle("Na veľkej obrazovke").toolbar {ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}}}
}
private struct TouchpadSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var previous=CGSize.zero
    @State private var last=Date.distantPast
    var body:some View {NavigationStack {VStack(spacing:24){Text("Posúvaj prstom. Ťuknutím vyber.").foregroundStyle(Ink.secondary)
        RoundedRectangle(cornerRadius:32).fill(Ink.surface).overlay(Image(systemName:"hand.draw").font(.system(size:48)).foregroundStyle(Ink.secondary)).frame(height:340).contentShape(Rectangle()).onTapGesture{tv.click()}.gesture(DragGesture(minimumDistance:4).onChanged{value in
            guard Date().timeIntervalSince(last)>0.04 else{return}
            let dx=Int(value.translation.width-previous.width),dy=Int(value.translation.height-previous.height)
            previous=value.translation;last=Date();tv.move(dx:dx,dy:dy)
        }.onEnded{_ in previous = .zero})
        if !tv.pointerReady {Button("Opraviť navigáciu"){tv.reconnectPointer()}.buttonStyle(ControlStyle())}
    }.padding(24).navigationTitle("Touchpad").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}.background(Ink.background)}}
}
private struct KeyboardSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    @State private var text=""
    var body:some View {NavigationStack {VStack(alignment:.leading,spacing:24){Text("Najprv otvor textové pole na TV.").foregroundStyle(Ink.secondary);TextField("Text pre TV",text:$text).textFieldStyle(.roundedBorder);Button("Odoslať text"){tv.command("com.webos.service.ime/insertText",payload:["text":text,"replace":0]);text=""}.buttonStyle(ControlStyle(accent:true)).disabled(text.isEmpty || !tv.connected);Spacer()}.padding(24).navigationTitle("Klávesnica").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}}}
}
private enum PictureGroup:String,CaseIterable {
    case basics="Základ",colour="Farby",clarity="Detaily",motion="Pohyb",gaming="Hranie",advanced="Pokročilé",all="Všetko"
    var keys:[String] {
        switch self {
        case .basics:return ["pictureMode","backlight","contrast","brightness","gamma","blackLevel","peakBrightness","hdrDynamicToneMapping"]
        case .colour:return ["color","tint","colorTemperature","whiteBalanceColorTemperature","colorGamut","dynamicColor"]
        case .clarity:return ["sharpness","superResolution","noiseReduction","mpegNoiseReduction","smoothGradation","dynamicContrast"]
        case .motion:return ["realCinema","truMotionMode","truMotionJudder","truMotionBlur","motionEyeCare","motionPro"]
        case .gaming:return ["pictureMode","blackLevel","hdrDynamicToneMapping","peakBrightness","sharpness","superResolution","motionPro"]
        case .advanced:return ["energySaving","eyeComfortMode","whiteBalanceColorTemperature","colorGamut","gamma"]
        case .all:return PictureSetting.all.map(\.key)
        }
    }
}
private struct PicturePage:View {
    @EnvironmentObject private var tv:WebOSTV
    var onDevices:()->Void
    @State private var group:PictureGroup = .basics
    @State private var query=""
    private var settings:[PictureSetting] {
        let list=query.isEmpty ? group.keys.compactMap{key in PictureSetting.all.first{$0.key==key}} : PictureSetting.all
        return list.filter{query.isEmpty || $0.title.localizedCaseInsensitiveContains(query) || $0.key.localizedCaseInsensitiveContains(query)}
    }
    var body:some View {
        Page(title:"Obraz.",subtitle:"Všetko priamo pod palcom.") {
            connection
            search
            categories
            DisclosureGroup("Načítavanie hodnôt") {
                VStack(alignment:.leading,spacing:14) {
                    Toggle("Priebežné obnovovanie",isOn:$tv.autoRefreshPicture)
                    Toggle("Overovať každú zmenu z TV",isOn:$tv.verifyPictureWrites)
                    Text("Predvolene vypnuté. Hodnoty načítaj tlačidlom Obnoviť, keď ich potrebuješ. Požiadavky ostanú označené osobitne.").font(.caption).foregroundStyle(Ink.secondary)
                }.padding(.vertical,12)
            }.font(.subheadline)
            .onChange(of:tv.autoRefreshPicture){_,_ in tv.saveReadPreferences()}
            .onChange(of:tv.verifyPictureWrites){_,_ in tv.saveReadPreferences()}
            HStack {
                Text("\(settings.count) nastavení").font(.caption).foregroundStyle(Ink.secondary)
                Spacer()
                Button {tv.readPicture(keys:settings.map(\.key))} label:{Label("Obnoviť",systemImage:"arrow.clockwise").font(.subheadline).frame(minHeight:44)}
                    .disabled(!tv.connected)
            }
            LazyVStack(spacing:18) {
                ForEach(settings) {setting in InlinePictureControl(setting:setting)}
            }
            if group == .gaming || group == .advanced || group == .all {HDMITypeControl()}
            Text("Posuvník odosiela po pustení, voľby po ťuknutí. TV označuje prijatú hodnotu; požiadavka zostáva označená osobitne.")
                .font(.caption).foregroundStyle(Ink.secondary)
        }
        .onAppear{refresh()}
        .onChange(of:group){_,_ in refresh()}
        .onChange(of:query){_,_ in refresh()}
        .onChange(of:tv.connected){_,value in if value{refresh()}}
        .onChange(of:tv.contextID){_,_ in refresh()}
    }
    @ViewBuilder private var connection:some View {
        if !tv.connected {
            Surface {
                Label(tv.connecting ? "Pripájanie…" : "TV je odpojená",systemImage:"wifi.exclamationmark").font(.headline)
                Text("Ovládanie sa aktivuje po pripojení. Hodnoty sa potom načítajú z TV.").font(.subheadline).foregroundStyle(Ink.secondary)
                Button(tv.connecting ? "Zrušiť pripájanie" : "Pripojiť TV") {
                    if tv.connecting {tv.disconnect()}
                    else if tv.current != nil {tv.connect()}
                    else {onDevices()}
                }.buttonStyle(ControlStyle(accent:true))
            }
        }
    }
    private var search:some View {
        HStack {
            Image(systemName:"magnifyingglass").foregroundStyle(Ink.secondary)
            TextField("Hľadať vo všetkých nastaveniach",text:$query).frame(minHeight:48)
            if !query.isEmpty {Button {query=""} label:{Image(systemName:"xmark.circle.fill").frame(width:44,height:44)}.buttonStyle(.plain)}
        }.padding(.horizontal,16).background(Ink.surface,in:RoundedRectangle(cornerRadius:16))
    }
    private var categories:some View {
        ScrollView(.horizontal,showsIndicators:false) {
            HStack(spacing:10) {
                ForEach(PictureGroup.allCases,id:\.self) {item in
                    Button {group=item} label:{
                        Text(item.rawValue).font(.subheadline.weight(.semibold))
                            .padding(.horizontal,18).frame(minHeight:46)
                            .foregroundStyle(group==item ? Ink.background : Color.white)
                            .background(group==item ? Ink.lime : Ink.surface,in:Capsule())
                    }.buttonStyle(.plain)
                }
            }
        }
    }
    private func refresh(){tv.watchPicture(keys:settings.map(\.key))}
}
private func display(_ value:String,key:String)->String {PictureSetting.label(value,key:key)}

private struct InlinePictureControl:View {
    @EnvironmentObject private var tv:WebOSTV
    let setting:PictureSetting
    @State private var draft:Double?
    @State private var dragging=false
    @State private var information=false
    private var actual:String? {tv.picture[setting.key]}
    private var actualNumber:Double? {
        guard let text=actual,let number=Double(text),number.isFinite,let range=setting.range,range.contains(number) else{return nil}
        return number
    }
    private var requested:String? {tv.queuedPicture[setting.key] ?? tv.sendingPicture[setting.key] ?? tv.requestedPicture[setting.key]}
    private var proposal:Double? {
        if let draft=draft {return draft}
        if let text=tv.queuedPicture[setting.key] ?? tv.sendingPicture[setting.key],let value=Double(text) {return value}
        return actualNumber ?? requested.flatMap{Double($0)}
    }
    private var enabled:Bool {tv.connected && !tv.presetBusy}
    var body:some View {
        Surface {
            header
            if let range=setting.range {numericControl(range)}else{options}
            readStatus
            requestStatus
            if information {Text(setting.help).font(.caption).foregroundStyle(Ink.secondary)}
        }
        .onChange(of:actual){_,_ in if !dragging {draft=nil}}
        .onChange(of:tv.contextID){_,_ in draft=nil;dragging=false}
    }
    private var header:some View {
        HStack(alignment:.top,spacing:12) {
            Image(systemName:setting.symbol).foregroundStyle(Ink.lime).frame(width:22).padding(.top,2)
            VStack(alignment:.leading,spacing:6) {
                Text(setting.title).font(.headline)
                if setting.range==nil,let value=actual {Text(display(value,key:setting.key)).font(.caption).foregroundStyle(Ink.lime)}
            }
            Spacer(minLength:4)
            if setting.range != nil {Text(actualNumber.map{String(Int($0))} ?? "—").font(.title2.bold()).monospacedDigit()}
            Button {information.toggle()} label:{Image(systemName:information ? "xmark.circle" : "info.circle").frame(width:44,height:44)}
                .buttonStyle(.plain).foregroundStyle(Ink.secondary).accessibilityLabel("Informácie: \(setting.title)")
        }
    }
    private func numericControl(_ range:ClosedRange<Double>)->some View {
        VStack(spacing:10) {
            HStack(spacing:14) {
                stepButton(-1,range:range)
                Slider(value:Binding(get:{min(range.upperBound,max(range.lowerBound,proposal ?? range.lowerBound))},set:{draft=$0}),in:range,step:1,onEditingChanged:{editing in
                    dragging=editing
                    if !editing,let value=draft {submit(String(Int(value)))}
                })
                .frame(minHeight:48).disabled(!enabled)
                .accessibilityLabel(setting.title)
                .accessibilityValue(actual ?? "TV hodnotu neposkytla")
                stepButton(1,range:range)
            }
            if let value=proposal,dragging || actualNumber==nil || value != actualNumber {
                Text("Nová požiadavka: \(Int(value))").font(.caption.weight(.medium)).foregroundStyle(.orange).frame(maxWidth:.infinity,alignment:.leading)
            } else if actualNumber==nil {
                Text("— z TV · posunutím zvolíš novú hodnotu").font(.caption).foregroundStyle(Ink.secondary).frame(maxWidth:.infinity,alignment:.leading)
            }
        }
    }
    private func stepButton(_ delta:Int,range:ClosedRange<Double>)->some View {
        Button {
            guard let value=proposal else{return}
            let next=min(range.upperBound,max(range.lowerBound,value+Double(delta)))
            draft=next;submit(String(Int(next)))
        } label:{Image(systemName:delta<0 ? "minus" : "plus").font(.title3).frame(width:48,height:52)}
        .buttonStyle(ControlStyle()).frame(width:48)
        .disabled(!enabled || proposal==nil || (delta<0 ? (proposal ?? range.lowerBound)<=range.lowerBound : (proposal ?? range.upperBound)>=range.upperBound))
        .accessibilityLabel(delta<0 ? "Znížiť \(setting.title)" : "Zvýšiť \(setting.title)")
    }
    private var options:some View {
        LazyVGrid(columns:[GridItem(.adaptive(minimum:88),spacing:10)],alignment:.leading,spacing:10) {
            ForEach(setting.options,id:\.self) {option in
                let selected=matches(actual,option)
                let pending=matches(requested,option) && !selected
                Button {submit(option)} label:{
                    VStack(spacing:4) {
                        Text(display(option,key:setting.key)).font(.subheadline.weight(.semibold)).multilineTextAlignment(.center).fixedSize(horizontal:false,vertical:true)
                        if selected {Text("TV").font(.system(size:9,weight:.bold))}
                        else if pending {Text("POŽIADAVKA").font(.system(size:8,weight:.bold))}
                    }
                    .padding(.horizontal,8).padding(.vertical,10).frame(maxWidth:.infinity,minHeight:52)
                    .foregroundStyle(selected ? Ink.background : (pending ? Color.orange : Color.white))
                    .background(selected ? Ink.lime : Ink.raised,in:RoundedRectangle(cornerRadius:14))
                    .overlay(RoundedRectangle(cornerRadius:14).stroke(pending ? Color.orange : Color.clear,lineWidth:1))
                    .opacity(enabled ? 1 : 0.4)
                }.buttonStyle(.plain).disabled(!enabled)
            }
        }
    }
    private var readStatus:some View {
        HStack(spacing:6) {
            if !tv.connected {Text("Nepripojené")}
            else if tv.readingKeys.contains(setting.key) {ProgressView().controlSize(.mini);Text("Čítam z TV…")}
            else if let time=tv.pictureReadAt[setting.key] {Text("TV ·");Text(time,style:.time)}
            else if tv.unavailableKeys[setting.key] != nil {Text("TV čítanie tejto hodnoty neposkytla")}
            else {Text("Zatiaľ bez odpovede TV")}
        }.font(.caption2).foregroundStyle(Ink.secondary)
    }
    @ViewBuilder private var requestStatus:some View {
        if let error=tv.failedPicture[setting.key] {Text(error).font(.caption).foregroundStyle(.orange)}
        else if let value=requested {
            if tv.queuedPicture[setting.key] != nil {Text("Na odoslanie: \(display(value,key:setting.key))").font(.caption).foregroundStyle(.orange)}
            else if tv.sendingPicture[setting.key] != nil {Text("Odosielam: \(display(value,key:setting.key))").font(.caption).foregroundStyle(.orange)}
            else if matches(actual,value) {Label("Potvrdené z TV",systemImage:"checkmark.circle").font(.caption).foregroundStyle(Ink.lime)}
            else {Text("Požiadavka: \(display(value,key:setting.key)) · nepotvrdená").font(.caption).foregroundStyle(.orange)}
        }
    }
    private func matches(_ observed:String?,_ value:String)->Bool {
        guard let observed=observed else{return false}
        if setting.key=="blackLevel" {return TVProtocol.blackLevelValue(observed)==TVProtocol.blackLevelValue(value)}
        return TVProtocol.pictureMatches(observed,value)
    }
    private func submit(_ value:String){tv.enqueuePicture(key:setting.key,value:value)}
}
private struct HDMITypeControl:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var input=""
    @State private var confirm:String?
    @State private var confirmation=false
    var body:some View {
        Surface {
            Label("Typ HDMI vstupu",systemImage:"cable.connector").font(.headline)
            Picker("Vyber vstup",selection:$input) {
                Text("Vyber HDMI vstup").tag("")
                ForEach(tv.inputs.filter{$0.id.uppercased().hasPrefix("HDMI")}) {item in Text(item.title).tag(item.id)}
            }.pickerStyle(.menu).frame(minHeight:48)
            HStack(spacing:14) {
                Button("PC"){confirm="PC";confirmation=true}
                Button("HDMI"){confirm="HDMI";confirmation=true}
            }.buttonStyle(ControlStyle()).disabled(input.isEmpty || !tv.connected || tv.settingsBusy || tv.presetBusy)
            Text("Nová požiadavka pre zvolený vstup. Neoznačuje aktuálny typ. Na B9 sa dostupnosť Auto rozsahu môže meniť podľa typu vstupu.").font(.caption).foregroundStyle(Ink.secondary)
        }
        .confirmationDialog("Nastaviť \(input) ako \(confirm ?? "HDMI")?",isPresented:$confirmation,titleVisibility:.visible) {
            Button("Nastaviť \(confirm ?? "HDMI")"){tv.setHDMIType(input:input,pc:confirm=="PC")}
        }
        .onChange(of:tv.selected){_,_ in input=""}
        .onChange(of:tv.inputs.map(\.id)){_,ids in if !ids.contains(input){input=""}}
    }
}

private struct ScenesPage:View {
    @EnvironmentObject private var tv:WebOSTV
    @State private var signal:B9Signal = .sdr
    @State private var preset:B9Preset?
    @State private var name=""
    var body:some View {Page(title:"Set the mood.",subtitle:"Východiskové presety pre LG B9."){
        Picker("Signál",selection:$signal){ForEach(B9Signal.allCases){Text($0.rawValue).tag($0)}}.pickerStyle(.segmented).frame(minHeight:48)
        ForEach(B9Preset.all.filter{$0.signal==signal}){item in
            Button {preset=item} label:{Surface {HStack(alignment:.top,spacing:18){Image(systemName:item.symbol).font(.system(size:28)).foregroundStyle(Ink.lime).frame(width:40,height:48);VStack(alignment:.leading,spacing:8){Text(item.name).font(.title3.bold()).foregroundStyle(.white);Text(item.subtitle).font(.subheadline).foregroundStyle(Ink.secondary)};Spacer(minLength:0)};HStack{Text(item.signal.rawValue).font(.caption.bold()).foregroundStyle(Ink.lime);Spacer();Image(systemName:"arrow.up.right").foregroundStyle(Ink.secondary)}}}.buttonStyle(.plain)
        }
        Text("Najprv spusti obsah so správnym signálom. Appka automaticky nerozpoznáva SDR, HDR10 ani Dolby Vision. Presety sú východiská, nie meraná kalibrácia panela.").font(.caption).foregroundStyle(Ink.secondary)
        SectionLabel(text:"Tvoje uložené hodnoty")
        ForEach(tv.profiles.filter{$0.device==tv.selected}){profile in
            Surface {Text(profile.name).font(.headline);Text(profile.confirmed==true ? "\(profile.settings.count) hodnôt uložených z odpovede TV" : "Staršia scéna · pôvod hodnôt neoverený").font(.caption).foregroundStyle(Ink.secondary)
                HStack(spacing:16){Button("Použiť"){tv.writePicture(profile.settings)}.buttonStyle(ControlStyle()).disabled(!tv.connected || tv.settingsBusy || tv.presetBusy);Button(role:.destructive){tv.deleteProfile(profile.id)} label:{Image(systemName:"trash").frame(width:52)}.buttonStyle(ControlStyle()).frame(width:60)}
            }
        }
        Surface {TextField("Názov vlastnej scény",text:$name).frame(minHeight:48);Button("Uložiť prijaté hodnoty"){tv.saveProfile(name);name=""}.buttonStyle(ControlStyle()).disabled(tv.picture.isEmpty || !tv.connected);Text("Ukladajú sa iba hodnoty, ktoré TV skutočne vrátila pre aktuálny vstup.").font(.caption).foregroundStyle(Ink.secondary)}
    }.sheet(item:$preset){PresetSheet(preset:$0)}}
}
private struct PresetSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let preset:B9Preset
    @State private var confirmed=false
    @State private var balance="preset"
    var body:some View {NavigationStack {ScrollView {VStack(alignment:.leading,spacing:24){
        Image(systemName:preset.symbol).font(.system(size:44)).foregroundStyle(Ink.lime)
        Text(preset.name).font(.largeTitle.bold());Text(preset.notes).font(.body).foregroundStyle(Ink.secondary)
        Picker("Biela",selection:$balance){Text("Podľa presetu").tag("preset");Text("Warm 1").tag("warm1");Text("Warm 2").tag("warm2")}.pickerStyle(.menu).frame(minHeight:48)
        Toggle("Na TV práve prehrávam \(preset.signal.rawValue)",isOn:$confirmed).frame(minHeight:60)
        Button(tv.presetBusy ? "Odosiela sa…" : "Použiť preset"){tv.applyRecommended(preset,whiteBalance:balance=="preset" ? nil : balance)}.buttonStyle(ControlStyle(accent:true)).disabled(!confirmed || !tv.connected || tv.settingsBusy || tv.presetBusy)
        Text(tv.status).font(.footnote).foregroundStyle(Ink.secondary)
        SectionLabel(text:"Odosielané hodnoty")
        ForEach(preset.values(whiteBalance:balance=="preset" ? nil : balance).sorted(by:{$0.key<$1.key}),id:\.key){key,value in HStack{Text(PictureSetting.all.first{$0.key==key}?.title ?? key);Spacer();Text(display(value,key:key)).foregroundStyle(Ink.lime)}.font(.caption).padding(.vertical,8)}
    }.padding(24)}.background(Ink.background).navigationTitle("LG B9").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){dismiss()}}}}}
}
private struct DevicesPage:View {
    @EnvironmentObject private var tv:WebOSTV
    @StateObject private var discovery=TVDiscovery()
    @State private var name="LG OLED"
    @State private var host=""
    @State private var mac=""
    @State private var details:TVDevice?
    @State private var log=false
    var body:some View {Page(title:"Your big screen.",subtitle:"Lokálne pripojenie cez Wi-Fi. Bez účtu."){
        ForEach(tv.devices){device in Surface {
            HStack(alignment:.top){Image(systemName:"tv").font(.title).foregroundStyle(Ink.lime);VStack(alignment:.leading,spacing:6){Text(device.name).font(.title3.bold());Text(device.host).font(.caption).foregroundStyle(Ink.secondary)};Spacer();Button {details=device} label:{Image(systemName:"ellipsis").frame(width:48,height:48)}.buttonStyle(.plain)}
            Button(tv.selected==device.id && tv.connected ? "Odpojiť" : (tv.selected==device.id && tv.connecting ? "Zrušiť pripájanie" : "Pripojiť")){
                if tv.selected==device.id && (tv.connected || tv.connecting) {tv.disconnect()}else{tv.select(device.id);tv.connect()}
            }.buttonStyle(ControlStyle(accent:tv.selected==device.id))
        }}
        SectionLabel(text:"Nájsť televízor")
        Surface {Text("iPhone aj TV pripoj na rovnakú Wi-Fi. Televízor musí byť zapnutý.").foregroundStyle(Ink.secondary)
            Button(discovery.searching ? "Zastaviť hľadanie" : "Vyhľadať TV"){if discovery.searching{discovery.stop()}else{discovery.start()}}.buttonStyle(ControlStyle(accent:true))
            if discovery.searching {ProgressView(value:discovery.progress)}
            Text(discovery.message).font(.caption).foregroundStyle(Ink.secondary)
            ForEach(discovery.found){found in Button {if tv.add(name:found.name,host:found.host,mac:""){discovery.stop();tv.connect()}} label:{HStack{Text(found.name);Spacer();Text(found.host).font(.caption);Image(systemName:"plus.circle")}.frame(minHeight:56)}.buttonStyle(.plain)}
        }
        SectionLabel(text:"Alebo pridať IP adresu")
        Surface {TextField("Názov TV",text:$name).frame(minHeight:48);TextField("192.168.0.110",text:$host).keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled().frame(minHeight:48)
            Button("Pridať a pripojiť"){if tv.add(name:name,host:host,mac:mac){host="";tv.connect()}}.buttonStyle(ControlStyle()).disabled(!WebOSTV.isLocalIP(host.trimmingCharacters(in:.whitespacesAndNewlines)))
            Text("Povoľ prístup k lokálnej sieti a potvrď párovanie na obrazovke TV.").font(.caption).foregroundStyle(Ink.secondary)
        }
        Surface {Toggle("Kompatibilný zápis obrazu",isOn:$tv.useLunaFallback);Text("Ak TV odmietne priamy zápis, skúsi sa alternatívna metóda cez webOS alert. Čítanie na overenie si môžeš zapnúť na stránke Obraz. Bez neho je zmena označená iba ako požiadavka.").font(.caption).foregroundStyle(Ink.secondary);Button("Diagnostika"){log=true}.frame(minHeight:48)}
        Text("Prism 2.1 · Wi-Fi remote").font(.caption).foregroundStyle(Ink.secondary)
    }.onDisappear{discovery.stop()}.sheet(item:$details){DeviceSheet(device:$0)}.sheet(isPresented:$log){NavigationStack {List {Text(tv.status);ForEach(Array(tv.diagnostics.enumerated()),id:\.offset){_,line in Text(line).font(.caption).textSelection(.enabled)}}.navigationTitle("Diagnostika").toolbar{ToolbarItem(placement:.confirmationAction){Button("Hotovo"){log=false}}}}}}
}
private struct DeviceSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let device:TVDevice
    @State private var name=""
    @State private var mac=""
    @State private var remove=false
    var body:some View {NavigationStack {Form {
        Section("Televízor"){TextField("Názov",text:$name);Text(device.host);TextField("MAC adresa pre Wake-on-LAN",text:$mac).textInputAutocapitalization(.never).autocorrectionDisabled()}
        Button("Uložiť"){if let index=tv.devices.firstIndex(where:{$0.id==device.id}) {tv.devices[index].name=name.isEmpty ? device.name : name;tv.devices[index].mac=mac;tv.persist()};dismiss()}.frame(minHeight:48)
        if tv.selected==device.id {Button("Zrušiť párovanie"){tv.forgetPairing();dismiss()}.frame(minHeight:48);Button("Prebudiť TV"){tv.wake()}.frame(minHeight:48)}
        Button("Odstrániť TV",role:.destructive){remove=true}.frame(minHeight:48)
    }.navigationTitle("Upraviť TV").toolbar{ToolbarItem(placement:.cancellationAction){Button("Zavrieť"){dismiss()}}}.onAppear{name=device.name;mac=device.mac}.confirmationDialog("Odstrániť TV aj jej scény?",isPresented:$remove,titleVisibility:.visible){Button("Odstrániť",role:.destructive){tv.remove(device.id);dismiss()}}}}
}
