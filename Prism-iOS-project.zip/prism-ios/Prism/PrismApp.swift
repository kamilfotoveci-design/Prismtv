import SwiftUI
import Foundation
import Network
import Security
import UIKit

struct TVDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var host: String
    var mac: String
}
struct TVApp: Identifiable { var id: String; var title: String }
struct TVInput: Identifiable { var id: String; var title: String }
struct PictureProfile: Codable, Identifiable {
    var id = UUID()
    var name: String
    var device: UUID
    var settings: [String:String]
}
struct TVFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

private enum PairingStore {
    static func read(_ host: String) -> String? {
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&item) == errSecSuccess,let d = item as? Data else { return nil }
        return String(data:d,encoding:.utf8)
    }
    static func save(_ key: String,host: String) {
        delete(host)
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host,kSecValueData as String:Data(key.utf8),kSecAttrAccessible as String:kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        SecItemAdd(q as CFDictionary,nil)
    }
    static func delete(_ host: String) {
        SecItemDelete([kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.kamilwhoo.prism.pairing",kSecAttrAccount as String:host] as CFDictionary)
    }
}

@MainActor final class WebOSTV: ObservableObject {
    @Published var devices: [TVDevice] = []
    @Published var profiles: [PictureProfile] = []
    @Published var selected: UUID?
    @Published var connected = false
    @Published var connecting = false
    @Published var pointerReady = false
    @Published var status = "Add your TV to get started"
    @Published var model = "LG webOS"
    @Published var apps: [TVApp] = []
    @Published var inputs: [TVInput] = []
    @Published var volume: Double?
    @Published var muted = false
    @Published var picture: [String:String] = [:]
    @Published var verifiedKeys: Set<String> = []
    @Published var diagnostics: [String] = []
    @Published var settingsBusy = false
    @Published var presetBusy = false
    @Published var useLunaFallback = true
    private var socket: URLSessionWebSocketTask?
    private var pointer: URLSessionWebSocketTask?
    private let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 12
        return URLSession(configuration:c)
    }()
    private var receiver: Task<Void,Never>?
    private var pointerReceiver: Task<Void,Never>?
    private var pending: [String:(Result<[String:Any],Error>)->Void] = [:]
    private var subscriptions: [String:([String:Any])->Void] = [:]
    private var counter = 0
    private var epoch = 0
    private var contextRevision = 0
    private var foregroundApp = ""
    private var timeouts: [String:Task<Void,Never>] = [:]
    private var pairTimeout: Task<Void,Never>?
    private var wakeConnection: NWConnection?
    var current: TVDevice? { devices.first { $0.id == selected } }
    init() {
        if let data = UserDefaults.standard.data(forKey:"prism.devices"),let v = try? JSONDecoder().decode([TVDevice].self,from:data) { devices = v }
        if let data = UserDefaults.standard.data(forKey:"prism.profiles"),let v = try? JSONDecoder().decode([PictureProfile].self,from:data) { profiles = v }
        if let raw = UserDefaults.standard.string(forKey:"prism.selected"),let id=UUID(uuidString:raw),devices.contains(where:{$0.id==id}) { selected=id } else { selected=devices.first?.id }
    }
    func persist() {
        UserDefaults.standard.set(try? JSONEncoder().encode(devices),forKey:"prism.devices")
        UserDefaults.standard.set(try? JSONEncoder().encode(profiles),forKey:"prism.profiles")
        UserDefaults.standard.set(selected?.uuidString,forKey:"prism.selected")
    }
    static func isLocalIP(_ host:String)->Bool {TVProtocol.isLocalIP(host)}
    func add(name: String,host: String,mac: String) -> Bool {
        let host=host.trimmingCharacters(in:.whitespacesAndNewlines)
        guard Self.isLocalIP(host) else {status="Enter a private IPv4 address, for example 192.168.0.110";return false}
        if let index=devices.firstIndex(where:{$0.host==host}) {
            if !mac.isEmpty {devices[index].mac=mac}
            if !name.isEmpty && name != "LG webOS TV" {devices[index].name=name}
            select(devices[index].id);persist();return true
        }
        let d=TVDevice(name:name.isEmpty ? "LG OLED" : name,host:host,mac:mac)
        devices.append(d);select(d.id);persist();return true
    }
    func select(_ id: UUID) { if selected != id { disconnect();selected=id;persist() } }
    func remove(_ id: UUID) {
        if selected==id {disconnect()}
        if let d=devices.first(where:{$0.id==id}) {PairingStore.delete(d.host)}
        devices.removeAll{$0.id==id};profiles.removeAll{$0.device==id};selected=devices.first?.id;persist()
    }
    func log(_ message: String) {
        diagnostics.insert(message,at:0);if diagnostics.count>40 {diagnostics.removeLast()}
    }
    func connect() {
        guard let tv=current else {status="Add a TV first";return}
        disconnect();connecting=true;status="Connecting to \(tv.name)…"
        guard Self.isLocalIP(tv.host),let url=URL(string:"ws://\(tv.host):3000") else {connecting=false;return}
        let token=epoch
        let ws=session.webSocketTask(with:url);socket=ws;ws.resume()
        receiver=Task { [weak self] in
            do {
                while !Task.isCancelled {
                    let message=try await ws.receive()
                    guard let self=self,self.epoch==token else{return}
                    self.handle(message)
                }
            } catch {
                guard let self=self,self.epoch==token,!Task.isCancelled else{return}
                self.disconnect();self.status="Connection lost. Check Wi-Fi, TV power and IP address.";self.log("WebSocket: \(error.localizedDescription)")
            }
        }
        let permissions=["LAUNCH","LAUNCH_WEBAPP","APP_TO_APP","CONTROL_AUDIO","CONTROL_DISPLAY","CONTROL_INPUT_TV","CONTROL_INPUT_MEDIA_PLAYBACK","CONTROL_INPUT_TEXT","CONTROL_MOUSE_AND_KEYBOARD","CONTROL_POWER","CONTROL_TV_SCREEN","READ_APP_STATUS","READ_INSTALLED_APPS","READ_RUNNING_APPS","READ_INPUT_DEVICE_LIST","READ_CURRENT_CHANNEL","READ_TV_CHANNEL_LIST","READ_POWER_STATE","READ_SETTINGS","WRITE_SETTINGS","WRITE_NOTIFICATION_ALERT","WRITE_NOTIFICATION_TOAST"]
        var payload:[String:Any]=["forcePairing":false,"pairingType":"PROMPT","manifest":["manifestVersion":1,"appVersion":"1.0","permissions":permissions]]
        if let key=PairingStore.read(tv.host) {payload["client-key"]=key}
        send(["id":"register","type":"register","payload":payload])
        pairTimeout=Task { [weak self] in
            try? await Task.sleep(nanoseconds:60_000_000_000)
            guard !Task.isCancelled,let self=self,self.epoch==token,!self.connected else{return}
            self.disconnect();self.status="Pairing timed out. Accept the request on your TV, then retry."
        }
    }
    func forgetPairing() { if let host=current?.host {PairingStore.delete(host)};disconnect();status="Pairing cleared. Connect and approve again on the TV." }
    func disconnect() {
        epoch += 1;receiver?.cancel();pointerReceiver?.cancel();pairTimeout?.cancel()
        socket?.cancel(with:.goingAway,reason:nil);pointer?.cancel(with:.goingAway,reason:nil)
        socket=nil;pointer=nil;connected=false;connecting=false;pointerReady=false;settingsBusy=false;presetBusy=false
        apps=[];inputs=[];volume=nil;picture=[:];verifiedKeys=[];foregroundApp="";contextRevision += 1
        let callbacks=Array(pending.values);pending=[:];subscriptions=[:]
        timeouts.values.forEach{$0.cancel()};timeouts=[:]
        callbacks.forEach{$0(.failure(TVFailure(message:"Disconnected")))}
        status="Disconnected"
    }
    private func send(_ object:[String:Any]) {
        guard let ws=socket,let data=try? JSONSerialization.data(withJSONObject:object),let text=String(data:data,encoding:.utf8) else{return}
        let token=epoch
        Task { [weak self] in
            do {try await ws.send(.string(text))}
            catch {guard let self=self,self.epoch==token else{return};self.status="Could not send command";self.log(error.localizedDescription)}
        }
    }
    private func handle(_ message:URLSessionWebSocketTask.Message) {
        let data:Data
        switch message {case .data(let d):data=d;case .string(let s):data=Data(s.utf8);@unknown default:return}
        guard let obj=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{return}
        let type=obj["type"] as? String ?? "",id=obj["id"] as? String ?? ""
        let payload=obj["payload"] as? [String:Any] ?? [:]
        if type=="registered" {
            if let key=payload["client-key"] as? String,let host=current?.host {PairingStore.save(key,host:host)}
            pairTimeout?.cancel();connected=true;connecting=false;status="Connected to \(current?.name ?? "TV")";refresh();return
        }
        if id=="register",type=="response" {status="Accept the pairing request on your TV";return}
        if type=="error" || (payload["returnValue"] as? Bool)==false {
            let error=(obj["error"] as? String) ?? (payload["errorText"] as? String) ?? "TV rejected the command"
            log(error)
            if id=="register" {disconnect();status="Pairing rejected. Clear pairing and try again.";return}
            timeouts.removeValue(forKey:id)?.cancel()
            if let cb=pending.removeValue(forKey:id) {cb(.failure(TVFailure(message:error)))}
            return
        }
        timeouts.removeValue(forKey:id)?.cancel()
        if let cb=pending.removeValue(forKey:id) {cb(.success(payload))}
        subscriptions[id]?(payload)
    }
    func request(_ uri:String,payload:[String:Any]=[:],completion:@escaping(Result<[String:Any],Error>)->Void) {
        guard connected else {completion(.failure(TVFailure(message:"Connect the TV first")));return}
        counter += 1;let id="r\(counter)";pending[id]=completion
        send(TVProtocol.request(id:id,uri:uri,payload:payload))
        timeouts[id]=Task { [weak self] in
            try? await Task.sleep(nanoseconds:10_000_000_000)
            guard !Task.isCancelled,let self=self,let cb=self.pending.removeValue(forKey:id) else{return}
            self.timeouts.removeValue(forKey:id);cb(.failure(TVFailure(message:"TV did not reply in time")))
        }
    }
    private func subscribe(_ uri:String,callback:@escaping([String:Any])->Void) {
        counter += 1;let id="s\(counter)";subscriptions[id]=callback
        send(["id":id,"type":"subscribe","uri":"ssap://"+uri,"payload":[:]])
    }
    func command(_ uri:String,payload:[String:Any]=[:],success:String="Command accepted") {
        request(uri,payload:payload) { [weak self] r in
            switch r {
            case .success:
                self?.status=success
                if uri=="tv/switchInput" || uri=="com.webos.applicationManager/launch" {
                    self?.contextRevision += 1;self?.picture=[:];self?.verifiedKeys=[]
                }
            case .failure(let e):self?.status=e.localizedDescription
            }
        }
    }
    func refresh() {
        guard connected else{return}
        request("system/getSystemInfo") { [weak self] r in if case .success(let p)=r,let name=p["modelName"] as? String {self?.model=name} }
        request("com.webos.applicationManager/listApps") { [weak self] r in
            if case .success(let p)=r,let list=p["apps"] as? [[String:Any]] {self?.apps=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVApp(id:id,title:v["title"] as? String ?? id)}.sorted{$0.title.localizedCaseInsensitiveCompare($1.title) == ComparisonResult.orderedAscending}}
        }
        request("tv/getExternalInputList") { [weak self] r in
            if case .success(let p)=r,let list=p["devices"] as? [[String:Any]] {self?.inputs=list.compactMap{v in guard let id=v["id"] as? String else{return nil};return TVInput(id:id,title:v["label"] as? String ?? id)}}
        }
        subscribe("com.webos.applicationManager/getForegroundAppInfo") { [weak self] p in
            guard let self=self,let app=p["appId"] as? String,app != self.foregroundApp else{return}
            self.foregroundApp=app;self.contextRevision += 1;self.picture=[:];self.verifiedKeys=[];self.readPicture()
        }
        subscribe("audio/getVolume") { [weak self] p in
            let s=p["volumeStatus"] as? [String:Any] ?? p
            if let v=s["volume"] as? NSNumber,v.doubleValue>=0 {self?.volume=v.doubleValue}
            if let m=s["mute"] as? Bool ?? s["muted"] as? Bool {self?.muted=m}
        }
        request("com.webos.service.networkinput/getPointerInputSocket") { [weak self] r in
            guard let self=self else{return}
            if case .success(let p)=r,let path=p["socketPath"] as? String,let url=URL(string:path),url.scheme=="ws",url.host==self.current?.host {self.openPointer(url)}
            else {self.log("Pointer socket unavailable. Re-pair if remote buttons fail.")}
        }
        readPicture()
    }
    private func openPointer(_ url:URL) {
        let p=session.webSocketTask(with:url);pointer=p;p.resume();let token=epoch
        p.sendPing { [weak self] error in Task { @MainActor in
            guard let self=self,self.epoch==token else{return}
            self.pointerReady=error==nil
            if error != nil {self.log("Remote button socket could not open")}
        } }
        pointerReceiver=Task { [weak self] in
            do {while !Task.isCancelled {_=try await p.receive()}}
            catch {guard let self=self,self.epoch==token,!Task.isCancelled else{return};self.pointerReady=false}
        }
    }
    func button(_ name:String) {pointerSend(TVProtocol.button(name))}
    func move(dx:Int,dy:Int) {pointerSend("type:move\ndx:\(dx)\ndy:\(dy)\ndown:0\n\n")}
    func click() {pointerSend("type:click\n\n")}
    private func pointerSend(_ text:String) {
        guard connected,pointerReady,let p=pointer else {status="Remote buttons unavailable. Reconnect or clear pairing.";return}
        Task { [weak self] in do {try await p.send(.string(text))} catch {self?.status="Remote input failed"} }
    }
    func readPicture() {
        let keys=["backlight","contrast","brightness","color"]
        let revision=contextRevision
        request("settings/getSystemSettings",payload:["category":"picture","keys":keys]) { [weak self] r in
            guard let self=self,self.contextRevision==revision else{return}
            if case .success(let p)=r,let settings=p["settings"] as? [String:Any] {
                for (k,v) in settings {if let s=v as? String {self.picture[k]=s;self.verifiedKeys.insert(k)} else if let n=v as? NSNumber {self.picture[k]=n.stringValue;self.verifiedKeys.insert(k)}}
            } else {self.log("TV could not return picture settings; use Apply to request changes.")}
        }
    }
    func writePicture(_ settings:[String:String],completion:((Bool)->Void)?=nil) {
        guard connected,!settingsBusy,!settings.isEmpty else{completion?(false);return}
        settingsBusy=true
        let writeContext=contextRevision
        request("settings/setSystemSettings",payload:["category":"picture","settings":settings]) { [weak self] r in
            guard let self=self else{completion?(false);return}
            guard self.contextRevision==writeContext else{self.settingsBusy=false;self.status="Input changed during the request · verify the TV";completion?(false);return}
            switch r {
            case .success:self.accepted(settings);completion?(true)
            case .failure(let error):
                if self.useLunaFallback {self.lunaWrite(settings,completion:completion)}
                else {self.settingsBusy=false;self.status=error.localizedDescription;completion?(false)}
            }
        }
    }
    private func accepted(_ values:[String:String]) {
        if values["pictureMode"] != nil {contextRevision += 1;picture=[:];verifiedKeys=[]}
        for(k,v) in values {picture[k]=v;verifiedKeys.remove(k)}
        settingsBusy=false;status="Settings requested · refresh to verify";readPicture()
    }
    private func lunaWrite(_ values:[String:String],completion:((Bool)->Void)?=nil) {
        let writeContext=contextRevision
        let uri="luna://com.webos.settingsservice/setSystemSettings"
        let params:[String:Any]=["category":"picture","settings":values]
        let body:[String:Any]=["message":" ","buttons":[["label":"","onClick":uri,"params":params]],"onclose":["uri":uri,"params":params],"onfail":["uri":uri,"params":params]]
        request("system.notifications/createAlert",payload:body) { [weak self] r in
            guard let self=self else{completion?(false);return}
            guard case .success(let p)=r,let alert=p["alertId"] as? String else {self.settingsBusy=false;self.status="TV blocked picture writes on this firmware";completion?(false);return}
            self.request("system.notifications/closeAlert",payload:["alertId":TVProtocol.closeAlertID(alert)]) { [weak self] result in
                guard let self=self else{completion?(false);return}
                guard self.contextRevision==writeContext else{self.settingsBusy=false;self.status="Input changed during the request · verify the TV";completion?(false);return}
                if case .success=result {self.accepted(values);completion?(true)}
                else {self.settingsBusy=false;self.status="Could not complete picture setting request";completion?(false)}
            }
        }
    }
    func applyRecommended(_ preset:B9Preset,whiteBalance:String?) {
        guard connected,!settingsBusy,!presetBusy else{return}
        let token=epoch
        let initialContext=contextRevision
        presetBusy=true
        status="Requesting \(preset.name)…"
        writePicture(["pictureMode":preset.mode]) { [weak self] ok in
            guard let self=self,self.epoch==token else{return}
            guard ok else {self.presetBusy=false;self.status="Preset stopped: picture mode request failed";return}
            guard self.contextRevision==initialContext+1 else{self.presetBusy=false;self.status="Preset stopped: input changed during mode selection";return}
            let revision=self.contextRevision
            self.status="Picture mode requested · preparing values…"
            Task { [weak self] in
                try? await Task.sleep(nanoseconds:1_200_000_000)
                guard let self=self,self.epoch==token,self.connected else{return}
                guard self.contextRevision==revision else{self.presetBusy=false;self.status="Preset stopped because the input changed";return}
                var values=preset.values(whiteBalance:whiteBalance);values.removeValue(forKey:"pictureMode")
                self.writePicture(values) { [weak self] finished in
                    guard let self=self,self.epoch==token else{return}
                    self.presetBusy=false
                    self.status=finished ? "\(preset.name) requested · verify the picture on TV" : "Preset incomplete · mode may have changed; check the TV"
                }
            }
        }
    }
    func setHDMIType(input:String,pc:Bool) {
        guard connected,!settingsBusy,!presetBusy else{return}
        settingsBusy=true
        let uri="luna://com.webos.service.eim/setDeviceInfo"
        let params:[String:Any]=["id":input,"icon":pc ? "pc.png" : "hdmi.png","label":pc ? "PC" : "HDMI"]
        let body:[String:Any]=["message":" ","buttons":[["label":"","onClick":uri,"params":params]],"onclose":["uri":uri,"params":params],"onfail":["uri":uri,"params":params]]
        request("system.notifications/createAlert",payload:body) { [weak self] r in
            guard let self=self else{return}
            guard case .success(let p)=r,let id=p["alertId"] as? String else{self.settingsBusy=false;self.status="TV blocked the HDMI type request";return}
            self.request("system.notifications/closeAlert",payload:["alertId":TVProtocol.closeAlertID(id)]) { [weak self] result in
                guard let self=self else{return};self.settingsBusy=false
                if case .success=result {self.status="HDMI type requested · verify on the TV"} else {self.status="HDMI type request failed"}
            }
        }
    }
    func saveProfile(_ name:String) {
        guard let tv=current,!picture.isEmpty else{status="Read or set picture values before saving";return}
        profiles.append(PictureProfile(name:name.isEmpty ? "My picture" : name,device:tv.id,settings:picture));persist();status="Profile saved for this TV"
    }
    func deleteProfile(_ id:UUID) {profiles.removeAll{$0.id==id};persist()}
    func wake() {
        guard let tv=current else{return}
        guard let packet=TVProtocol.wakePacket(tv.mac) else {status="Add a valid TV MAC address to use Wake-on-LAN";return}
        wakeConnection?.cancel()
        let c=NWConnection(host:NWEndpoint.Host(tv.host),port:9,using:.udp);wakeConnection=c
        c.stateUpdateHandler={ [weak self] state in if case .ready=state {c.send(content:packet,completion:.contentProcessed{error in Task { @MainActor in self?.status=error==nil ? "Wake packet sent · try Connect in a few seconds" : "Wake packet could not be sent";c.cancel()}})} }
        c.start(queue:.main)
        status="Sending Wake-on-LAN…"
        Task {try? await Task.sleep(nanoseconds:4_000_000_000);c.cancel()}
    }
}

struct PictureSetting: Identifiable {
    var id:String {key}
    let key:String
    let title:String
    let range:ClosedRange<Double>?
    let options:[String]
    static let all:[PictureSetting]=[
        .init(key:"backlight",title:"OLED pixel brightness",range:0...100,options:[]),
        .init(key:"contrast",title:"Contrast",range:0...100,options:[]),
        .init(key:"brightness",title:"Brightness / black level",range:0...100,options:[]),
        .init(key:"color",title:"Colour depth",range:0...100,options:[]),
        .init(key:"tint",title:"Tint",range:-50...50,options:[]),
        .init(key:"colorTemperature",title:"Colour temperature",range:-50...50,options:[]),
        .init(key:"dynamicColor",title:"Colour adjustment",range:nil,options:["off","low","medium","high"]),
        .init(key:"noiseReduction",title:"Noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"mpegNoiseReduction",title:"MPEG noise reduction",range:nil,options:["off","low","medium","high","auto"]),
        .init(key:"sharpness",title:"Sharpness",range:0...50,options:[]),
        .init(key:"peakBrightness",title:"Peak brightness",range:nil,options:["off","low","medium","high"]),
        .init(key:"hdrDynamicToneMapping",title:"HDR tone mapping",range:nil,options:["off","on","HGIG"]),
        .init(key:"whiteBalanceColorTemperature",title:"White balance",range:nil,options:["cool","medium","warm1","warm2"]),
        .init(key:"blackLevel",title:"HDMI black level",range:nil,options:["low","medium","high"]),
        .init(key:"colorGamut",title:"Colour gamut",range:nil,options:["auto","extended","wide","srgb"]),
        .init(key:"superResolution",title:"Super resolution",range:nil,options:["off","low","medium","high"]),
        .init(key:"dynamicContrast",title:"Dynamic contrast",range:nil,options:["off","low","medium","high"]),
        .init(key:"smoothGradation",title:"Smooth gradation",range:nil,options:["off","low","medium","high"]),
        .init(key:"gamma",title:"Gamma",range:nil,options:["low","medium","high1","high2"]),
        .init(key:"truMotionMode",title:"TruMotion",range:nil,options:["off","smooth","clear","user"]),
        .init(key:"truMotionJudder",title:"De-judder",range:0...10,options:[]),
        .init(key:"truMotionBlur",title:"De-blur",range:0...10,options:[]),
        .init(key:"realCinema",title:"Real cinema",range:nil,options:["off","on"]),
        .init(key:"motionEyeCare",title:"Motion eye care",range:nil,options:["off","on"]),
        .init(key:"motionPro",title:"OLED Motion / BFI",range:nil,options:["off","on"]),
        .init(key:"pictureMode",title:"Picture mode",range:nil,options:["cinema","expert1","expert2","game","normal","hdrCinema","hdrGame","dolbyHdrCinema","dolbyHdrCinemaBright","dolbyHdrGame"])
    ]
}

private struct PrismGlass:ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @ViewBuilder func body(content:Content)->some View {
        if reduceTransparency {
            content.background(Color(red:0.11,green:0.13,blue:0.19),in:RoundedRectangle(cornerRadius:28))
        } else {
#if compiler(>=6.2)
            if #available(iOS 26.0,*) {
                content.glassEffect(.regular.tint(Color(red:0.12,green:0.16,blue:0.24).opacity(0.42)),in:RoundedRectangle(cornerRadius:28))
            } else {content.background(.ultraThinMaterial,in:RoundedRectangle(cornerRadius:28))}
#else
            content.background(.ultraThinMaterial,in:RoundedRectangle(cornerRadius:28))
#endif
        }
    }
}
private struct PrismGlassGroup<Content:View>:View {
    let content:Content
    init(@ViewBuilder content:()->Content){self.content=content()}
    @ViewBuilder var body:some View {
#if compiler(>=6.2)
        if #available(iOS 26.0,*) {GlassEffectContainer(spacing:16){content}}
        else {content}
#else
        content
#endif
    }
}
private extension View {func prismGlass()->some View{modifier(PrismGlass())}}
private let cyan=Color(red:0.02,green:0.84,blue:0.94)

@main struct PrismApp:App {
    @StateObject private var tv=WebOSTV()
    var body:some Scene {WindowGroup {PrismView().environmentObject(tv).preferredColorScheme(.dark)}}
}

struct PrismView:View {
    @EnvironmentObject private var tv:WebOSTV
    @StateObject private var discovery=TVDiscovery()
    @State private var tab=0
    @State private var showAdd=false
    @State private var showKeyboard=false
    @State private var text=""
    @State private var pendingPower=false
    @State private var profileName=""
    @State private var browseSignal:B9Signal = .sdr
    @State private var recommended:B9Preset?
    @State private var showProfile=false
    @State private var name="LG B9"
    @State private var host=""
    @State private var mac=""
    @State private var appSearch=""
    @State private var touchPoint:CGSize = .zero
    private let columns=[GridItem(.flexible()),GridItem(.flexible())]
    private var background:some View {
        LinearGradient(colors:[Color(red:0.055,green:0.075,blue:0.12),Color(red:0.025,green:0.03,blue:0.045)],startPoint:.top,endPoint:.bottom).ignoresSafeArea()
    }
    var body:some View {
        TabView(selection:$tab) {
            page("Prism TV") {remotePage}.tabItem{Label("Remote",systemImage:"dpad")}.tag(0)
            PicturePage(onClose:{tab=0}).tabItem{Label("Display",systemImage:"slider.horizontal.3")}.tag(1)
            page("Apps & inputs") {appsPage}.tabItem{Label("Apps",systemImage:"square.grid.2x2")}.tag(2)
            page("Profiles") {profilesPage}.tabItem{Label("Profiles",systemImage:"bookmark")}.tag(3)
            page("Your TVs") {devicesPage}.tabItem{Label("TVs",systemImage:"tv")}.tag(4)
        }.tint(cyan)
        .sheet(isPresented:$showAdd,onDismiss:{discovery.stop()}){addSheet}
        .sheet(isPresented:$showKeyboard){keyboardSheet}
        .sheet(item:$recommended){preset in B9PresetSheet(preset:preset).environmentObject(tv)}
        .alert("Turn off TV?",isPresented:$pendingPower){Button("Turn off",role:.destructive){tv.command("system/turnOff",success:"Power off requested")};Button("Cancel",role:.cancel){}}message:{Text("This puts the selected TV in standby.")}
        .alert("Save picture profile",isPresented:$showProfile){TextField("Profile name",text:$profileName);Button("Save"){tv.saveProfile(profileName);profileName=""};Button("Cancel",role:.cancel){}}message:{Text("Saves the values read or requested in this session for the selected TV. Apply them in the same input and SDR/HDR/Dolby Vision context.")}
        .onOpenURL { url in
            if url.host=="display" {tab=1} else if url.host=="apps" {tab=2} else {tab=0}
        }
    }
    private func page<Content:View>(_ title:String,@ViewBuilder content:()->Content)->some View {
        NavigationStack {
            ScrollView {PrismGlassGroup {VStack(spacing:20){connectionCard;content();status}.padding(.horizontal,20).padding(.top,12).padding(.bottom,24)}}
                .background(background).navigationTitle(title)
        }
    }
    private var status:some View {Text(tv.status).font(.caption).foregroundStyle(.secondary).frame(maxWidth:.infinity,alignment:.leading).padding(.horizontal,4)}
    private var connectionCard:some View {
        HStack(spacing:12) {
            Image(systemName:"tv").font(.title2).foregroundStyle(cyan)
            VStack(alignment:.leading,spacing:5){Text(tv.current?.name ?? "No TV selected").font(.subheadline.weight(.semibold));Text(tv.connected ? tv.model : tv.connecting ? "Approve on TV…" : "Same Wi-Fi required").font(.caption).foregroundStyle(.secondary)}
            Spacer(minLength:2)
            Button(tv.connected ? "Disconnect" : tv.connecting ? "Cancel" : "Connect") {
                if tv.connected || tv.connecting {tv.disconnect()} else if tv.current==nil {showAdd=true} else {tv.connect()}
            }.font(.caption.weight(.semibold)).buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(Color.black)
        }.padding(18).prismGlass()
    }
    private var remotePage:some View {
        VStack(spacing:20) {
            HStack(spacing:12) {
                remoteKey("Home",icon:"house",key:"HOME")
                remoteKey("Back",icon:"arrow.uturn.backward",key:"BACK")
                remoteKey("Settings",icon:"gearshape",key:"MENU")
                Button{pendingPower=true}label:{Image(systemName:"power").font(.title3).frame(maxWidth:.infinity,minHeight:54)}.foregroundStyle(.red).prismGlass().disabled(!tv.connected)
            }
            VStack(spacing:9) {
                remoteKey("Up",icon:"chevron.up",key:"UP")
                HStack(spacing:9) {
                    remoteKey("Left",icon:"chevron.left",key:"LEFT")
                    Button{tv.button("ENTER")}label:{Text("OK").font(.title2.weight(.semibold)).frame(width:94,height:80)}.buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(Color.black).buttonBorderShape(.roundedRectangle(radius:26))
                    remoteKey("Right",icon:"chevron.right",key:"RIGHT")
                }
                remoteKey("Down",icon:"chevron.down",key:"DOWN")
            }.padding(18).prismGlass().disabled(!tv.connected || !tv.pointerReady)
            HStack(spacing:12) {
                Button{tv.command("audio/volumeDown")}label:{Image(systemName:"speaker.minus").frame(maxWidth:.infinity,minHeight:54)}.prismGlass()
                Button{tv.command("audio/setMute",payload:["mute":!tv.muted])}label:{Image(systemName:tv.muted ? "speaker.slash" : "speaker.wave.2").frame(maxWidth:.infinity,minHeight:54)}.prismGlass()
                Button{tv.command("audio/volumeUp")}label:{Image(systemName:"speaker.plus").frame(maxWidth:.infinity,minHeight:54)}.prismGlass()
            }.font(.title3).disabled(!tv.connected)
            if let volume=tv.volume {
                Text("Volume \(Int(volume))").font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing:12) {
                remoteKey("Rewind",icon:"backward.fill",key:"REWIND")
                remoteKey("Play",icon:"play.fill",key:"PLAY")
                remoteKey("Pause",icon:"pause.fill",key:"PAUSE")
                remoteKey("Stop",icon:"stop.fill",key:"STOP")
            }
            DisclosureGroup("Touchpad & keyboard") {
                VStack(spacing:16) {
                    RoundedRectangle(cornerRadius:24).fill(.white.opacity(0.04))
                        .overlay(Label("Swipe to move · tap to click",systemImage:"hand.draw").font(.caption).foregroundStyle(.secondary))
                        .frame(height:130).contentShape(Rectangle())
                        .gesture(DragGesture(minimumDistance:2).onChanged{v in
                            let dx=v.translation.width-touchPoint.width,dy=v.translation.height-touchPoint.height
                            if abs(dx)+abs(dy)>4 {tv.move(dx:Int(dx*1.4),dy:Int(dy*1.4));touchPoint=v.translation}
                        }.onEnded{_ in touchPoint = .zero})
                        .simultaneousGesture(TapGesture().onEnded{tv.click()})
                    Button{showKeyboard=true}label:{Label("Type on TV",systemImage:"keyboard")}.buttonStyle(.bordered)
                    HStack{remoteKey("Channel down",icon:"chevron.down",key:"CHANNELDOWN");remoteKey("Channel up",icon:"chevron.up",key:"CHANNELUP")}
                    LazyVGrid(columns:Array(repeating:GridItem(.flexible()),count:3),spacing:8){ForEach(0..<10,id:\.self){n in Button("\(n)"){tv.button("\(n)")}.buttonStyle(.bordered).frame(minHeight:44)}}
                }.padding(.top,14)
            }.padding(18).prismGlass().disabled(!tv.connected)
            Button{tv.wake()}label:{Label("Wake TV",systemImage:"power.circle")}.buttonStyle(.bordered).disabled(tv.current==nil)
        }
    }
    private func remoteKey(_ title:String,icon:String,key:String)->some View {
        Button{tv.button(key)}label:{Image(systemName:icon).font(.title3).frame(maxWidth:.infinity,minHeight:54)}
            .buttonStyle(.plain).prismGlass().accessibilityLabel(title).disabled(!tv.connected || !tv.pointerReady)
    }
    private var appsPage:some View {
        VStack(alignment:.leading,spacing:16) {
            Text("Inputs").font(.headline)
            if tv.inputs.isEmpty {Text("Connect to load your TV inputs.").font(.caption).foregroundStyle(.secondary)}
            ForEach(tv.inputs){input in
                Button{tv.command("tv/switchInput",payload:["inputId":input.id])}label:{HStack{Image(systemName:"cable.connector");Text(input.title);Spacer();Image(systemName:"arrow.up.right")}.padding(18)}.prismGlass()
            }
            Text("TV apps").font(.headline).padding(.top,10)
            TextField("Search apps",text:$appSearch).padding(15).prismGlass()
            if tv.apps.isEmpty {Text("Connect to load installed TV apps.").font(.caption).foregroundStyle(.secondary)}
            LazyVGrid(columns:columns,spacing:12){ForEach(tv.apps.filter{appSearch.isEmpty || $0.title.localizedCaseInsensitiveContains(appSearch)}){app in
                Button{tv.command("com.webos.applicationManager/launch",payload:["id":app.id])}label:{VStack(alignment:.leading,spacing:14){Image(systemName:"play.tv").font(.title2);Text(app.title).font(.subheadline.weight(.medium)).frame(maxWidth:.infinity,alignment:.leading)}.padding(18)}.buttonStyle(.plain).prismGlass()
            }}
        }.disabled(!tv.connected)
    }
    private var profilesPage:some View {
        VStack(alignment:.leading,spacing:18) {
            HStack {Text("Recommended for LG B9").font(.title3.weight(.semibold));Spacer();Image(systemName:"sparkles").foregroundStyle(cyan)}
            Text("Starting points, not a panel calibration. Preview the values, then apply while the correct signal is playing.").font(.caption).foregroundStyle(.secondary)
            Picker("Browse signal presets",selection:$browseSignal){ForEach(B9Signal.allCases){signal in Text(signal.rawValue).tag(signal)}}.pickerStyle(.segmented)
            ForEach(B9Preset.all.filter{$0.signal==browseSignal}){preset in
                Button {recommended=preset} label: {
                    HStack(spacing:14) {
                        Image(systemName:preset.symbol).font(.title2).foregroundStyle(cyan).frame(width:32)
                        VStack(alignment:.leading,spacing:6){Text(preset.name).font(.headline);Text(preset.subtitle).font(.caption).foregroundStyle(.secondary)}
                        Spacer(minLength:2);Image(systemName:"chevron.right").font(.caption).foregroundStyle(.secondary)
                    }.padding(20)
                }.buttonStyle(.plain).prismGlass()
            }
            DisclosureGroup("My saved profiles") {
                VStack(alignment:.leading,spacing:16) {
                    Text("Applies to the current input and signal. These are your saved values, separate from the B9 starting presets.").font(.caption).foregroundStyle(.secondary)
                    Button{showProfile=true}label:{Label("Save current settings",systemImage:"plus")}.buttonStyle(.borderedProminent).disabled(!tv.connected || tv.picture.isEmpty || tv.presetBusy)
                    ForEach(tv.profiles.filter{$0.device==tv.selected}){profile in
                        VStack(alignment:.leading,spacing:14) {
                            HStack{Text(profile.name).font(.headline);Spacer();Button{tv.deleteProfile(profile.id)}label:{Image(systemName:"trash")}.accessibilityLabel("Delete "+profile.name)}
                            Text("\(profile.settings.count) settings").font(.caption).foregroundStyle(.secondary)
                            Button("Apply profile"){tv.writePicture(profile.settings)}.buttonStyle(.bordered).disabled(!tv.connected || tv.settingsBusy || tv.presetBusy)
                        }.padding(18).prismGlass()
                    }
                }.padding(.top,16)
            }.padding(20).prismGlass()
        }
    }
    private var devicesPage:some View {
        VStack(alignment:.leading,spacing:16) {
            ForEach(tv.devices){d in
                VStack(alignment:.leading,spacing:12){
                    HStack{Image(systemName:"tv");Text(d.name).font(.headline);Spacer();if tv.selected==d.id{Image(systemName:"checkmark.circle.fill").foregroundStyle(cyan)}}
                    Text(d.host).font(.system(.caption,design:.monospaced)).foregroundStyle(.secondary)
                    HStack{Button("Select"){tv.select(d.id)}.buttonStyle(.bordered);Spacer();Button(role:.destructive){tv.remove(d.id)}label:{Image(systemName:"trash")}}
                }.padding(20).prismGlass()
            }
            Button{showAdd=true}label:{Label("Find TV on Wi-Fi",systemImage:"wifi")}.buttonStyle(.borderedProminent)
            Button("Clear selected TV pairing"){tv.forgetPairing()}.buttonStyle(.bordered).disabled(tv.current==nil)
            Toggle("Picture compatibility method",isOn:$tv.useLunaFallback).padding(18).prismGlass()
            Text("Uses the TV's alert callback for picture writes if the direct command is rejected. A brief TV popup may appear. No setting is changed by enabling this option alone.").font(.caption).foregroundStyle(.secondary)
            DisclosureGroup("Connection help"){
                Text("Use the same Wi-Fi as the TV. Find its IP in LG Network settings. The TV must be on for first pairing; accept the popup with your physical remote. This build targets LG B9 and compatible models exposing local WebSocket port 3000. TLS-only models are not supported in this version.\n\nWake-on-LAN needs the TV's network MAC and Mobile TV On / Wake via Wi-Fi enabled. Unicast wake packets may not work after your router forgets the TV.\n\nAutomatic search checks nearby IPv4 addresses on this Wi-Fi and confirms webOS with a hello response. Large networks are limited to the phone’s local /24. The TV must be on. If it is not found, enter the IP manually.").font(.caption).foregroundStyle(.secondary).padding(.top,12)
            }.padding(18).prismGlass()
            DisclosureGroup("Diagnostics"){
                ForEach(Array(tv.diagnostics.enumerated()),id:\.offset){_,message in Text(message).font(.system(.caption2,design:.monospaced)).frame(maxWidth:.infinity,alignment:.leading).padding(.vertical,4)}
            }.padding(18).prismGlass()
            Text("Prism TV 1.1.0 · Independent webOS remote").font(.caption2).foregroundStyle(.secondary)
        }
    }
    private var addSheet:some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:20) {
                    VStack(alignment:.leading,spacing:8) {
                        Image(systemName:"tv.and.mediabox").font(.system(size:38,weight:.light)).foregroundStyle(cyan)
                        Text("Your TV, nearby.").font(.title2.weight(.semibold))
                        Text("Keep your LG TV on and use the same Wi-Fi. Pairing starts only after you select it.").font(.subheadline).foregroundStyle(.secondary)
                    }.padding(.vertical,8)
                    VStack(alignment:.leading,spacing:15) {
                        HStack {
                            Label("Nearby TVs",systemImage:"wifi").font(.headline)
                            Spacer()
                            if discovery.searching {Button("Stop"){discovery.stop()}.font(.subheadline)}
                            else {Button("Search again"){discovery.start()}.font(.subheadline)}
                        }
                        if discovery.searching {
                            ProgressView(value:discovery.progress).tint(cyan)
                            Text("Checking Wi-Fi · \(discovery.checked) / \(discovery.total)").font(.caption).foregroundStyle(.secondary).monospacedDigit()
                        }
                        Text(discovery.message).font(.caption).foregroundStyle(.secondary)
                        ForEach(discovery.found){device in
                            Button {
                                discovery.stop()
                                if tv.add(name:device.name,host:device.host,mac:"") {showAdd=false;tv.connect()}
                            } label: {
                                HStack(spacing:12) {
                                    Image(systemName:"tv").font(.title2).foregroundStyle(cyan)
                                    VStack(alignment:.leading,spacing:5){Text(device.name).font(.subheadline.weight(.medium));Text(device.host).font(.caption).foregroundStyle(.secondary)}
                                    Spacer();Image(systemName:"chevron.right").font(.caption)
                                }.padding(.vertical,8).frame(minHeight:44)
                            }.buttonStyle(.plain)
                        }
                        if discovery.denied {
                            Button("Open iPhone settings") {if let url=URL(string:UIApplication.openSettingsURLString){UIApplication.shared.open(url)}}.font(.subheadline)
                        }
                    }.padding(20).prismGlass()
                    DisclosureGroup("Add by IP instead") {
                        VStack(spacing:15) {
                            TextField("TV name",text:$name)
                            TextField("IP address · 192.168.0.110",text:$host).keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled()
                            TextField("MAC address · optional for wake",text:$mac).textInputAutocapitalization(.characters).autocorrectionDisabled()
                            Button("Save TV") {if tv.add(name:name,host:host,mac:mac){discovery.stop();showAdd=false;host="";mac=""}}.buttonStyle(.borderedProminent).frame(maxWidth:.infinity)
                            Text(tv.status).font(.caption).foregroundStyle(.secondary)
                        }.padding(.top,18).textFieldStyle(.roundedBorder)
                    }.padding(20).prismGlass()
                }.padding(20)
            }.background(background).navigationTitle("Find TV").navigationBarTitleDisplayMode(.inline)
                .toolbar{ToolbarItem(placement:.cancellationAction){Button("Close"){showAdd=false}}}
                .task{discovery.start()}
        }.tint(cyan)
    }
    private var keyboardSheet:some View {
        NavigationStack {
            Form {
                Section {
                    Text("Open a text field on the TV first.").font(.caption).foregroundStyle(.secondary)
                    TextField("Text to send",text:$text)
                    Button("Send text") {tv.command("com.webos.service.ime/insertText",payload:["text":text,"replace":0]);text=""}.disabled(text.isEmpty)
                    Button("Enter") {tv.command("com.webos.service.ime/sendEnterKey")}
                    Button("Delete character") {tv.command("com.webos.service.ime/deleteCharacters",payload:["count":1])}
                }
            }.navigationTitle("TV keyboard")
                .toolbar {ToolbarItem(placement:.confirmationAction){Button("Done"){showKeyboard=false}}}
        }
    }
}

struct PicturePage:View {
    @EnvironmentObject private var tv:WebOSTV
    let onClose:()->Void
    @State private var category="Picture"
    @State private var search=""
    @State private var info:PictureSetting?
    @State private var hdmi="HDMI_1"
    private var settings:[PictureSetting] {
        if !search.isEmpty {return PictureSetting.all.filter{$0.title.localizedCaseInsensitiveContains(search)}}
        let gaming:Set<String>=["hdrDynamicToneMapping","truMotionMode","truMotionJudder","truMotionBlur","motionPro"]
        let advanced:Set<String>=["pictureMode","whiteBalanceColorTemperature","gamma","blackLevel","colorGamut"]
        return PictureSetting.all.filter{s in category=="Gaming" ? gaming.contains(s.key) : category=="Advanced" ? advanced.contains(s.key) : !gaming.contains(s.key) && !advanced.contains(s.key)}
    }
    private var groups:[(String,[PictureSetting])] {
        if category != "Picture" || !search.isEmpty {return [(search.isEmpty ? category.uppercased() : "SEARCH RESULTS",settings)]}
        let brightness:Set<String>=["backlight","contrast","brightness","dynamicContrast","peakBrightness","motionEyeCare"]
        let colour:Set<String>=["color","tint","colorTemperature","dynamicColor"]
        return [("BRIGHTNESS",settings.filter{brightness.contains($0.key)}),("COLOUR",settings.filter{colour.contains($0.key)}),("CLARITY",settings.filter{!brightness.contains($0.key) && !colour.contains($0.key)})]
    }
    var body:some View {
        NavigationStack {
            ScrollView {
                PrismGlassGroup {
                LazyVStack(spacing:16) {
                    HStack{Circle().fill(tv.connected ? Color.green : Color.gray).frame(width:6,height:6);Text(tv.current?.name ?? "No TV selected");Spacer();Button("Refresh"){tv.readPicture()}.disabled(!tv.connected)}.font(.caption).foregroundStyle(.secondary).padding(.horizontal,4)
                    if !tv.connected {Text("Connect your TV from Remote before changing settings.").font(.caption).foregroundStyle(.secondary).frame(maxWidth:.infinity,alignment:.leading)}
                    if category=="Advanced" && search.isEmpty {hdmiCard}
                    ForEach(groups,id:\.0){group in
                        if !group.1.isEmpty {
                            Text(group.0).font(.caption.weight(.semibold)).tracking(2).foregroundStyle(.secondary).frame(maxWidth:.infinity,alignment:.leading).padding(.top,16).padding(.bottom,3)
                            ForEach(group.1){setting in SettingCard(setting:setting,info:{info=setting})}
                        }
                    }
                    if settings.isEmpty {Text("No settings match your search.").foregroundStyle(.secondary).padding(30)}
                    Text(tv.status).font(.caption).foregroundStyle(.secondary).frame(maxWidth:.infinity,alignment:.leading).padding(.top,8)
                    Text("LIVE = last value read from TV · SET = last requested value. Availability depends on input, signal and firmware.").font(.caption2).foregroundStyle(.secondary).frame(maxWidth:.infinity,alignment:.leading)
                }.padding(.horizontal,22).padding(.top,12).padding(.bottom,24)
                }
            }.background(LinearGradient(colors:[Color(red:0.06,green:0.08,blue:0.13),Color(red:0.025,green:0.03,blue:0.045)],startPoint:.top,endPoint:.bottom).ignoresSafeArea())
                .navigationTitle("Display Settings").navigationBarTitleDisplayMode(.inline)
                .toolbar(.hidden,for:.tabBar)
                .toolbar{ToolbarItem(placement:.topBarLeading){Button(action:onClose){Image(systemName:"chevron.left")}.accessibilityLabel("Back to remote")}}
                .safeAreaInset(edge:.bottom){
                    VStack(spacing:12){
                        HStack(spacing:9){
                            categoryButton("Picture",symbol:"photo.on.rectangle")
                            categoryButton("Gaming",symbol:"gamecontroller.fill")
                            categoryButton("Advanced",symbol:"gearshape.2.fill")
                        }
                        HStack(spacing:10){Image(systemName:"magnifyingglass").foregroundStyle(.secondary);TextField("Search settings…",text:$search).autocorrectionDisabled();if !search.isEmpty{Button{search=""}label:{Image(systemName:"xmark.circle.fill").foregroundStyle(.secondary)}}}.padding(17).background(.ultraThinMaterial,in:Capsule())
                    }.padding(.horizontal,18).padding(.top,12).padding(.bottom,12).background(.ultraThinMaterial)
                }
                .sheet(item:$info){s in NavigationStack{ScrollView{VStack(alignment:.leading,spacing:18){Text(s.title).font(.title2.weight(.semibold));Text(explanation(s)).font(.body);Text("If the TV refuses a value, check the active input and picture mode. A SET badge only records the requested value; LIVE requires a successful read-back.").font(.caption).foregroundStyle(.secondary)}.padding(24)}.navigationTitle("Setting info").navigationBarTitleDisplayMode(.inline).toolbar{ToolbarItem(placement:.confirmationAction){Button("Done"){info=nil}}}}.presentationDetents([.medium,.large])}
        }.tint(cyan)
    }
    private var hdmiCard:some View {
        VStack(alignment:.leading,spacing:14) {
            Label("HDMI type",systemImage:"display").font(.headline)
            Picker("Target input",selection:$hdmi) {ForEach(1..<5,id:\.self){n in Text("HDMI \(n)").tag("HDMI_\(n)")}}.pickerStyle(.menu)
            HStack(spacing:12) {
                Button("PC"){tv.setHDMIType(input:hdmi,pc:true)}.buttonStyle(.bordered)
                Button("Regular HDMI"){tv.setHDMIType(input:hdmi,pc:false)}.buttonStyle(.bordered)
            }.disabled(!tv.connected || tv.settingsBusy || tv.presetBusy)
            Text("Select the target input first. This sends a change; it does not report the current input type.").font(.caption2).foregroundStyle(.secondary)
        }.padding(18).prismGlass()
    }
    private func categoryButton(_ title:String,symbol:String)->some View {
        Button{category=title}label:{HStack(spacing:6){Image(systemName:symbol);Text(title)}.font(.caption.weight(.semibold)).foregroundStyle(category==title ? cyan : Color.primary).frame(maxWidth:.infinity,minHeight:44).padding(.horizontal,5).background(.white.opacity(category==title ? 0.12 : 0.06),in:Capsule()).overlay(Capsule().stroke(.white.opacity(0.12),lineWidth:0.7))}.buttonStyle(.plain)
    }
    private func explanation(_ s:PictureSetting)->String {
        switch s.key {
        case "backlight":return "Changes the OLED pixel light level for the current picture mode. This is separate from Brightness / black level."
        case "brightness":return "Adjusts the near-black signal level. This is separate from the HDMI video-range selector."
        case "peakBrightness":return "Requests Off, Low, Medium or High even if the TV menu greys out the control. Whether the value takes effect still depends on the current signal and firmware."
        case "blackLevel":return "HDMI signal range on B9-style webOS: Low = Limited, Medium = Auto, High = Full. Match it to the source. Auto may only take effect with supported input types."
        case "gamma":return "LG values map to Low ≈ 1.9, Medium ≈ 2.2, High 1 ≈ 2.4, High 2 ≈ BT.1886. The selected mode and signal can restrict availability."
        case "hdrDynamicToneMapping":return "Off, On or HGiG for supported HDR10 picture modes. This is not Dolby Vision tone mapping."
        case "whiteBalanceColorTemperature":return "Requests the TV's white-balance preset: Cool, Medium, Warm 1 or Warm 2. These are TV presets, not calibrated Kelvin values."
        case "truMotionMode":return "Motion interpolation preset. Judder and blur controls usually require User mode and may be unavailable during gaming or VRR."
        case "colorTemperature":return "LG's -50 to +50 cool/warm adjustment. This is not a Kelvin scale."
        default:return "Requests \(s.title.lowercased()) for the currently active picture mode. The available values can vary by model, signal, input and firmware."
        }
    }
}

struct SettingCard:View {
    @EnvironmentObject private var tv:WebOSTV
    let setting:PictureSetting
    let info:()->Void
    @State private var draft=50.0
    @State private var editing=false
    @State private var touched=false
    private var stored:String? {tv.picture[setting.key]}
    private var range:ClosedRange<Double> {setting.range ?? (0...100)}
    private var number:Double {if touched{return draft};return Double(stored ?? "") ?? min(range.upperBound,max(range.lowerBound,50))}
    private var symbol:String {
        if ["sharpness","superResolution","noiseReduction","mpegNoiseReduction","smoothGradation"].contains(setting.key){return "camera.aperture"}
        if ["color","colorGamut","tint"].contains(setting.key){return "paintpalette"}
        if setting.key.lowercased().contains("temperature"){return "thermometer.medium"}
        if setting.key=="realCinema"{return "film"}
        if setting.key.contains("truMotion"){return "play.circle"}
        return "sun.max"
    }
    var body:some View {
        VStack(alignment:.leading,spacing:15){
            HStack(spacing:8){
                Image(systemName:symbol).font(.subheadline)
                Text(setting.title).font(.headline).fixedSize(horizontal:false,vertical:true)
                Spacer(minLength:3)
                if setting.range != nil {Text(touched ? String(Int(draft)) : stored ?? "—").font(.subheadline.weight(.semibold)).monospacedDigit()}
                if stored != nil {
                    Text(tv.verifiedKeys.contains(setting.key) ? "LIVE" : "SET").font(.system(size:8,weight:.bold)).tracking(0.5).foregroundStyle(tv.verifiedKeys.contains(setting.key) ? cyan : .orange).padding(.horizontal,5).padding(.vertical,3).overlay(RoundedRectangle(cornerRadius:4).stroke(tv.verifiedKeys.contains(setting.key) ? cyan : .orange,lineWidth:0.8))
                }
                Button(action:info){Image(systemName:"info.circle").foregroundStyle(cyan).frame(width:26,height:32)}.accessibilityLabel("About "+setting.title)
            }
            if setting.range != nil {
                HStack(spacing:10){
                    step(-1)
                    Slider(value:Binding(get:{number},set:{draft=$0;touched=true}),in:range,step:1,onEditingChanged:{active in editing=active;if !active{submit()}}).tint(cyan).accessibilityLabel(setting.title)
                    step(1)
                }.disabled(!tv.connected || tv.settingsBusy || tv.presetBusy)
            } else if setting.options.count>6 {
                Menu{
                    ForEach(setting.options,id:\.self){value in Button(label(value)){tv.writePicture([setting.key:value])}}
                }label:{HStack{Text(stored.map{label($0)} ?? "Current value unavailable").lineLimit(1);Spacer();Image(systemName:"chevron.down")}.font(.subheadline).padding(17).background(.white.opacity(0.08),in:RoundedRectangle(cornerRadius:18))}.disabled(!tv.connected || tv.settingsBusy || tv.presetBusy)
            } else {
                ScrollView(.horizontal,showsIndicators:false){HStack(spacing:7){ForEach(setting.options,id:\.self){value in
                    Button{tv.writePicture([setting.key:value])}label:{Text(label(value)).font(.subheadline.weight(.medium)).foregroundStyle(stored==value ? Color.black : Color.primary).padding(.horizontal,15).frame(minHeight:43).background(stored==value ? cyan : Color.white.opacity(0.075),in:RoundedRectangle(cornerRadius:16)).overlay(RoundedRectangle(cornerRadius:16).stroke(.white.opacity(stored==value ? 0.35 : 0.065),lineWidth:0.7))}.buttonStyle(.plain)
                }}}.disabled(!tv.connected || tv.settingsBusy || tv.presetBusy)
            }
        }.padding(17).prismGlass()
        .onChange(of:stored){_ in if !editing {touched=false}}
    }
    private func label(_ value:String)->String {
        if setting.key=="gamma" {return ["low":"1.9","medium":"2.2","high1":"2.4","high2":"BT.1886"][value] ?? value}
        if setting.key=="blackLevel" {return ["low":"Limited","medium":"Auto","high":"Full"][value] ?? value}
        return ["HGIG":"HGiG","warm1":"Warm 1","warm2":"Warm 2","srgb":"sRGB","hdrCinema":"HDR Cinema","hdrGame":"HDR Game","dolbyHdrCinema":"DV Cinema","dolbyHdrCinemaBright":"DV Cinema Home","dolbyHdrGame":"DV Game","expert1":"Expert Bright","expert2":"Expert Dark"][value] ?? value.prefix(1).uppercased()+String(value.dropFirst())
    }
    private func submit(){tv.writePicture([setting.key:String(Int(number))])}
    private func step(_ delta:Double)->some View {
        Button{draft=min(range.upperBound,max(range.lowerBound,number+delta));touched=true;submit()}label:{Image(systemName:delta<0 ? "minus" : "plus").font(.title3.weight(.medium)).foregroundStyle(.primary).frame(width:42,height:43).background(.white.opacity(0.075),in:RoundedRectangle(cornerRadius:14)).overlay(RoundedRectangle(cornerRadius:14).stroke(.white.opacity(0.15),lineWidth:1))}.buttonStyle(.plain).accessibilityLabel((delta<0 ? "Decrease " : "Increase ")+setting.title)
    }
}

struct B9PresetSheet:View {
    @EnvironmentObject private var tv:WebOSTV
    @Environment(\.dismiss) private var dismiss
    let preset:B9Preset
    @State private var correctSignal=false
    @AppStorage("prism.b9.whiteBalanceOverride") private var whiteBalance="preset"
    private var requested:[String:String] {preset.values(whiteBalance:whiteBalance=="preset" ? nil : whiteBalance)}
    var body:some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:20) {
                    HStack(spacing:14) {
                        Image(systemName:preset.symbol).font(.largeTitle).foregroundStyle(cyan)
                        VStack(alignment:.leading,spacing:6){Text(preset.name).font(.title2.weight(.semibold));Text(preset.signal.rawValue+" · LG B9").font(.subheadline).foregroundStyle(.secondary)}
                    }.padding(.vertical,10)
                    Text(preset.notes).font(.subheadline).foregroundStyle(.secondary)
                    VStack(alignment:.leading,spacing:14) {
                        Text("White balance preference").font(.headline)
                        Picker("White balance override",selection:$whiteBalance){Text("Preset").tag("preset");Text("Warm 1").tag("warm1");Text("Warm 2").tag("warm2")}.pickerStyle(.segmented)
                        Text("Preset keeps its designed value. Warm 1 is your optional preference; Warm 2 is the reference starting point in the SDR/HDR presets. Dolby Vision keeps its mode's white balance unless you explicitly override it.").font(.caption).foregroundStyle(.secondary)
                    }.padding(20).prismGlass()
                    VStack(alignment:.leading,spacing:12) {
                        Text("Values to request").font(.headline)
                        ForEach(requested.keys.sorted(),id:\.self){key in
                            HStack(alignment:.firstTextBaseline,spacing:12) {
                                Text(PictureSetting.all.first{$0.key==key}?.title ?? key).font(.subheadline)
                                Spacer(minLength:12)
                                Text(displayValue(key,requested[key] ?? "")).font(.subheadline.weight(.medium)).foregroundStyle(cyan).multilineTextAlignment(.trailing)
                            }.padding(.vertical,4)
                        }
                    }.padding(20).prismGlass()
                    if preset.signal == .dolbyVision {
                        Label("Brightness, contrast and colour are intentionally not overwritten.",systemImage:"checkmark.shield").font(.caption).foregroundStyle(.secondary)
                    }
                    VStack(alignment:.leading,spacing:14) {
                        Toggle("The TV is currently showing \(preset.signal.rawValue)",isOn:$correctSignal).font(.subheadline)
                        Text("Confirm this on the television. Prism does not automatically detect SDR/HDR/Dolby Vision in this version.").font(.caption).foregroundStyle(.secondary)
                        Button {
                            tv.applyRecommended(preset,whiteBalance:whiteBalance=="preset" ? nil : whiteBalance)
                        } label: {
                            HStack {
                                if tv.presetBusy {ProgressView().tint(.black)}
                                Text(tv.presetBusy ? "Sending preset…" : "Apply to selected TV").fontWeight(.semibold)
                            }.frame(maxWidth:.infinity,minHeight:46)
                        }.buttonStyle(.borderedProminent).tint(cyan).foregroundStyle(Color.black)
                            .disabled(!correctSignal || !tv.connected || tv.settingsBusy || tv.presetBusy)
                        Text(tv.connected ? tv.status : "Connect your TV before applying.").font(.caption).foregroundStyle(.secondary)
                    }.padding(20).prismGlass()
                    Text("The mode is requested first, followed by its values after a short pause. If the request is interrupted, the TV may have changed partially. Verify the result on the TV; SET is not calibration or hardware confirmation.").font(.caption).foregroundStyle(.secondary)
                    VStack(alignment:.leading,spacing:10) {
                        Text("Preset basis").font(.caption.weight(.semibold))
                        Text("B9 review measurements and manufacturer guidance, adapted into practical starting points. Room-brightness values and the Kamil preset are preference choices. No per-panel white-balance or LUT calibration values are copied.").font(.caption).foregroundStyle(.secondary)
                        Link("LG B9 measured settings · RTINGS",destination:URL(string:"https://www.rtings.com/tv/reviews/lg/b9-oled/settings")!).font(.caption)
                        Link("PS5 HDR setup · PlayStation",destination:URL(string:"https://www.playstation.com/cs-cz/support/hardware/ps5-enable-adjust-hdr/")!).font(.caption)
                    }
                }.padding(22)
            }.background(LinearGradient(colors:[Color(red:0.06,green:0.08,blue:0.13),Color(red:0.025,green:0.03,blue:0.045)],startPoint:.top,endPoint:.bottom).ignoresSafeArea())
                .navigationTitle("Preset preview").navigationBarTitleDisplayMode(.inline)
                .toolbar{ToolbarItem(placement:.confirmationAction){Button("Done"){dismiss()}}}
        }.tint(cyan)
    }
    private func displayValue(_ key:String,_ value:String)->String {
        if key=="gamma" {return ["low":"1.9","medium":"2.2","high1":"2.4","high2":"BT.1886"][value] ?? value}
        return ["warm1":"Warm 1","warm2":"Warm 2","HGIG":"HGiG","expert1":"Expert Bright","expert2":"Expert Dark","game":"Game","hdrGame":"HDR Game","hdrCinema":"HDR Cinema","dolbyHdrCinema":"DV Cinema","dolbyHdrCinemaBright":"DV Cinema Home"][value] ?? value.capitalized
    }
}
