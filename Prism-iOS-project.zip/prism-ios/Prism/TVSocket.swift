import Foundation
import Security
import CryptoKit

@MainActor protocol TVSocket:AnyObject {
    var onOpen:(()->Void)? {get set}
    var onClose:(()->Void)? {get set}
    func connect()
    func send(_ text:String) async throws
    func receive() async throws -> Data
    func close()
}

private final class SocketLifecycle:NSObject,URLSessionWebSocketDelegate {
    let opened:@MainActor ()->Void
    let closed:@MainActor ()->Void
    let host:String
    let certificatePin:String?
    let untrusted:@MainActor (String)->Void
    init(host:String,certificatePin:String?,untrusted:@escaping @MainActor (String)->Void,opened:@escaping @MainActor ()->Void,closed:@escaping @MainActor ()->Void){self.host=host;self.certificatePin=certificatePin;self.untrusted=untrusted;self.opened=opened;self.closed=closed}
    func urlSession(_ session:URLSession,didReceive challenge:URLAuthenticationChallenge,completionHandler:@escaping (URLSession.AuthChallengeDisposition,URLCredential?)->Void){
        guard challenge.protectionSpace.authenticationMethod==NSURLAuthenticationMethodServerTrust,
              challenge.protectionSpace.host==host,
              let trust=challenge.protectionSpace.serverTrust,
              let chain=SecTrustCopyCertificateChain(trust) as? [SecCertificate],let leaf=chain.first else {
            completionHandler(.performDefaultHandling,nil);return
        }
        let fingerprint=SHA256.hash(data:SecCertificateCopyData(leaf) as Data).map{String(format:"%02x",$0)}.joined()
        if let pin=certificatePin {
            if pin==fingerprint {completionHandler(.useCredential,URLCredential(trust:trust))}
            else {Task{@MainActor in self.untrusted(fingerprint);completionHandler(.cancelAuthenticationChallenge,nil)}}
        } else if SecTrustEvaluateWithError(trust,nil) {
            completionHandler(.useCredential,URLCredential(trust:trust))
        } else {
            // Self-signed TV certificates require a deliberate user decision.
            Task{@MainActor in self.untrusted(fingerprint);completionHandler(.cancelAuthenticationChallenge,nil)}
        }
    }
    func urlSession(_ session:URLSession,webSocketTask:URLSessionWebSocketTask,didOpenWithProtocol negotiatedProtocol:String?){Task{@MainActor in self.opened()}}
    func urlSession(_ session:URLSession,webSocketTask:URLSessionWebSocketTask,didCloseWith closeCode:URLSessionWebSocketTask.CloseCode,reason:Data?){Task{@MainActor in self.closed()}}
}

@MainActor final class NativeTVSocket:TVSocket {
    var onOpen:(()->Void)?
    var onClose:(()->Void)?
    private let url:URL
    private var session:URLSession?
    private var task:URLSessionWebSocketTask?
    private let certificatePin:String?
    private let untrusted:@MainActor (String)->Void
    init(url:URL,certificatePin:String?=nil,untrusted:@escaping @MainActor (String)->Void = {_ in}){self.url=url;self.certificatePin=certificatePin;self.untrusted=untrusted}
    func connect(){
        let delegate=SocketLifecycle(host:url.host ?? "",certificatePin:certificatePin,untrusted:untrusted,opened:{[weak self] in self?.onOpen?()},closed:{[weak self] in self?.onClose?()})
        let configuration=URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest=12
        let session=URLSession(configuration:configuration,delegate:delegate,delegateQueue:nil)
        self.session=session
        let task=session.webSocketTask(with:url);self.task=task;task.resume()
    }
    func send(_ text:String) async throws {
        guard let task=task else{throw URLError(.notConnectedToInternet)}
        try await task.send(.string(text))
    }
    func receive() async throws -> Data {
        guard let task=task else{throw URLError(.notConnectedToInternet)}
        switch try await task.receive(){case .data(let d):return d;case .string(let s):return Data(s.utf8);@unknown default:throw URLError(.cannotParseResponse)}
    }
    func close(){task?.cancel(with:.goingAway,reason:nil);task=nil;session?.invalidateAndCancel();session=nil}
}
