import Foundation

@MainActor protocol TVSocket:AnyObject {
    var onOpen:(()->Void)? {get set}
    var onClose:(()->Void)? {get set}
    func connect()
    func send(_ text:String) async throws
    func receive() async throws -> Data
    func close()
}

private final class SocketLifecycle:NSObject,URLSessionWebSocketDelegate {
    let opened:@MainActor ()->Void
    let closed:@MainActor ()->Void
    init(opened:@escaping @MainActor ()->Void,closed:@escaping @MainActor ()->Void){self.opened=opened;self.closed=closed}
    func urlSession(_ session:URLSession,webSocketTask:URLSessionWebSocketTask,didOpenWithProtocol negotiatedProtocol:String?){Task{@MainActor in self.opened()}}
    func urlSession(_ session:URLSession,webSocketTask:URLSessionWebSocketTask,didCloseWith closeCode:URLSessionWebSocketTask.CloseCode,reason:Data?){Task{@MainActor in self.closed()}}
}

@MainActor final class NativeTVSocket:TVSocket {
    var onOpen:(()->Void)?
    var onClose:(()->Void)?
    private let url:URL
    private var session:URLSession?
    private var task:URLSessionWebSocketTask?
    init(url:URL){self.url=url}
    func connect(){
        let delegate=SocketLifecycle(opened:{[weak self] in self?.onOpen?()},closed:{[weak self] in self?.onClose?()})
        let configuration=URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest=12
        let session=URLSession(configuration:configuration,delegate:delegate,delegateQueue:nil)
        self.session=session
        let task=session.webSocketTask(with:url);self.task=task;task.resume()
    }
    func send(_ text:String) async throws {
        guard let task=task else{throw URLError(.notConnectedToInternet)}
        try await task.send(.string(text))
    }
    func receive() async throws -> Data {
        guard let task=task else{throw URLError(.notConnectedToInternet)}
        switch try await task.receive(){case .data(let d):return d;case .string(let s):return Data(s.utf8);@unknown default:throw URLError(.cannotParseResponse)}
    }
    func close(){task?.cancel(with:.goingAway,reason:nil);task=nil;session?.invalidateAndCancel();session=nil}
}
