import Foundation
import Combine
import Network
import Darwin

struct DiscoveredTV:Identifiable,Sendable {
    var id:String {host}
    let host:String
    let name:String
}

private enum ProbePortResult:Sendable {case open,closed,denied}

private final class TVPortProbe:@unchecked Sendable {
    private let lock=NSLock()
    private var finished=false
    private var continuation:CheckedContinuation<ProbePortResult,Never>?
    private var connection:NWConnection?
    func run(host:String) async -> ProbePortResult {
        await withCheckedContinuation { continuation in
            self.continuation=continuation
            let c=NWConnection(host:NWEndpoint.Host(host),port:3000,using:.tcp)
            self.connection=c
            c.stateUpdateHandler={ [self] state in
                switch state {
                case .ready:finish(.open)
                case .failed:finish(.closed)
                case .waiting:
                    if c.currentPath?.unsatisfiedReason == .localNetworkDenied {finish(.denied)}
                default:break
                }
            }
            c.start(queue:.main)
            DispatchQueue.main.asyncAfter(deadline:.now()+1.6) { [weak self] in self?.finish(.closed) }
        }
    }
    private func finish(_ result:ProbePortResult) {
        lock.lock()
        guard !finished else {lock.unlock();return}
        finished=true
        let callback=continuation;continuation=nil
        let c=connection;connection=nil
        lock.unlock()
        c?.stateUpdateHandler=nil;c?.cancel()
        callback?.resume(returning:result)
    }
}

@MainActor final class TVDiscovery:ObservableObject {
    @Published var found:[DiscoveredTV]=[]
    @Published var searching=false
    @Published var checked=0
    @Published var total=0
    @Published var message="Find a TV on your Wi-Fi"
    @Published var denied=false
    private var task:Task<Void,Never>?
    private var generation=0
    var progress:Double {total>0 ? Double(checked)/Double(total) : 0}
    func stop() {
        generation += 1;task?.cancel();task=nil
        if searching {message="Search stopped"}
        searching=false
    }
    func start() {
        stop();found=[];checked=0;denied=false
        guard let network=Self.wifiAddress() else {message="Connect your iPhone to Wi-Fi, then search again.";return}
        let hosts=TVProtocol.scanHosts(ip:network.ip,mask:network.mask)
        guard !hosts.isEmpty else {message="This Wi-Fi network cannot be searched. Add the TV's IP manually.";return}
        total=hosts.count;searching=true;message="Searching your Wi-Fi…";let token=generation
        task=Task { [weak self] in
            await withTaskGroup(of:(String,ProbePortResult,DiscoveredTV?).self) { group in
                var next=0
                let parallel=min(16,hosts.count)
                for _ in 0..<parallel {
                    let host=hosts[next];next += 1
                    group.addTask {await Self.inspect(host)}
                }
                while let (host,state,tv)=await group.next() {
                    guard let self=self,!Task.isCancelled,self.generation==token else {group.cancelAll();return}
                    self.checked += 1
                    if case .denied=state {self.denied=true;self.message="Allow Local Network access in Settings → Prism TV, then retry.";self.searching=false;group.cancelAll();return}
                    if let tv=tv,!self.found.contains(where:{$0.host==host}) {self.found.append(tv);self.found.sort{$0.host.localizedStandardCompare($1.host) == .orderedAscending}}
                    if next<hosts.count,!Task.isCancelled {
                        let host=hosts[next];next += 1
                        group.addTask {await Self.inspect(host)}
                    }
                }
            }
            guard let self=self,self.generation==token,!Task.isCancelled else{return}
            self.searching=false
            if !self.denied {self.message=self.found.isEmpty ? "No TV found. Keep the TV on, check Wi-Fi, or add its IP manually." : "Select your TV to pair"}
        }
    }
    nonisolated private static func inspect(_ host:String) async -> (String,ProbePortResult,DiscoveredTV?) {
        guard !Task.isCancelled else{return(host,.closed,nil)}
        let result=await TVPortProbe().run(host:host)
        if case .open=result,!Task.isCancelled {return(host,result,await hello(host))}
        return(host,result,nil)
    }
    nonisolated private static func hello(_ host:String) async -> DiscoveredTV? {
        guard TVProtocol.isLocalIP(host),let url=URL(string:"ws://\(host):3000") else{return nil}
        let config=URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest=2
        let session=URLSession(configuration:config),socket=session.webSocketTask(with:url)
        socket.resume()
        defer {socket.cancel(with:.goingAway,reason:nil);session.invalidateAndCancel()}
        return await withTaskGroup(of:DiscoveredTV?.self) { group in
            group.addTask {
                do {
                    let request:[String:Any]=["id":"discover","type":"hello","payload":["sdkVersion":"1.0","appId":"com.kamilwhoo.prismtv","appName":"Prism TV","deviceModel":"iPhone","OSVersion":"iOS"]]
                    let bytes=try JSONSerialization.data(withJSONObject:request)
                    try await socket.send(.string(String(decoding:bytes,as:UTF8.self)))
                    let msg=try await socket.receive()
                    let data:Data
                    switch msg {case .data(let d):data=d;case .string(let s):data=Data(s.utf8);@unknown default:return nil}
                    guard let name=TVProtocol.webOSHelloName(data) else{return nil}
                    return DiscoveredTV(host:host,name:name)
                } catch {return nil}
            }
            group.addTask {try? await Task.sleep(nanoseconds:2_000_000_000);socket.cancel(with:.goingAway,reason:nil);return nil}
            let result=await group.next() ?? nil
            group.cancelAll()
            return result
        }
    }
    nonisolated private static func wifiAddress()->(ip:String,mask:String)? {
        var first:UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&first)==0,let start=first else{return nil}
        defer {freeifaddrs(first)}
        var pointer:UnsafeMutablePointer<ifaddrs>?=start
        var fallback:(String,String)?
        while let current=pointer {
            defer {pointer=current.pointee.ifa_next}
            let item=current.pointee
            guard let address=item.ifa_addr,let mask=item.ifa_netmask,address.pointee.sa_family==UInt8(AF_INET),(item.ifa_flags & UInt32(IFF_UP)) != 0,(item.ifa_flags & UInt32(IFF_LOOPBACK)) == 0 else{continue}
            let name=String(cString:item.ifa_name)
            guard name.hasPrefix("en") else{continue}
            let ip=address.withMemoryRebound(to:sockaddr_in.self,capacity:1){TVProtocol.ipString(networkOrder:$0.pointee.sin_addr.s_addr)}
            let netmask=mask.withMemoryRebound(to:sockaddr_in.self,capacity:1){TVProtocol.ipString(networkOrder:$0.pointee.sin_addr.s_addr)}
            guard TVProtocol.isLocalIP(ip) else{continue}
            if name=="en0" {return(ip,netmask)}
            fallback=(ip,netmask)
        }
        return fallback
    }
}
