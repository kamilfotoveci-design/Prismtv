import Foundation

enum B9Signal:String,CaseIterable,Identifiable {
    case sdr="SDR",hdr10="HDR10",dolbyVision="Dolby Vision"
    var id:String {rawValue}
}
struct B9Preset:Identifiable {
    let id:String
    let name:String
    let subtitle:String
    let signal:B9Signal
    let mode:String
    let symbol:String
    let settings:[String:String]
    let notes:String
    func values(whiteBalance:String?=nil)->[String:String] {
        var values=settings
        values["pictureMode"]=mode
        if let value=whiteBalance,["warm1","warm2"].contains(value) {values["whiteBalanceColorTemperature"]=value}
        return values
    }
    private static let clean:[String:String]=[
        "dynamicContrast":"off","superResolution":"off","noiseReduction":"off","mpegNoiseReduction":"off","smoothGradation":"off","truMotionMode":"off","motionPro":"off","motionEyeCare":"off"
    ]
    private static func sdr(_ overrides:[String:String])->[String:String] {
        var result=clean
        let base=["backlight":"50","contrast":"85","brightness":"50","color":"50","tint":"0","sharpness":"10","colorGamut":"auto","gamma":"medium","whiteBalanceColorTemperature":"warm2","peakBrightness":"off"]
        result.merge(base){_,new in new};result.merge(overrides){_,new in new};return result
    }
    private static func hdr(_ overrides:[String:String])->[String:String] {
        var result=clean
        let base=["backlight":"100","contrast":"100","brightness":"50","color":"50","tint":"0","sharpness":"10","colorGamut":"auto","whiteBalanceColorTemperature":"warm2","peakBrightness":"high"]
        result.merge(base){_,new in new};result.merge(overrides){_,new in new};return result
    }
    static let all:[B9Preset]=[
        B9Preset(id:"ps5-sdr",name:"PS5 · SDR",subtitle:"Nízke oneskorenie, čistý obraz",signal:.sdr,mode:"game",symbol:"gamecontroller",settings:sdr(["backlight":"60","realCinema":"off"]),notes:"Najprv spusti SDR hru. Na PS5 nastav HDR iba pri podporovanom obsahu. OLED 60 je východiskový jas pre miestnosť. Špičkový jas sa požaduje vypnutý, ale firmvér môže zmenu blokovať. Rozsah RGB na konzole musí zodpovedať TV. Typ vstupu ani rozsah HDMI sa nemení."),
        B9Preset(id:"ps5-personal",name:"PS5 · Kamil",subtitle:"Tvoj ostrejší SDR obraz",signal:.sdr,mode:"game",symbol:"person.crop.circle",settings:sdr(["backlight":"60","sharpness":"25","superResolution":"low","whiteBalanceColorTemperature":"warm1","realCinema":"off"]),notes:"Tvoja preferencia: Warm 1, ostrosť 25 a Super Resolution Low. Nejde o neutrálnu kalibráciu. Spusti SDR hru a prispôsob jas OLED miestnosti. Rozsah a typ HDMI sa nemení."),
        B9Preset(id:"sdr-night",name:"Filmy · SDR večer",subtitle:"Expert Dark, gamma 2.4",signal:.sdr,mode:"expert2",symbol:"moon.stars",settings:sdr(["backlight":"35","gamma":"high1","realCinema":"on"]),notes:"Pre SDR filmy v tmavej miestnosti. OLED 35 je východisko, nie nameraný cieľ jasu. Gamma 2.4 môže v svetlejšej miestnosti skryť detaily; vtedy porovnaj dennú gamma 2.2. Real Cinema je zapnuté, interpolácia vypnutá. Nepoužívaj pre HDR ani Dolby Vision."),
        B9Preset(id:"sdr-day",name:"Filmy · SDR cez deň",subtitle:"Expert Bright, gamma 2.2",signal:.sdr,mode:"expert1",symbol:"sun.max",settings:sdr(["backlight":"70","gamma":"medium","realCinema":"on"]),notes:"Pre SDR obsah pri vyššom okolitom svetle. OLED 70 prispôsob miestnosti. Gamma 2.2, neutrálne spracovanie a Real Cinema zapnuté. Tieto SDR hodnoty nepatria do HDR ani Dolby Vision."),
        B9Preset(id:"ps5-hdr",name:"PS5 · HDR HGiG",subtitle:"HDR Game a kalibrácia konzoly",signal:.hdr10,mode:"hdrGame",symbol:"gamecontroller.fill",settings:hdr(["hdrDynamicToneMapping":"HGIG","realCinema":"off"]),notes:"Najprv spusti HDR hru. HGiG závisí od firmvéru B9 a režimu Hra; skontroluj TV menu. Potom na PS5 otvor Nastavenia → Obrazovka a video → Výstup videa → Upraviť HDR. Postupuj podľa obrazcov, bez univerzálneho počtu kliknutí. Predvoľba nemení PS5, VRR ani typ HDMI."),
        B9Preset(id:"hdr-film",name:"Filmy · HDR10",subtitle:"Kino, dynamické mapovanie vypnuté",signal:.hdr10,mode:"hdrCinema",symbol:"film",settings:hdr(["hdrDynamicToneMapping":"off","realCinema":"on"]),notes:"Najprv spusti HDR10 obsah. Predvoľba požaduje Kino s dynamickým mapovaním vypnutým; bežné statické mapovanie TV zostáva. Jas OLED a špičkový jas sú vysoké pre HDR. Dynamické mapovanie môžeš porovnať ručne. HGiG patrí hernej predvoľbe."),
        B9Preset(id:"dv-night",name:"Filmy · Dolby Vision večer",subtitle:"DV Cinema, zachovaný jas režimu",signal:.dolbyVision,mode:"dolbyHdrCinema",symbol:"sparkles.tv",settings:["realCinema":"on","truMotionMode":"off","motionPro":"off"],notes:"Najprv spusti skutočný Dolby Vision obsah z podporovanej aplikácie, Apple TV alebo CoreELEC. Vyberie DV Cinema a zachová existujúci jas OLED, kontrast, farby a mapovanie daného režimu. Neobnovuje továrenské hodnoty a neposiela SDR gamma ani HDR10 DTM."),
        B9Preset(id:"dv-day",name:"Filmy · Dolby Vision deň",subtitle:"DV Cinema Home, zachovaný jas",signal:.dolbyVision,mode:"dolbyHdrCinemaBright",symbol:"sun.horizon",settings:["realCinema":"on","truMotionMode":"off","motionPro":"off"],notes:"Najprv spusti skutočný Dolby Vision obsah. Vyberie DV Cinema Home a zachová existujúci jas, kontrast, farby a mapovanie režimu. Neobnovuje továrenské nastavenia. Pri príliš svetlej čiernej porovnaj DV Cinema. Neposiela SDR gamma ani HDR10 DTM.")
    ]
}
