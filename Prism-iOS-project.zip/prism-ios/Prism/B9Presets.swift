import Foundation

enum B9Signal:String,CaseIterable,Identifiable {
    case sdr="SDR",hdr10="HDR10",dolbyVision="Dolby Vision"
    var id:String {rawValue}
}
struct B9Preset:Identifiable {
    let id:String
    let name:String
    let subtitle:String
    let signal:B9Signal
    let mode:String
    let symbol:String
    let settings:[String:String]
    let notes:String
    func values(whiteBalance:String?=nil)->[String:String] {
        var values=settings
        values["pictureMode"]=mode
        if let value=whiteBalance,["warm1","warm2"].contains(value) {values["whiteBalanceColorTemperature"]=value}
        return values
    }
    private static let clean:[String:String]=[
        "dynamicContrast":"off","superResolution":"off","noiseReduction":"off","mpegNoiseReduction":"off","smoothGradation":"off","truMotionMode":"off","motionPro":"off","motionEyeCare":"off"
    ]
    private static func sdr(_ overrides:[String:String])->[String:String] {
        var result=clean
        let base=["backlight":"50","contrast":"85","brightness":"50","color":"50","tint":"0","sharpness":"10","colorGamut":"auto","gamma":"medium","whiteBalanceColorTemperature":"warm2","peakBrightness":"off"]
        result.merge(base){_,new in new};result.merge(overrides){_,new in new};return result
    }
    private static func hdr(_ overrides:[String:String])->[String:String] {
        var result=clean
        let base=["backlight":"100","contrast":"100","brightness":"50","color":"50","tint":"0","sharpness":"10","colorGamut":"auto","whiteBalanceColorTemperature":"warm2","peakBrightness":"high"]
        result.merge(base){_,new in new};result.merge(overrides){_,new in new};return result
    }
    static let all:[B9Preset]=[
        B9Preset(id:"ps5-sdr",name:"PS5 · SDR",subtitle:"Low latency, clean image",signal:.sdr,mode:"game",symbol:"gamecontroller",settings:sdr(["backlight":"60","realCinema":"off"]),notes:"Start an SDR game first. On PS5, use HDR On When Supported. OLED 60 is a room-brightness starting point. Peak Brightness is requested Off, but firmware may restrict changes. Match the console RGB range to the TV. This preset leaves HDMI range and input type unchanged."),
        B9Preset(id:"ps5-personal",name:"PS5 · Kamil",subtitle:"Your sharper SDR preference",signal:.sdr,mode:"game",symbol:"person.crop.circle",settings:sdr(["backlight":"60","sharpness":"25","superResolution":"low","whiteBalanceColorTemperature":"warm1","realCinema":"off"]),notes:"Your preferred Warm 1, Sharpness 25 and Super Resolution Low. This is a preference profile, not a neutral calibration. Start an SDR game and adjust OLED brightness for your room. HDMI range and input type stay unchanged."),
        B9Preset(id:"sdr-night",name:"Films · SDR night",subtitle:"Expert Dark, gamma 2.4",signal:.sdr,mode:"expert2",symbol:"moon.stars",settings:sdr(["backlight":"35","gamma":"high1","realCinema":"on"]),notes:"For SDR films in a dark room. OLED 35 is a starting point, not a measured luminance target. Compare gamma 2.2 if 2.4 hides details in your room. Real Cinema is On and interpolation is Off. Do not use for HDR or Dolby Vision."),
        B9Preset(id:"sdr-day",name:"Films · SDR day",subtitle:"Expert Bright, gamma 2.2",signal:.sdr,mode:"expert1",symbol:"sun.max",settings:sdr(["backlight":"70","gamma":"medium","realCinema":"on"]),notes:"For SDR content with more ambient light. Adjust the OLED 70 starting point to your room. Uses gamma 2.2, neutral processing and Real Cinema On. These SDR values are not intended for HDR or Dolby Vision."),
        B9Preset(id:"ps5-hdr",name:"PS5 · HDR HGiG",subtitle:"HDR Game, console calibration",signal:.hdr10,mode:"hdrGame",symbol:"gamecontroller.fill",settings:hdr(["hdrDynamicToneMapping":"HGIG","realCinema":"off"]),notes:"Start an HDR game first. HGiG depends on B9 firmware and Game mode; check the TV menu. Then use PS5 Settings → Screen and Video → Video Output → Adjust HDR. Follow the patterns rather than a universal click count. This preset does not change the PS5, VRR or HDMI input type."),
        B9Preset(id:"hdr-film",name:"Films · HDR10",subtitle:"Cinema, dynamic tone mapping Off",signal:.hdr10,mode:"hdrCinema",symbol:"film",settings:hdr(["hdrDynamicToneMapping":"off","realCinema":"on"]),notes:"Start HDR10 content first. Requests Cinema with dynamic tone mapping Off; the normal static TV mapping remains. OLED and peak brightness are high for HDR. Compare dynamic tone mapping manually if you prefer it. HGiG is reserved for the gaming preset."),
        B9Preset(id:"dv-night",name:"Films · Dolby Vision night",subtitle:"DV Cinema, keep mode brightness",signal:.dolbyVision,mode:"dolbyHdrCinema",symbol:"sparkles.tv",settings:["realCinema":"on","truMotionMode":"off","motionPro":"off"],notes:"Start actual Dolby Vision content from a supported TV app, Apple TV or CoreELEC source. Selects DV Cinema while preserving existing OLED brightness, contrast, color and tone mapping. It does not reset factory settings or apply SDR gamma or HDR10 dynamic tone mapping."),
        B9Preset(id:"dv-day",name:"Films · Dolby Vision day",subtitle:"DV Cinema Home, keep brightness",signal:.dolbyVision,mode:"dolbyHdrCinemaBright",symbol:"sun.horizon",settings:["realCinema":"on","truMotionMode":"off","motionPro":"off"],notes:"Start actual Dolby Vision content first. Selects DV Cinema Home while preserving current brightness, contrast, color and tone mapping. It does not restore factory defaults. Compare DV Cinema if blacks look raised. No SDR gamma or HDR10 dynamic tone mapping is applied.")
    ]
}
