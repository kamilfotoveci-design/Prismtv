import Foundation

enum B9Signal:String,CaseIterable,Identifiable {
    case sdr="SDR",hdr10="HDR10",dolbyVision="Dolby Vision"
    var id:String {rawValue}
}
struct B9Preset:Identifiable {
    let id:String
    let name:String
    let subtitle:String
    let signal:B9Signal
    let mode:String
    let symbol:String
    let settings:[String:String]
    let notes:String
    func values(whiteBalance:String?=nil)->[String:String] {
        var values=settings
        values["pictureMode"]=mode
        if let value=whiteBalance,["warm1","warm2"].contains(value) {values["whiteBalanceColorTemperature"]=value}
        return values
    }
    private static let clean:[String:String]=[
        "dynamicContrast":"off","superResolution":"off","noiseReduction":"off","mpegNoiseReduction":"off","smoothGradation":"off","truMotionMode":"off","motionPro":"off","motionEyeCare":"off"
    ]
    private static func sdr(_ overrides:[String:String])->[String:String] {
        var result=clean
        let base=["backlight":"50","contrast":"85","brightness":"50","color":"50","tint":"0","sharpness":"10","colorGamut":"auto","gamma":"medium","whiteBalanceColorTemperature":"warm2","peakBrightness":"off"]
        result.merge(base){_,new in new};result.merge(overrides){_,new in new};return result
    }
    private static func hdr(_ overrides:[String:String])->[String:String] {
        var result=clean
        let base=["backlight":"100","contrast":"100","brightness":"50","color":"50","tint":"0","sharpness":"10","colorGamut":"auto","whiteBalanceColorTemperature":"warm2","peakBrightness":"high"]
        result.merge(base){_,new in new};result.merge(overrides){_,new in new};return result
    }
    static let all:[B9Preset]=[
        B9Preset(id:"ps5-sdr",name:"PS5 · SDR",subtitle:"Low latency, clean image",signal:.sdr,mode:"game",symbol:"gamecontroller",settings:sdr(["backlight":"60","realCinema":"off"]),notes:"Start an SDR game first. On PS5, choose HDR: On When Supported so SDR games stay SDR. OLED 60 is only a room-brightness starting point. Peak Brightness is requested Off; a greyed-out control may still be firmware-restricted. Keep the source RGB range matched to the TV; this preset leaves the HDMI range and input type unchanged."),
        B9Preset(id:"ps5-personal",name:"PS5 · Kamil",subtitle:"Your sharper SDR preference",signal:.sdr,mode:"game",symbol:"person.crop.circle",settings:sdr(["backlight":"60","sharpness":"25","superResolution":"low","whiteBalanceColorTemperature":"warm1","realCinema":"off"]),notes:"A preference preset based on your Warm 1 and sharper-picture choices, not a neutral calibration. Uses Sharpness 25 and Super Resolution Low. Start an SDR game and adjust OLED brightness to your room. HDMI range and input type stay unchanged."),
        B9Preset(id:"sdr-night",name:"Films · SDR night",subtitle:"Expert Dark, gentle room brightness",signal:.sdr,mode:"expert2",symbol:"moon.stars",settings:sdr(["backlight":"35","gamma":"high1","realCinema":"on"]),notes:"For SDR films in a dim room. OLED 35 is a starting point, not a measured luminance target. Gamma 2.4 is a dark-room choice; use the day preset's 2.2 if it hides detail in your viewing conditions. Real Cinema is On and interpolation is Off. Do not use for HDR or Dolby Vision."),
        B9Preset(id:"sdr-day",name:"Films · SDR day",subtitle:"Expert Bright, gamma 2.2",signal:.sdr,mode:"expert1",symbol:"sun.max",settings:sdr(["backlight":"70","gamma":"medium","realCinema":"on"]),notes:"For SDR viewing with more ambient light. OLED 70 is a starting point to adjust to your room. Gamma 2.2, neutral colour processing and Real Cinema On. Do not transfer these SDR values to HDR or Dolby Vision."),
        B9Preset(id:"ps5-hdr",name:"PS5 · HDR HGiG",subtitle:"HDR Game, console-calibrated tone mapping",signal:.hdr10,mode:"hdrGame",symbol:"gamecontroller.fill",settings:hdr(["hdrDynamicToneMapping":"HGIG","realCinema":"off"]),notes:"Start an HDR game before applying. HGiG availability depends on B9 firmware and the active Game mode; check the TV menu after applying. Then run PS5 Settings → Screen and Video → Video Output → Adjust HDR. Follow the console's patterns; do not use a universal click count. This preset does not change the PS5, VRR or HDMI input type."),
        B9Preset(id:"hdr-film",name:"Films · HDR10",subtitle:"Cinema, dynamic tone mapping Off",signal:.hdr10,mode:"hdrCinema",symbol:"film",settings:hdr(["hdrDynamicToneMapping":"off","realCinema":"on"]),notes:"Play HDR10 content first. This is a consistency-focused Cinema starting point with dynamic tone mapping Off; it still uses the TV's normal static HDR roll-off. OLED and Peak Brightness stay high for HDR. If you prefer extra scene-dependent brightening, compare DTM On manually. HGiG is reserved for the gaming preset."),
        B9Preset(id:"dv-night",name:"Films · Dolby Vision night",subtitle:"Cinema, keep mode-specific light levels",signal:.dolbyVision,mode:"dolbyHdrCinema",symbol:"sparkles.tv",settings:["realCinema":"on","truMotionMode":"off","motionPro":"off"],notes:"Play real Dolby Vision content from a compatible TV app, Apple TV or CoreELEC source first. Selects DV Cinema and preserves that mode's existing OLED brightness, contrast, colour and Dolby Vision tone mapping. It does not reset the mode to factory defaults. No SDR gamma or HDR10 DTM value is applied."),
        B9Preset(id:"dv-day",name:"Films · Dolby Vision day",subtitle:"Cinema Home, keep mode-specific light levels",signal:.dolbyVision,mode:"dolbyHdrCinemaBright",symbol:"sun.horizon",settings:["realCinema":"on","truMotionMode":"off","motionPro":"off"],notes:"Play real Dolby Vision content first. Selects DV Cinema Home for a brighter room while preserving that mode's existing brightness, contrast, colour and tone mapping. It does not reset factory values. Compare with DV Cinema if dark scenes look elevated. No SDR gamma or HDR10 DTM value is applied.")
    ]
}
