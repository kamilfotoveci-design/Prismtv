#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 scripts/verify-source.py
python3 -m unittest discover -s tests -p "test_*.py"
xcode_major="$(xcodebuild -version 2>/dev/null | awk '/^Xcode / {split($2,v,"."); print v[1]}' || true)"
if [[ "${xcode_major:-0}" -lt 26 ]]; then
  selected_xcode=""
  for candidate in /Applications/Xcode*.app; do
    [[ -d "$candidate/Contents/Developer" ]] || continue
    candidate_major="$(DEVELOPER_DIR="$candidate/Contents/Developer" xcodebuild -version 2>/dev/null | awk '/^Xcode / {split($2,v,"."); print v[1]}' || true)"
    if [[ "${candidate_major:-0}" -ge 26 ]]; then
      selected_xcode="$candidate/Contents/Developer"
      break
    fi
  done
  if [[ -z "$selected_xcode" ]]; then
    printf 'Xcode 26 or later is required. Select an installed Xcode 26+ and retry.\n' >&2
    exit 1
  fi
  export DEVELOPER_DIR="$selected_xcode"
fi
xcodebuild -version
mkdir -p build
report_build_error() {
  printf '\n--- Build diagnostics ---\n' >&2
  for log_file in build/simulator-build.log build/interaction-build.log build/device-build.log; do
    if [[ -f "$log_file" ]]; then
      grep -E 'error:|fatal error:' "$log_file" | tail -n 25 >&2 || true
    fi
  done
}
trap report_build_error ERR
# Parse every app source before the longer model tests and Xcode build.
xcrun swiftc -frontend -parse -swift-version 5 Prism/*.swift
xcrun swiftc -target "$(uname -m)-apple-macosx14.0" -swift-version 5 Prism/TVProtocol.swift Prism/B9Presets.swift Prism/TVModels.swift tests/ProtocolTests.swift -o build/protocol-tests
build/protocol-tests
xcrun swiftc -target "$(uname -m)-apple-macosx14.0" -swift-version 5 Prism/TVProtocol.swift Prism/B9Presets.swift Prism/TVModels.swift Prism/TVSocket.swift Prism/WebOSTV.swift tests/TVHarness.swift tests/ModelTests.swift -o build/model-tests
build/model-tests
xcrun swiftc -target "$(uname -m)-apple-macosx14.0" -swift-version 5 Prism/TVProtocol.swift Prism/B9Presets.swift Prism/TVModels.swift Prism/TVSocket.swift Prism/WebOSTV.swift tests/TVHarness.swift tests/RegressionTests.swift -o build/regression-tests
build/regression-tests
if [[ "${CI:-}" == "true" ]]; then
  bash scripts/smoke-test.sh
fi
xcodebuild -project Prism.xcodeproj -scheme Prism -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build 2>&1 | tee build/device-build.log
python3 scripts/verify-app.py build/DerivedData/Build/Products/Release-iphoneos/Prism.app
mkdir -p build/package/Payload
rm -rf build/package/Payload/Prism.app
cp -R build/DerivedData/Build/Products/Release-iphoneos/Prism.app build/package/Payload/Prism.app
python3 - <<'PACKAGE_PY'
from pathlib import Path
import zipfile
root=Path('build/package')
output=Path('build/Prism-unsigned.ipa')
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted((root/'Payload').rglob('*')):
        if path.is_file():
            assert not path.is_symlink(), 'Unexpected symlink in app bundle'
            z.write(path,path.relative_to(root).as_posix())
PACKAGE_PY
python3 scripts/verify-archive.py ipa build/Prism-unsigned.ipa
python3 - <<'RELEASE_PY'
from pathlib import Path
import hashlib,os
p=Path('build/Prism-unsigned.ipa')
Path('build/RELEASE.txt').write_text('Prism 2.7.0 · build 14\nCommit: '+os.environ.get('GITHUB_SHA','local')+'\nSHA256: '+hashlib.sha256(p.read_bytes()).hexdigest()+'\nExtract the GitHub artifact ZIP, then sign/install Prism-unsigned.ipa.\nThis IPA is unsigned.\n')
RELEASE_PY
printf '\nCreated: build/Prism-unsigned.ipa (requires signing by a sideload tool)\n'
