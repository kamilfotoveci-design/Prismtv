#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 scripts/verify-source.py
python3 -m unittest discover -s tests -p "test_*.py"
xcode_major="$(xcodebuild -version | awk '/^Xcode / {split($2,v,"."); print v[1]}')"
if [[ "$xcode_major" -lt 26 ]]; then
  selected_xcode=""
  for candidate in /Applications/Xcode_26.3.app /Applications/Xcode_26.2.app /Applications/Xcode_26.1.1.app /Applications/Xcode_26.0.1.app; do
    if [[ -d "$candidate/Contents/Developer" ]]; then
      selected_xcode="$candidate/Contents/Developer"
      break
    fi
  done
  if [[ -z "$selected_xcode" ]]; then
    printf 'Xcode 26 or later is required by this build configuration. Select a supported Xcode and retry.\n' >&2
    exit 1
  fi
  export DEVELOPER_DIR="$selected_xcode"
fi
xcodebuild -version
mkdir -p build
report_build_error() {
  printf '\n--- Build diagnostics ---\n' >&2
  for log_file in build/simulator-build.log build/device-build.log; do
    if [[ -f "$log_file" ]]; then
      grep -E 'error:|fatal error:' "$log_file" | tail -n 25 >&2 || true
    fi
  done
}
trap report_build_error ERR
# Parse every app source before the longer model tests and Xcode build.
xcrun swiftc -frontend -parse -swift-version 5 Prism/*.swift
swiftc -swift-version 5 Prism/TVProtocol.swift Prism/B9Presets.swift Prism/TVModels.swift tests/ProtocolTests.swift -o build/protocol-tests
build/protocol-tests
swiftc -swift-version 5 Prism/TVProtocol.swift Prism/B9Presets.swift Prism/TVModels.swift Prism/TVSocket.swift Prism/WebOSTV.swift tests/ModelTests.swift -o build/model-tests
build/model-tests
if [[ "${CI:-}" == "true" ]]; then
  bash scripts/smoke-test.sh
fi
xcodebuild -project Prism.xcodeproj -scheme Prism -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build 2>&1 | tee build/device-build.log
python3 scripts/verify-app.py build/DerivedData/Build/Products/Release-iphoneos/Prism.app
mkdir -p build/package/Payload
rm -rf build/package/Payload/Prism.app
cp -R build/DerivedData/Build/Products/Release-iphoneos/Prism.app build/package/Payload/Prism.app
python3 - <<'PACKAGE_PY'
from pathlib import Path
import zipfile
root=Path('build/package')
output=Path('build/Prism-unsigned.ipa')
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted((root/'Payload').rglob('*')):
        if path.is_file():
            assert not path.is_symlink(), 'Unexpected symlink in app bundle'
            z.write(path,path.relative_to(root).as_posix())
PACKAGE_PY
python3 scripts/verify-archive.py ipa build/Prism-unsigned.ipa
python3 - <<'RELEASE_PY'
from pathlib import Path
import hashlib,os
p=Path('build/Prism-unsigned.ipa')
Path('build/RELEASE.txt').write_text('Prism 2.5.0 · build 10\nCommit: '+os.environ.get('GITHUB_SHA','local')+'\nSHA256: '+hashlib.sha256(p.read_bytes()).hexdigest()+'\nExtract the GitHub artifact ZIP, then sign/install Prism-unsigned.ipa.\nThis IPA is unsigned.\n')
RELEASE_PY
printf '\nCreated: build/Prism-unsigned.ipa (requires signing by a sideload tool)\n'
