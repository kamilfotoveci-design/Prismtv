#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 scripts/verify-source.py
xcode_major="$(xcodebuild -version | awk '/^Xcode / {split($2,v,"."); print v[1]}')"
if [[ "$xcode_major" -lt 26 ]]; then
  selected_xcode=""
  for candidate in /Applications/Xcode_26.3.app /Applications/Xcode_26.2.app /Applications/Xcode_26.1.1.app /Applications/Xcode_26.0.1.app; do
    if [[ -d "$candidate/Contents/Developer" ]]; then
      selected_xcode="$candidate/Contents/Developer"
      break
    fi
  done
  if [[ -z "$selected_xcode" ]]; then
    printf 'Xcode 26 or later is required by this build configuration. Select a supported Xcode and retry.\n' >&2
    exit 1
  fi
  export DEVELOPER_DIR="$selected_xcode"
fi
xcodebuild -version
mkdir -p build
swiftc -swift-version 5 Prism/TVProtocol.swift Prism/B9Presets.swift tests/ProtocolTests.swift -o build/protocol-tests
build/protocol-tests
swiftc -swift-version 5 Prism/TVProtocol.swift Prism/B9Presets.swift Prism/TVModels.swift Prism/TVSocket.swift Prism/WebOSTV.swift tests/ModelTests.swift -o build/model-tests
build/model-tests
if [[ "${CI:-}" == "true" ]]; then
  bash scripts/smoke-test.sh
fi
xcodebuild -project Prism.xcodeproj -scheme Prism -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
python3 scripts/verify-app.py build/DerivedData/Build/Products/Release-iphoneos/Prism.app
mkdir -p build/package/Payload
rm -rf build/package/Payload/Prism.app
cp -R build/DerivedData/Build/Products/Release-iphoneos/Prism.app build/package/Payload/Prism.app
cd build/package
rm -f ../Prism-unsigned.ipa
zip -qry ../Prism-unsigned.ipa Payload
printf '\nCreated: build/Prism-unsigned.ipa (requires signing by a sideload tool)\n'
