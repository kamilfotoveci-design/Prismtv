import Foundation

@main struct RegressionTests {
    @MainActor static func pause() async {try? await Task.sleep(nanoseconds:80_000_000)}
    @MainActor static func wait(_ predicate:()->Bool) async {
        for _ in 0..<600 {
            if predicate(){return}
            try? await Task.sleep(nanoseconds:20_000_000)
        }
        preconditionFailure("Regression timed out")
    }
    @MainActor static func main() async {
        let suite="PrismRegressions-\(UUID().uuidString)"
        let defaults=UserDefaults(suiteName:suite)!
        defer{defaults.removePersistentDomain(forName:suite)}
        let harness=Harness()
        let tv=WebOSTV(defaults:defaults,persistPairing:false,socketFactory:{harness.make($0)})
        precondition(tv.add(name:"B9",host:"192.168.0.110",mac:""))
        tv.connect();await wait{tv.connected && tv.picture["contrast"] != nil}
        let socket=harness.sockets.first!
        func count(_ uri:String)->Int {socket.sent.filter{$0.contains(uri)}.count}

        // The original app missed 401, "insufficient permissions", and code-only
        // errors. Exercise the real response parser, queue, and alert dispatch.
        FileHandle.standardOutput.write(Data("TEST: Permission fallback\n".utf8))
        harness.settingRejection=["returnValue":false,"errorCode":401]
        tv.userError="Old failure"
        tv.enqueuePicture(key:"backlight",value:"15")
        await wait{!tv.settingsBusy && tv.requestedPicture["backlight"]=="15"}
        precondition(tv.compatibilityKeys.contains("backlight") && tv.failedPicture.isEmpty)
        precondition(tv.userError==nil,"A successful retry must dismiss the previous error")
        precondition(count("createAlert")==1 && count("closeAlert")==1)
        precondition(harness.alertSettings["category"] as? String=="picture")
        precondition((harness.alertSettings["settings"] as? [String:Any])?["backlight"] as? Int==15)
        let directBefore=count("ssap://settings/setSystemSettings")
        tv.enqueuePicture(key:"contrast",value:"82")
        await wait{!tv.settingsBusy && tv.requestedPicture["contrast"]=="82"}
        precondition(count("ssap://settings/setSystemSettings")==directBefore,"Reuse the working compatible route")
        precondition(count("createAlert")==2)

        // Different close-alert ID formats are only retried after an explicit
        // rejection, never after an ambiguous network timeout.
        FileHandle.standardOutput.write(Data("TEST: Alert ID compatibility\n".utf8))
        harness.rejectNormalizedClose=true
        tv.enqueuePicture(key:"color",value:"49")
        await wait{!tv.settingsBusy && tv.requestedPicture["color"]=="49"}
        precondition(count("closeAlert")==4)
        harness.rejectNormalizedClose=false

        // Sound settings share the corrected route, including code-only errors.
        FileHandle.standardOutput.write(Data("TEST: Audio fallback\n".utf8))
        tv.enqueueSound(key:"audioBalance",value:"3")
        await wait{!tv.soundBusy && tv.requestedSound["audioBalance"]=="3"}
        precondition(harness.alertSettings["category"] as? String=="sound")
        precondition(tv.userError==nil)
        tv.saveReadPreferences()
        precondition(defaults.bool(forKey:"prism.useLunaFallback"))

        // A new connection must renegotiate the route for that firmware/session.
        FileHandle.standardOutput.write(Data("TEST: Reconnect route\n".utf8))
        tv.disconnect();harness.settingRejection=nil;harness.applyWrites=true
        tv.connect();await wait{tv.connected && tv.picture["contrast"] != nil}
        let fresh=harness.sockets.last{$0.sent.contains(where:{$0.contains("register")})}!
        let alerts=fresh.sent.filter{$0.contains("createAlert")}.count
        tv.enqueuePicture(key:"contrast",value:"81")
        await wait{!tv.settingsBusy && tv.requestedPicture["contrast"]=="81"}
        precondition(fresh.sent.filter{$0.contains("createAlert")}.count==alerts)
        precondition(!tv.compatibilityKeys.contains("contrast"))

        // Many firmware versions cannot read pictureMode at all. Apply the
        // remaining settings after settlement and retain unverified status.
        FileHandle.standardOutput.write(Data("TEST: Write-only picture modes\n".utf8))
        harness.readMode=false
        let scene=PictureProfile(name:"Write-only mode",device:tv.selected!,settings:["pictureMode":"game","contrast":"80","brightness":"51"])
        tv.applyProfile(scene)
        await wait{!tv.presetBusy}
        precondition(tv.requestedPicture["contrast"]=="80" && tv.requestedPicture["brightness"]=="51")
        precondition(tv.picture["pictureMode"]==nil && tv.userError==nil)

        // One unsupported key must not reject every other setting in a scene.
        FileHandle.standardOutput.write(Data("TEST: Partial scene failures\n".utf8))
        harness.rejectedKeys=["peakBrightness"]
        let partial=PictureProfile(name:"Partial",device:tv.selected!,settings:["contrast":"79","peakBrightness":"off","sharpness":"5"])
        tv.applyProfile(partial);await wait{!tv.presetBusy}
        precondition(tv.requestedPicture["contrast"]=="79" && tv.requestedPicture["sharpness"]=="5")
        precondition(tv.failedPicture["peakBrightness"] != nil && tv.status.contains("1 rejected"))
        precondition(!tv.settingsBusy)
        harness.rejectedKeys=[]

        // Changing sound mode must retain the external route and keep TV EQ
        // disabled; an unread route must not masquerade as TV speakers.
        FileHandle.standardOutput.write(Data("TEST: External audio route\n".utf8))
        tv.readSound(keys:["soundOutput"]);await wait{tv.sound["soundOutput"] != nil}
        tv.enqueueSound(key:"soundOutput",value:"external_arc")
        await wait{!tv.soundBusy && tv.requestedSound["soundOutput"]=="external_arc"}
        tv.enqueueSound(key:"soundMode",value:"movie")
        await wait{!tv.soundBusy && tv.requestedSound["soundMode"]=="movie"}
        precondition(tv.externalAudioOutput && !tv.canUseTVEqualizer)
        tv.enqueueSound(key:"userEqualizerValues",value:"[0,0,0,0,0]")
        precondition(tv.queuedSound["userEqualizerValues"]==nil)

        // Never leave a callback/continuation suspended after disconnect.
        FileHandle.standardOutput.write(Data("TEST: Disconnect completion\n".utf8))
        harness.holdWrites=true
        var finished:Bool?
        tv.writePicture(["brightness":"52"]){finished=$0}
        await wait{!harness.heldWrites.isEmpty}
        tv.disconnect();await pause()
        precondition(finished==false && !tv.settingsBusy && !tv.presetBusy)
        precondition(tv.picture.isEmpty && tv.requestedPicture.isEmpty)
        print("PASS: code-only 401 fallback, cached routes, alert IDs, audio writes, scene settlement, partial scenes, external EQ guard and disconnect completion.")
    }
}
