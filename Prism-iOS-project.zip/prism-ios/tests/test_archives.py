import importlib.util
import plistlib
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path

spec = importlib.util.spec_from_file_location('archive_check', Path(__file__).resolve().parents[1] / 'scripts/verify-archive.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class ArchiveTests(unittest.TestCase):
    def test_rejects_download_error_page(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'Prism.ipa'
            path.write_text('<html>sign in required</html>')
            with self.assertRaises(ValueError):
                module.verify(path, 'ipa')

    def test_ipa_structure_permissions_and_truncation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'Prism.ipa'
            base = 'Payload/Prism.app/'
            info = {'CFBundleExecutable': 'Prism', 'CFBundleIdentifier': 'com.kamilwhoo.prismtv',
                    'CFBundleShortVersionString': '2.6.2', 'CFBundleVersion': '13'}
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr(base + 'Info.plist', plistlib.dumps(info))
                entry = zipfile.ZipInfo(base + 'Prism')
                entry.create_system = 3
                entry.external_attr = (stat.S_IFREG | 0o755) << 16
                z.writestr(entry, b'\xcf\xfa\xed\xfe' + bytes(64))
                z.writestr(base + 'Assets.car', b'fixture')
            self.assertEqual(len(module.verify(path, 'ipa')), 64)
            path.write_bytes(path.read_bytes()[:-30])
            with self.assertRaises(ValueError):
                module.verify(path, 'ipa')

    def test_rejects_screenshot_artifact_as_ipa(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'Prism-IPA.zip'
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr('simulator-launch.png', b'fixture')
            with self.assertRaises(ValueError):
                module.verify(path, 'ipa')

    def test_rejects_damaged_entry_and_traversal(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'bad.zip'
            with zipfile.ZipFile(path, 'w', zipfile.ZIP_STORED) as z:
                z.writestr('sentinel', b'uniquepayload')
            content = path.read_bytes().replace(b'uniquepayload', b'brokenpayload')
            path.write_bytes(content)
            with self.assertRaises((ValueError, zipfile.BadZipFile)):
                module.verify(path, 'ipa')
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr('../escape', b'fixture')
            with self.assertRaises(ValueError):
                module.verify(path, 'ipa')


if __name__ == '__main__':
    unittest.main()
