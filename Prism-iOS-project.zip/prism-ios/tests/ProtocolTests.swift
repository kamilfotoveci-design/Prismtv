import Foundation

@main struct ProtocolTests {
    static func main() throws {
        for ip in ["192.168.0.110","10.0.0.2","172.16.0.1","172.31.255.254","169.254.1.2"] {precondition(TVProtocol.isLocalIP(ip),ip)}
        for ip in ["8.8.8.8","127.0.0.1","192.168.0.999","172.32.0.1","172.15.0.1","192.168.1","192.168.0.01","192.168..1","http://192.168.0.1","192.168.0.1:3000","+192.168.0.1"] {precondition(!TVProtocol.isLocalIP(ip),ip)}
        precondition(TVProtocol.ipString(networkOrder:UInt32(0xc0a8006e).bigEndian)=="192.168.0.110")
        precondition(TVProtocol.ipString(networkOrder:UInt32(0xffffff00).bigEndian)=="255.255.255.0")
        let hosts=TVProtocol.scanHosts(ip:"192.168.0.10",mask:"255.255.255.0")
        precondition(hosts.count==253 && hosts.contains("192.168.0.110") && !hosts.contains("192.168.0.10") && !hosts.contains("192.168.0.0") && !hosts.contains("192.168.0.255"))
        precondition(TVProtocol.scanHosts(ip:"10.1.2.3",mask:"255.255.0.0").count==253)
        precondition(TVProtocol.scanHosts(ip:"192.168.0.5",mask:"255.255.255.252")==["192.168.0.6"])
        precondition(TVProtocol.scanHosts(ip:"192.168.0.5",mask:"255.0.255.0").isEmpty)
        precondition(TVProtocol.scanHosts(ip:"192.168.0.5",mask:"255.255.255.255").isEmpty)
        let hello=Data(#"{"type":"hello","payload":{"deviceType":"tv","deviceOS":"webOS"}}"#.utf8)
        precondition(TVProtocol.webOSHelloName(hello)=="LG webOS TV")
        precondition(TVProtocol.webOSHelloName(Data(#"{"type":"hello","payload":{"deviceType":"speaker","deviceOS":"other"}}"#.utf8))==nil)
        let packet=TVProtocol.wakePacket("01:23:45:67:89:ab")!
        precondition(packet.count==102)
        precondition(Array(packet.prefix(6))==Array(repeating:UInt8(255),count:6))
        for i in 0..<16 {precondition(Array(packet[(6+i*6)..<(12+i*6)])==[1,35,69,103,137,171])}
        precondition(TVProtocol.wakePacket("invalid")==nil)
        precondition(TVProtocol.wakePacket("01:23:45:67:89:zz")==nil)
        precondition(TVProtocol.button("ENTER")=="type:button\nname:ENTER\n\n")
        precondition(TVProtocol.closeAlertID("com.webos.service.apiadapter.pub-123")=="com.webos.service.apiadapter-123")
        precondition(TVProtocol.closeAlertID("com.webos.service.apiadapter-123")=="com.webos.service.apiadapter-123")
        let request=TVProtocol.request(id:"r1",uri:"audio/setMute",payload:["mute":true])
        let data=try JSONSerialization.data(withJSONObject:request)
        let decoded=try JSONSerialization.jsonObject(with:data) as! [String:Any]
        precondition(decoded["uri"] as? String=="ssap://audio/setMute")
        precondition((decoded["payload"] as? [String:Any])?["mute"] as? Bool==true)
        precondition(B9Preset.all.count==8)
        precondition(Set(B9Preset.all.map{$0.id}).count==B9Preset.all.count)
        for p in B9Preset.all {
            let values=p.values()
            precondition(values["pictureMode"]==p.mode)
            precondition(p.values(whiteBalance:"warm1")["whiteBalanceColorTemperature"]=="warm1")
            if p.signal == .dolbyVision {
                for key in ["backlight","contrast","brightness","color","gamma","hdrDynamicToneMapping"] {precondition(values[key]==nil)}
            }
            if p.signal == .sdr {precondition(values["peakBrightness"]=="off" && values["contrast"]=="85" && values["hdrDynamicToneMapping"]==nil)}
            if p.signal == .hdr10 {precondition(values["gamma"]==nil && values["backlight"]=="100" && values["peakBrightness"]=="high")}
        }
        let personal=B9Preset.all.first{$0.id=="ps5-personal"}!
        precondition(personal.settings["sharpness"]=="25" && personal.settings["whiteBalanceColorTemperature"]=="warm1")
        precondition(B9Preset.all.first{$0.id=="ps5-hdr"}!.settings["hdrDynamicToneMapping"]=="HGIG")
        precondition(TVProtocol.pictureMatches("50.0","50"))
        precondition(TVProtocol.pictureMatches("hgig","HGIG"))
        precondition(!TVProtocol.pictureMatches("64","99"))
        precondition(TVProtocol.messageID(12)=="12")
        precondition(TVProtocol.messageID("r12")=="r12")
        precondition(TVProtocol.pictureValues(["settings":["brightness":NSNumber(value:50),"color":"60","gamma":NSNull(),"contrast":true]],allowed:["brightness","gamma","contrast"]) == ["brightness":"50"])
        precondition(TVProtocol.pictureValues(["returnValue":false,"settings":["brightness":50]],allowed:["brightness"]).isEmpty)
        precondition(TVProtocol.pictureValues(["brightness":50],allowed:["brightness"]).isEmpty)
        print("PASS: LAN validation, WOL contents, remote framing and SSAP JSON.")
    }
}
