import Foundation

// The real model runs against a scripted socket. No TV or paired credentials required.
@MainActor final class TestSocket:TVSocket {
    var onOpen:(()->Void)?
    var onClose:(()->Void)?
    var sent:[String]=[]
    var failURI:String?
    var responder:(([String:Any])->[String:Any]?)?
    private var waiting:CheckedContinuation<Data,Error>?
    private var inbox:[Data]=[]
    private var closed=false
    func connect(){onOpen?()}
    func send(_ text:String) async throws {
        guard !closed else{throw URLError(.cancelled)}
        sent.append(text)
        guard let data=text.data(using:.utf8),let object=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{return}
        if let failing=failURI,object["uri"] as? String==failing {throw URLError(.networkConnectionLost)}
        if object["type"] as? String=="register" {emit(["type":"registered","payload":[:]]);return}
        if let payload=responder?(object){emit(["type":"response","id":object["id"] ?? "","payload":payload])}
    }
    func emit(_ object:[String:Any]){let data=try! JSONSerialization.data(withJSONObject:object);if let continuation=waiting {waiting=nil;continuation.resume(returning:data)}else{inbox.append(data)}}
    func receive() async throws -> Data {
        if !inbox.isEmpty{return inbox.removeFirst()}
        if closed{throw URLError(.cancelled)}
        return try await withCheckedThrowingContinuation{waiting=$0}
    }
    func close(){closed=true;waiting?.resume(throwing:URLError(.cancelled));waiting=nil;onClose?()}
}
@MainActor final class Harness {
    var sockets:[TestSocket]=[]
    var backend:[String:Any]=["backlight":64,"contrast":"85","brightness":50,"color":50]
    var holdReads=false
    var foregroundID=""
    var volumePayload:[String:Any]=["volumeStatus":["volume":27,"mute":false]]
    var held:[(TestSocket,String,String)]=[]
    func foreground(_ app:String){
        sockets.first!.emit(["id":foregroundID,"type":"response","payload":["appId":app]])
    }
    func make(_ url:URL)->TVSocket {
        let socket=TestSocket();sockets.append(socket)
        socket.responder={[weak self,weak socket] object in
            guard let self=self,let socket=socket else{return nil}
            let uri=object["uri"] as? String ?? ""
            if uri.hasSuffix("getPointerInputSocket"){return ["socketPath":"ws://192.168.0.110:3000/pointer"]}
            if uri.hasSuffix("getSystemSettings") {
                let payload=object["payload"] as? [String:Any] ?? [:]
                let key=(payload["keys"] as? [String])?.first ?? ""
                if self.holdReads {self.held.append((socket,object["id"] as? String ?? "",key));return nil}
                return ["returnValue":true,"settings":self.backend[key].map{[key:$0]} ?? [:]]
            }
            if uri.hasSuffix("getForegroundAppInfo"){self.foregroundID=object["id"] as? String ?? "";return [:]}
            if uri.hasSuffix("getVolume"){return self.volumePayload}
            // Deliberately acknowledge writes without mutating the TV backend.
            return ["returnValue":true]
        }
        return socket
    }
}
@main struct ModelTests {
    @MainActor static func settle() async {for _ in 0..<120 {await Task.yield()};try? await Task.sleep(nanoseconds:30_000_000)}
    @MainActor static func waitUntil(_ predicate:@MainActor ()->Bool) async {
        for _ in 0..<200 {
            if predicate(){return}
            try? await Task.sleep(nanoseconds:20_000_000)
        }
        preconditionFailure("Timed out waiting for model work")
    }
    @MainActor static func main() async {
        var keyboard=KeyboardDraft()
        keyboard.text="Ahoj TV"
        let first=keyboard.begin()!
        keyboard.finish(id:first.id,success:false)
        precondition(keyboard.text=="Ahoj TV" && keyboard.error != nil && !keyboard.sending,"Failed text must remain available for retry")
        let retry=keyboard.begin()!
        keyboard.disconnected()
        precondition(keyboard.text=="Ahoj TV" && !keyboard.sending)
        let newer=keyboard.begin()!
        keyboard.finish(id:retry.id,success:true)
        precondition(keyboard.text=="Ahoj TV" && keyboard.sending,"A stale success must not clear a new draft")
        keyboard.finish(id:newer.id,success:true)
        precondition(keyboard.text.isEmpty && !keyboard.sending)
        let suite="PrismTests-\(UUID().uuidString)"
        let defaults=UserDefaults(suiteName:suite)!
        defer {defaults.removePersistentDomain(forName:suite)}
        let harness=Harness()
        let tv=WebOSTV(defaults:defaults,persistPairing:false,socketFactory:{harness.make($0)})
        precondition(!tv.autoRefreshPicture && !tv.verifyPictureWrites,"Picture polling and write read-back must be opt-in")
        precondition(PictureSetting.all.first{$0.key=="blackLevel"}!.options==["auto","high","low"])
        precondition(PictureSetting.label("high",key:"blackLevel")=="Full")
        precondition(PictureSetting.label("low",key:"blackLevel")=="Limited")
        precondition(TVProtocol.blackLevelValue("auto")=="auto" && TVProtocol.blackLevelValue("medium")=="medium")
        precondition(tv.add(name:"Test TV",host:"192.168.0.110",mac:""))
        let active=tv.selected!
        precondition(tv.add(name:"Spare",host:"192.168.0.111",mac:""))
        let spare=tv.selected!
        tv.select(active);tv.connect();await settle()
        precondition(tv.connected && tv.pointerReady,"Navigation must use the open event, no ping dependency")
        precondition(tv.picture["backlight"]=="64","Only the TV's numeric response is shown")
        precondition(tv.volume==27 && tv.muted==false,"Nested volume responses are parsed")
        harness.foreground("com.webos.app.hdmi1");await settle()
        precondition(tv.picture["backlight"]=="64" && tv.picture["contrast"]=="85","A late first foreground reply must not erase initial reads")
        harness.volumePayload=["volumeStatus":["volume":-1,"muteStatus":true]]
        tv.readVolume();await settle()
        precondition(tv.volume==nil && tv.muted==true,"External sound output -1 is not a real volume")
        harness.volumePayload=["volumeStatus":["volume":27,"mute":false]]
        tv.readVolume();await settle()
        harness.sockets.first!.failURI="ssap://audio/volumeUp"
        var failureReported=false
        tv.request("audio/volumeUp"){result in if case .failure=result {failureReported=true}}
        await settle()
        precondition(failureReported,"Transport send errors must finish pending requests immediately")
        tv.command("audio/volumeUp");await settle()
        precondition(tv.userError != nil,"Command errors must be visible independently of ordinary status text")
        harness.sockets.first!.failURI=nil
        tv.command("audio/volumeDown");await settle()
        precondition(tv.userError==nil,"A successful retry clears the shared error notice")
        tv.saveProfile("Read values")
        precondition(tv.profiles.last?.confirmed==true && tv.profiles.last?.settings["backlight"]=="64")
        let legacy:[String:Any]=["id":UUID().uuidString,"name":"Legacy","device":active.uuidString,"settings":["backlight":"99"]]
        let legacyData=try! JSONSerialization.data(withJSONObject:legacy)
        let legacyScene=try! JSONDecoder().decode(PictureProfile.self,from:legacyData)
        precondition(legacyScene.confirmed==nil,"Legacy scenes must not be labelled confirmed")
        tv.remove(spare)
        precondition(tv.connected && tv.selected==active,"Deleting another TV must preserve the connection")
        for key in ["UP","DOWN","LEFT","RIGHT","ENTER"] {tv.button(key)}
        await settle()
        let pointer=harness.sockets.last!
        precondition(pointer.sent == ["UP","DOWN","LEFT","RIGHT","ENTER"].map{TVProtocol.button($0)},"Rapid buttons must retain order")
        @MainActor func readCount()->Int {harness.sockets.first!.sent.filter{$0.contains("getSystemSettings")}.count}
        let readsBeforeWrite=readCount()
        tv.writePicture(["backlight":"99"]);await settle()
        precondition(tv.requestedPicture["backlight"]=="99" && tv.picture["backlight"]==nil,"An ACK must not become an actual value")
        precondition(readCount()==readsBeforeWrite,"No automatic read after a write by default")
        precondition(tv.picture["contrast"]=="85","An unrelated confirmed value must remain visible")
        tv.readPicture(keys:["backlight"]);await settle()
        precondition(tv.picture["backlight"]=="64","Only a manual TV read restores the actual value")
        tv.verifyPictureWrites=true
        tv.writePicture(["backlight":"98"]);await settle()
        precondition(tv.picture["backlight"]=="64" && tv.requestedPicture["backlight"]=="98","Opt-in read-back must still report the real value")
        tv.verifyPictureWrites=false
        let queueReadCount=readCount()
        tv.enqueuePicture(key:"contrast",value:"86")
        tv.enqueuePicture(key:"contrast",value:"87")
        tv.enqueuePicture(key:"color",value:"51")
        precondition(tv.queuedPicture["contrast"]=="87","Rapid changes must coalesce to the latest value")
        await waitUntil{tv.queuedPicture.isEmpty && tv.sendingPicture.isEmpty && !tv.settingsBusy}
        precondition(tv.requestedPicture["contrast"]=="87" && tv.requestedPicture["color"]=="51","Different controls must not discard each other's requests")
        precondition(readCount()==queueReadCount,"Queued controls must not trigger unwanted reads")
        let selection=tv.makeSceneDraft(includeSelection:true)!
        precondition(selection.settings["contrast"]=="87" && selection.settings["color"]=="51","A scene must include the user's latest choices")
        precondition(!selection.confirmedKeys.contains("contrast") && selection.confirmedKeys.contains("brightness"),"Unverified choices must stay distinct from received values")
        precondition(tv.saveProfile("Môj výber",draft:selection))
        precondition(tv.profiles.last?.confirmed==false && tv.profiles.last?.settings==selection.settings,"Save must preserve the exact preview")
        let readOnly=tv.makeSceneDraft(includeSelection:false)!
        precondition(readOnly.settings["contrast"]==nil && readOnly.confirmedKeys.count==readOnly.settings.count)
        harness.sockets.first!.failURI="ssap://com.webos.service.ime/insertText"
        var textSucceeded:Bool?
        tv.sendText("Test"){textSucceeded=$0};await settle()
        precondition(textSucceeded==false && tv.userError != nil)
        harness.sockets.first!.failURI=nil
        tv.sendText("Test"){textSucceeded=$0};await settle()
        precondition(textSucceeded==true && tv.userError==nil)
        tv.enqueuePicture(key:"blackLevel",value:"full")
        await waitUntil{tv.queuedPicture.isEmpty && tv.sendingPicture.isEmpty && !tv.settingsBusy}
        precondition(tv.requestedPicture["blackLevel"]=="high")
        tv.enqueuePicture(key:"blackLevel",value:"medium")
        precondition(tv.queuedPicture["blackLevel"]==nil,"Medium is not offered as Auto")
        tv.enqueuePicture(key:"brightness",value:"200")
        precondition(tv.queuedPicture["brightness"]==nil,"Out-of-range slider requests must be rejected")
        tv.enqueuePicture(key:"pictureMode",value:"game")
        precondition(tv.pictureModePending,"Mode selection must lock immediately, before network ACK")
        tv.enqueuePicture(key:"contrast",value:"88")
        precondition(tv.queuedPicture["contrast"]==nil,"Controls must be blocked explicitly during a mode change")
        await waitUntil{!tv.pictureModePending && !tv.settingsBusy}
        precondition(tv.requestedPicture["pictureMode"]=="game")
        let profilesBefore=tv.profiles.count
        precondition(!tv.saveProfile("Stale preview",draft:selection) && tv.profiles.count==profilesBefore,"An old-input preview must not be saved")
        tv.enqueuePicture(key:"contrast",value:"89")
        await waitUntil{tv.queuedPicture.isEmpty && tv.sendingPicture.isEmpty && !tv.settingsBusy}
        precondition(tv.requestedPicture["contrast"]=="89","Controls must work again after mode settlement")
        let restored=WebOSTV(defaults:defaults,persistPairing:false)
        precondition(restored.requestedPicture["contrast"]=="89" && restored.savedSelectionKeys.contains("contrast"),"Previous choices must restore with a saved marker")
        precondition(restored.picture.isEmpty,"A saved choice must never become a received TV value")
        let other=restored.add(name:"Other",host:"192.168.0.112",mac:"")
        precondition(other && restored.requestedPicture.isEmpty,"Saved choices must be isolated per TV")

        tv.readPicture(keys:["gamma"]);await settle()
        precondition(tv.picture["gamma"]==nil && tv.unavailableKeys["gamma"] != nil,"Missing settings are unavailable, never invented")
        harness.holdReads=true
        tv.readPicture(keys:["brightness"]);await settle()
        let old=harness.held
        harness.foreground("com.webos.app.hdmi2");await settle()
        for (socket,id,key) in old {socket.emit(["type":"response","id":id,"payload":["settings":[key:99]]])}
        await settle()
        precondition(tv.picture.isEmpty,"Old input responses must not enter a new context")
        precondition(tv.requestedPicture["contrast"]==nil,"A different known input must not inherit another input's choices")
        harness.foreground("com.webos.app.hdmi1");await settle()
        precondition(tv.requestedPicture["contrast"]=="89" && tv.savedSelectionKeys.contains("contrast"),"Returning to an input restores its own choices")

        tv.disconnect()
        precondition(tv.picture.isEmpty && tv.volume==nil && tv.muted==nil && !tv.pointerReady)
        tv.button("ENTER")
        precondition(!tv.pointerReady)
        print("PASS: keyboard retention/retry, mode-change lock/recovery, delayed first foreground reply, complete scene previews, stale preview rejection, actual/requested separation, optional reads, queued edits, remote order and volume.")
    }
}
