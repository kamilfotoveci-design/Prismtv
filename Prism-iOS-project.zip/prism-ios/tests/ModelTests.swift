import Foundation

// The real model runs against a scripted socket. No TV or paired credentials required.
@MainActor final class TestSocket:TVSocket {
    var onOpen:(()->Void)?
    var onClose:(()->Void)?
    var sent:[String]=[]
    var failURI:String?
    var responder:(([String:Any])->[String:Any]?)?
    private var waiting:CheckedContinuation<Data,Error>?
    private var inbox:[Data]=[]
    private var closed=false
    func connect(){onOpen?()}
    func send(_ text:String) async throws {
        guard !closed else{throw URLError(.cancelled)}
        sent.append(text)
        guard let data=text.data(using:.utf8),let object=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{return}
        if let failing=failURI,object["uri"] as? String==failing {throw URLError(.networkConnectionLost)}
        if object["type"] as? String=="register" {emit(["type":"registered","payload":[:]]);return}
        if let payload=responder?(object){emit(["type":"response","id":object["id"] ?? "","payload":payload])}
    }
    func emit(_ object:[String:Any]){let data=try! JSONSerialization.data(withJSONObject:object);if let continuation=waiting {waiting=nil;continuation.resume(returning:data)}else{inbox.append(data)}}
    func receive() async throws -> Data {
        if !inbox.isEmpty{return inbox.removeFirst()}
        if closed{throw URLError(.cancelled)}
        return try await withCheckedThrowingContinuation{waiting=$0}
    }
    func close(){closed=true;waiting?.resume(throwing:URLError(.cancelled));waiting=nil;onClose?()}
}
@MainActor final class Harness {
    var sockets:[TestSocket]=[]
    var backend:[String:Any]=["backlight":64,"contrast":"85","brightness":50,"color":50]
    var holdReads=false
    var volumePayload:[String:Any]=["volumeStatus":["volume":27,"mute":false]]
    var held:[(TestSocket,String,String)]=[]
    func make(_ url:URL)->TVSocket {
        let socket=TestSocket();sockets.append(socket)
        socket.responder={[weak self,weak socket] object in
            guard let self=self,let socket=socket else{return nil}
            let uri=object["uri"] as? String ?? ""
            if uri.hasSuffix("getPointerInputSocket"){return ["socketPath":"ws://192.168.0.110:3000/pointer"]}
            if uri.hasSuffix("getSystemSettings") {
                let payload=object["payload"] as? [String:Any] ?? [:]
                let key=(payload["keys"] as? [String])?.first ?? ""
                if self.holdReads {self.held.append((socket,object["id"] as? String ?? "",key));return nil}
                return ["returnValue":true,"settings":self.backend[key].map{[key:$0]} ?? [:]]
            }
            if uri.hasSuffix("getVolume"){return self.volumePayload}
            // Deliberately acknowledge writes without mutating the TV backend.
            return ["returnValue":true]
        }
        return socket
    }
}
@main struct ModelTests {
    @MainActor static func settle() async {for _ in 0..<120 {await Task.yield()};try? await Task.sleep(nanoseconds:30_000_000)}
    @MainActor static func main() async {
        let suite="PrismTests-\(UUID().uuidString)"
        let defaults=UserDefaults(suiteName:suite)!
        defer {defaults.removePersistentDomain(forName:suite)}
        let harness=Harness()
        let tv=WebOSTV(defaults:defaults,persistPairing:false,socketFactory:{harness.make($0)})
        precondition(tv.add(name:"Test TV",host:"192.168.0.110",mac:""))
        let active=tv.selected!
        precondition(tv.add(name:"Spare",host:"192.168.0.111",mac:""))
        let spare=tv.selected!
        tv.select(active);tv.connect();await settle()
        precondition(tv.connected && tv.pointerReady,"Navigation must use the open event, no ping dependency")
        precondition(tv.picture["backlight"]=="64","Only the TV's numeric response is shown")
        precondition(tv.volume==27 && tv.muted==false,"Nested volume responses are parsed")
        harness.volumePayload=["volumeStatus":["volume":-1,"muteStatus":true]]
        tv.readVolume();await settle()
        precondition(tv.volume==nil && tv.muted==true,"External sound output -1 is not a real volume")
        harness.volumePayload=["volumeStatus":["volume":27,"mute":false]]
        tv.readVolume();await settle()
        harness.sockets.first!.failURI="ssap://audio/volumeUp"
        var failureReported=false
        tv.request("audio/volumeUp"){result in if case .failure=result {failureReported=true}}
        await settle()
        precondition(failureReported,"Transport send errors must finish pending requests immediately")
        harness.sockets.first!.failURI=nil
        tv.saveProfile("Read values")
        precondition(tv.profiles.last?.confirmed==true && tv.profiles.last?.settings["backlight"]=="64")
        let legacy:[String:Any]=["id":UUID().uuidString,"name":"Legacy","device":active.uuidString,"settings":["backlight":"99"]]
        let legacyData=try! JSONSerialization.data(withJSONObject:legacy)
        let legacyScene=try! JSONDecoder().decode(PictureProfile.self,from:legacyData)
        precondition(legacyScene.confirmed==nil,"Legacy scenes must not be labelled confirmed")
        tv.remove(spare)
        precondition(tv.connected && tv.selected==active,"Deleting another TV must preserve the connection")
        for key in ["UP","DOWN","LEFT","RIGHT","ENTER"] {tv.button(key)}
        await settle()
        let pointer=harness.sockets.last!
        precondition(pointer.sent == ["UP","DOWN","LEFT","RIGHT","ENTER"].map{TVProtocol.button($0)},"Rapid buttons must retain order")
        tv.writePicture(["backlight":"99"]);await settle()
        precondition(tv.requestedPicture["backlight"]=="99")
        precondition(tv.picture["backlight"]=="64","An ACK must not replace the actual TV value")
        tv.readPicture(keys:["gamma"]);await settle()
        precondition(tv.picture["gamma"]==nil && tv.unavailableKeys["gamma"] != nil,"Missing settings are unavailable, never invented")
        harness.holdReads=true
        tv.readPicture(keys:["brightness"]);await settle()
        let old=harness.held
        tv.invalidatePicture()
        for (socket,id,key) in old {socket.emit(["type":"response","id":id,"payload":["settings":[key:99]]])}
        await settle()
        precondition(tv.picture.isEmpty,"Old input responses must not enter a new context")
        tv.disconnect()
        precondition(tv.picture.isEmpty && tv.volume==nil && tv.muted==nil && !tv.pointerReady)
        tv.button("ENTER")
        precondition(!tv.pointerReady)
        print("PASS: actual vs requested values, unavailable reads, stale input responses, rapid remote order, socket lifecycle, volume and deleting an inactive TV.")
    }
}
