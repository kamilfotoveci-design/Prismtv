import Foundation

// The real model runs against a scripted socket. No TV or paired credentials required.
@MainActor final class TestSocket:TVSocket {
    var onOpen:(()->Void)?
    var onClose:(()->Void)?
    var sent:[String]=[]
    var failURI:String?
    var responder:(([String:Any])->[String:Any]?)?
    private var waiting:CheckedContinuation<Data,Error>?
    private var inbox:[Data]=[]
    private var closed=false
    func connect(){onOpen?()}
    func send(_ text:String) async throws {
        guard !closed else{throw URLError(.cancelled)}
        sent.append(text)
        guard let data=text.data(using:.utf8),let object=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{return}
        if let failing=failURI,object["uri"] as? String==failing {throw URLError(.networkConnectionLost)}
        if object["type"] as? String=="register" {emit(["type":"registered","payload":[:]]);return}
        if let payload=responder?(object){emit(["type":"response","id":object["id"] ?? "","payload":payload])}
    }
    func emit(_ object:[String:Any]){let data=try! JSONSerialization.data(withJSONObject:object);if let continuation=waiting {waiting=nil;continuation.resume(returning:data)}else{inbox.append(data)}}
    func receive() async throws -> Data {
        if !inbox.isEmpty{return inbox.removeFirst()}
        if closed{throw URLError(.cancelled)}
        return try await withCheckedThrowingContinuation{waiting=$0}
    }
    func close(){closed=true;waiting?.resume(throwing:URLError(.cancelled));waiting=nil;onClose?()}
}
@MainActor final class Harness {
    var sockets:[TestSocket]=[]
    var backend:[String:Any]=["pictureMode":"game","backlight":64,"contrast":"85","brightness":50,"color":50]
    var soundBackend:[String:Any]=["soundMode":"standard","soundOutputDigital":"pcm","audioBalance":0,"userEqualizerValues":[0,0,0,0,0]]
    var soundOutput="tv_speaker"
    var holdSoundReads=false
    var heldSound:[(TestSocket,String,String)]=[]
    var settingRejection:[String:Any]?
    var rejectedKeys:Set<String>=[]
    var applyWrites=false
    var readMode=true
    var rejectNormalizedClose=false
    var holdWrites=false
    var heldWrites:[(TestSocket,String)]=[]
    var alertSettings:[String:Any]=[:]
    var holdReads=false
    var foregroundID=""
    var currentForeground=""
    var volumePayload:[String:Any]=["volumeStatus":["volume":27,"mute":false]]
    var held:[(TestSocket,String,String)]=[]
    func foreground(_ app:String){
        currentForeground=app
        sockets.first!.emit(["id":foregroundID,"type":"response","payload":["appId":app]])
    }
    func make(_ url:URL)->TVSocket {
        let socket=TestSocket();sockets.append(socket)
        socket.responder={[weak self,weak socket] object in
            guard let self=self,let socket=socket else{return nil}
            let uri=object["uri"] as? String ?? ""
            if uri.hasSuffix("getPointerInputSocket"){return ["socketPath":"ws://192.168.0.110:3000/pointer"]}
            if uri.hasSuffix("createAlert") {
                let payload=object["payload"] as? [String:Any] ?? [:]
                self.alertSettings=((payload["onclose"] as? [String:Any])?["params"] as? [String:Any]) ?? [:]
                return ["returnValue":true,"alertId":"com.webos.service.apiadapter.pub-test"]
            }
            if uri.hasSuffix("closeAlert") {
                let payload=object["payload"] as? [String:Any] ?? [:]
                if self.rejectNormalizedClose,payload["alertId"] as? String=="com.webos.service.apiadapter-test" {
                    return ["returnValue":false,"errorCode":404,"errorText":"Alert not found"]
                }
                return ["returnValue":true]
            }
            if uri.hasSuffix("setSystemSettings") {
                if self.holdWrites {self.heldWrites.append((socket,object["id"] as? String ?? ""));return nil}
                if let rejection=self.settingRejection {return rejection}
                let payload=object["payload"] as? [String:Any] ?? [:]
                let values=payload["settings"] as? [String:Any] ?? [:]
                if !self.rejectedKeys.isDisjoint(with:values.keys) {return ["returnValue":false,"errorCode":422,"errorText":"Invalid setting value"]}
                if self.applyWrites {
                    if payload["category"] as? String=="sound" {self.soundBackend.merge(values){_,new in new}}
                    else {self.backend.merge(values){_,new in new}}
                }
                return ["returnValue":true]
            }
            if uri.hasSuffix("getSystemSettings") {
                let payload=object["payload"] as? [String:Any] ?? [:]
                let key=(payload["keys"] as? [String])?.first ?? ""
                if payload["category"] as? String=="sound" {
                    if self.holdSoundReads {self.heldSound.append((socket,object["id"] as? String ?? "",key));return nil}
                    return ["returnValue":true,"settings":self.soundBackend[key].map{[key:$0]} ?? [:]]
                }
                if key=="pictureMode",!self.readMode {return ["returnValue":true,"settings":[:]]}
                if self.holdReads {self.held.append((socket,object["id"] as? String ?? "",key));return nil}
                return ["returnValue":true,"settings":self.backend[key].map{[key:$0]} ?? [:]]
            }
            if uri.hasSuffix("getForegroundAppInfo"){
                if object["type"] as? String=="subscribe" {self.foregroundID=object["id"] as? String ?? "";return [:]}
                return ["appId":self.currentForeground]
            }
            if uri.hasSuffix("getSoundOutput"){return ["returnValue":true,"soundOutput":self.soundOutput]}
            if uri.hasSuffix("getVolume"){return self.volumePayload}
            // Deliberately acknowledge writes without mutating the TV backend.
            return ["returnValue":true]
        }
        return socket
    }
}
