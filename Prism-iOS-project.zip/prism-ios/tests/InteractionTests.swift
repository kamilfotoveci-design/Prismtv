import XCTest

// These tests exercise UIKit hit testing on a real simulator window. They do
// not replace protocol tests or verification against a physical LG television.
@MainActor final class InteractionTests:XCTestCase {
    private var app:XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure=false
        app=XCUIApplication()
    }

    override func tearDownWithError() throws {
        let attachment=XCTAttachment(screenshot:app.screenshot())
        attachment.lifetime = .keepAlways
        add(attachment)
        app.terminate()
    }

    private func launch(_ argument:String="--interaction-test") {
        app.terminate()
        app.launchArguments=argument=="--interaction-test" ? [argument] : [argument,"--interaction-test"]
        app.launch()
    }

    private func reveal(_ element:XCUIElement,file:StaticString=#filePath,line:UInt=#line) {
        for _ in 0..<8 {
            if element.exists && element.isHittable {return}
            app.scrollViews.firstMatch.swipeUp()
        }
        XCTAssertTrue(element.exists,"Control missing from accessibility tree",file:file,line:line)
        XCTAssertTrue(element.isHittable,"Control cannot receive a tap",file:file,line:line)
    }

    private func expectValue(_ expected:String,of element:XCUIElement) {
        let predicate=NSPredicate(format:"value == %@",expected)
        expectation(for:predicate,evaluatedWith:element)
        waitForExpectations(timeout:3)
    }

    func testEveryHomeRowRespondsInBlankAreaAndBackWorks() {
        let routes=[("devices","Manage TV"),("remote","Remote"),
                    ("picture","Display Settings"),("sound","Sound Settings"),
                    ("connectivity","Connectivity"),("calibration","Calibration Guide"),
                    ("scenes","Presets"),("quickAccess","Quick Access"),
                    ("media","Apps & Inputs")]
        for (route,title) in routes {
            launch()
            let row=app.buttons["route."+route]
            reveal(row)
            XCTAssertTrue(row.isEnabled,"Offline navigation must remain enabled: "+route)
            // Tap empty space before the chevron, rather than just the text/icon.
            row.coordinate(withNormalizedOffset:CGVector(dx:0.82,dy:0.5)).tap()
            let bar=app.navigationBars[title]
            XCTAssertTrue(bar.waitForExistence(timeout:5),"Route did not open: "+route)
            bar.buttons.firstMatch.tap()
            XCTAssertTrue(app.buttons["toolbar.settings"].waitForExistence(timeout:5),"Back failed: "+route)
        }
    }

    func testToolbarSettingsToggleAndTVButton() {
        launch()
        app.buttons["toolbar.settings"].tap()
        XCTAssertTrue(app.navigationBars["App Settings"].waitForExistence(timeout:5))
        let toggle=app.switches["prefs.readback"]
        XCTAssertTrue(toggle.waitForExistence(timeout:5))
        let before=toggle.value as? String
        toggle.tap()
        XCTAssertNotEqual(toggle.value as? String,before)
        app.navigationBars["App Settings"].buttons.firstMatch.tap()
        app.buttons["toolbar.devices"].tap()
        XCTAssertTrue(app.navigationBars["Manage TV"].waitForExistence(timeout:5))
    }

    func testOfflinePictureHelpWorksWhileTVWritesStayDisabled() {
        launch()
        app.buttons["route.picture"].tap()
        let info=app.buttons["picture.info.contrast"]
        reveal(info)
        XCTAssertFalse(app.buttons["picture.step.up.contrast"].isEnabled)
        info.tap()
        XCTAssertTrue(app.staticTexts["What it does"].waitForExistence(timeout:5))
        app.buttons["Done"].tap()
        XCTAssertTrue(app.navigationBars["Display Settings"].waitForExistence(timeout:5))
    }

    func testOfflineSoundHelpWorks() {
        launch()
        app.buttons["route.sound"].tap()
        let info=app.buttons["sound.info.soundOutput"]
        reveal(info)
        info.tap()
        XCTAssertTrue(app.staticTexts["What it does"].waitForExistence(timeout:5))
        app.buttons["Done"].tap()
        XCTAssertTrue(app.navigationBars["Sound Settings"].waitForExistence(timeout:5))
    }

    func testPictureStepButtonsDispatchAgainstDebugFixture() {
        launch("--preview-picture")
        let plus=app.buttons["picture.step.up.contrast"]
        reveal(plus)
        XCTAssertTrue(plus.isEnabled)
        XCTAssertEqual(app.buttons["picture.value.contrast"].label,"Enter an exact value for Contrast")
        plus.tap()
        // The exact-value button contains the requested number; it is never
        // represented as a newly received TV reading by this fixture test.
        let value=app.buttons["picture.value.contrast"]
        expectValue("86",of:value)
        app.buttons["picture.step.down.contrast"].tap()
        expectValue("85",of:value)
    }

    func testPictureCategoriesSearchAndInlineRangeChoices() {
        launch("--preview-picture")
        app.buttons["picture.category.Gaming"].tap()
        let full=app.buttons["picture.option.blackLevel.high"]
        reveal(full)
        XCTAssertTrue(app.buttons["picture.option.blackLevel.auto"].exists)
        XCTAssertTrue(app.buttons["picture.option.blackLevel.low"].exists)
        XCTAssertTrue(full.isEnabled)
        full.tap()
        expectValue("My choice",of:full)
        let search=app.textFields["picture.search"]
        search.tap()
        search.typeText("contrast")
        let contrast=app.buttons["picture.info.contrast"]
        XCTAssertTrue(contrast.waitForExistence(timeout:5),"Search must include settings outside the selected category")
        XCTAssertFalse(app.buttons["picture.option.blackLevel.high"].exists)
        app.buttons["Clear search"].tap()
        reveal(app.buttons["picture.option.blackLevel.high"])
    }
}
