"""Run the real state machine on Linux with platform I/O replaced by test doubles.

No generated file enters the app target. Keychain, native sockets, Published/
Combine notifications and Wake-on-LAN need Apple platform checks separately.
"""
from pathlib import Path
import os
import subprocess

root = Path(__file__).resolve().parents[1]
build = root / 'build' / 'portable'
build.mkdir(parents=True, exist_ok=True)
source = (root / 'Prism/WebOSTV.swift').read_text()
for name in ['Combine', 'Network', 'Security']:
    source = source.replace('import ' + name + '\n', '')
a = source.index('private enum PairingStore {')
b = source.index('@MainActor final class WebOSTV', a)
source = source[:a] + '''private enum PairingStore {
    static func read(_ host:String)->String? {nil}
    static func save(_ key:String,host:String){}
    static func delete(_ host:String){}
}
protocol ObservableObject {}
@propertyWrapper struct Published<Value> {
    var wrappedValue:Value
    init(wrappedValue:Value){self.wrappedValue=wrappedValue}
}
''' + source[b:]
source = source.replace('    private var wakeConnection: NWConnection?\n', '')
a = source.index('    func wake() {')
# wake is the final method. All state-machine logic above stays byte-for-byte.
source = source[:a] + '    func wake(){status="Wake I/O is excluded from portable tests."}\n}\n'
socket = (root / 'Prism/TVSocket.swift').read_text()
a = socket.index('@MainActor protocol TVSocket')
b = socket.index('private final class SocketLifecycle', a)
socket = 'import Foundation\n' + socket[a:b] + '''
@MainActor final class NativeTVSocket:TVSocket {
    var onOpen:(()->Void)?
    var onClose:(()->Void)?
    init(url:URL,certificatePin:String?,untrusted:@escaping @MainActor (String)->Void){}
    func connect(){preconditionFailure("Inject a TestSocket")}
    func send(_ text:String) async throws {throw URLError(.unsupportedURL)}
    func receive() async throws -> Data {throw URLError(.unsupportedURL)}
    func close(){}
}
'''
(build / 'WebOSTV.swift').write_text(source)
(build / 'TVSocket.swift').write_text(socket)
swift = os.environ.get('SWIFTC', 'swiftc')
common = [str(root / ('Prism/' + f)) for f in ['TVProtocol.swift', 'B9Presets.swift', 'TVModels.swift']]
for test in ['ProtocolTests', 'ModelTests', 'RegressionTests']:
    files = common + ([str(build / 'TVSocket.swift'), str(build / 'WebOSTV.swift'), str(root / 'tests/TVHarness.swift')] if test != 'ProtocolTests' else [])
    output = str(build / test)
    subprocess.run([swift, '-g', '-swift-version', '5', *files, str(root / ('tests/' + test + '.swift')), '-o', output], check=True)
    subprocess.run([output], check=True)
