#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcodebuild -project Prism.xcodeproj -scheme Prism -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/Simulator CODE_SIGNING_ALLOWED=NO build 2>&1 | tee build/simulator-build.log
simulator_id="$(xcrun simctl list devices available --json | python3 -c 'import json,sys; d=json.load(sys.stdin); a=[p for group in d["devices"].values() for p in group if p.get("isAvailable") and "iPhone" in p["name"]]; assert a,"No iPhone simulator installed"; print(a[0]["udid"])')"
if ! xcrun simctl boot "$simulator_id"; then
  xcrun simctl list devices booted | grep -F "$simulator_id"
fi
xcrun simctl bootstatus "$simulator_id" -b
xcrun simctl install "$simulator_id" build/Simulator/Build/Products/Debug-iphonesimulator/Prism.app
xcrun simctl launch --terminate-running-process "$simulator_id" com.kamilwhoo.prismtv
sleep 3
xcrun simctl spawn "$simulator_id" launchctl list > build/simulator-processes.txt
python3 - <<'PY'
from pathlib import Path
lines=Path('build/simulator-processes.txt').read_text().splitlines()
assert any('com.kamilwhoo.prismtv' in line and line.split()[0].isdigit() and int(line.split()[0]) > 0 for line in lines), 'Prism exited after launch. Check simulator diagnostics in the build log.'
print('PASS: Prism stayed running after simulator launch.')
PY
xcrun simctl io "$simulator_id" screenshot build/simulator-launch.png
xcrun simctl terminate "$simulator_id" com.kamilwhoo.prismtv

# A clearly marked Debug-only fixture, without networking, captures the Picture UI.
xcrun simctl launch --terminate-running-process "$simulator_id" com.kamilwhoo.prismtv --preview-picture
sleep 2
xcrun simctl io "$simulator_id" screenshot build/simulator-picture-preview.png
xcrun simctl terminate "$simulator_id" com.kamilwhoo.prismtv
