"""Validate source archive wiring and icon files before invoking Xcode."""
from pathlib import Path
import json
import plistlib
import re
import struct
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parents[1]
project=(root/'Prism.xcodeproj/project.pbxproj').read_text()
objects=re.findall(r'^([0-9A-F]{24}) = \{',project,re.M)
assert len(objects)==len(set(objects)), 'Duplicate project object IDs'
known=set(objects)
refs=set(re.findall(r'\b[0-9A-F]{24}\b',project))
assert refs<=known, f'Dangling project IDs: {refs-known}'
file_refs=dict(re.findall(r'([0-9A-F]{24}) = \{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = ([^;]+);',project))
source_phase=re.search(r'isa = PBXSourcesBuildPhase;[^\n]+?files = \(([^)]+)\)',project).group(1)
compiled=[]
for build_id in re.findall(r'[0-9A-F]{24}',source_phase):
    match=re.search(build_id+r' = \{isa = PBXBuildFile; fileRef = ([0-9A-F]{24});',project)
    assert match, f'Missing build object {build_id}'
    compiled.append(file_refs[match.group(1)])
actual={p.name for p in (root/'Prism').glob('*.swift')}
assert set(compiled)==actual and len(compiled)==len(actual), 'Swift source phase is incomplete or duplicated'
info=plistlib.loads((root/'Prism/Info.plist').read_bytes())
assert info['CFBundleShortVersionString']=='2.6.2' and info['CFBundleVersion']=='13'
assert project.count('CURRENT_PROJECT_VERSION = 13;')==2
assert project.count('MARKETING_VERSION = 2.6.2;')==2
assert info.get('NSLocalNetworkUsageDescription')
icons=root/'Prism/Assets.xcassets/AppIcon.appiconset'
catalog=json.loads((icons/'Contents.json').read_text())
for icon in catalog['images']:
    path=icons/icon['filename']
    png=path.read_bytes()
    assert png[:8]==b'\x89PNG\r\n\x1a\n'
    width,height,depth,colour=struct.unpack('>IIBB',png[16:26])
    expected=round(float(icon['size'].split('x')[0])*float(icon['scale'][:-1]))
    assert width==height==expected, f'Wrong dimensions: {path.name}'
    assert colour==2 and depth==8, f'Icon must be opaque RGB: {path.name}'
print(f'PASS: {len(actual)} Swift source references, project IDs, version, privacy text and {len(catalog["images"])} RGB app icons.')

# The scheme must run the UI test bundle, not silently succeed with zero tests.
scheme=ET.parse(root/'Prism.xcodeproj/xcshareddata/xcschemes/Prism.xcscheme')
testables=scheme.findall('./TestAction/Testables/TestableReference')
assert len(testables)==1 and testables[0].get('skipped')=='NO'
test_ref=testables[0].find('BuildableReference')
assert test_ref is not None and test_ref.get('BlueprintName')=='PrismUITests'
test_id=test_ref.get('BlueprintIdentifier')
assert test_id in known
assert 'com.apple.product-type.bundle.ui-testing' in project
assert (root/'tests/InteractionTests.swift').is_file()
smoke=(root/'scripts/smoke-test.sh').read_text()
assert 'xcodebuild test ' in smoke and 'interaction-build.log' in smoke
print('PASS: native UI test target, shared TestAction and CI interaction gate wired.')

# App-owned strings must remain English; Unicode user data in test fixtures is intentional.
for source in (root/'Prism').glob('*.swift'):
    assert not re.search('[áčďéíľĺňóôŕšťúýžÁČĎÉÍĽĹŇÓÔŔŠŤÚÝŽ]',source.read_text()), f'Untranslated app text: {source.name}'
    assert not any(token in source.read_text() for token in [' ako ', 'MAC adresa', 'vstup', 'Potiahni']), f'Known untranslated text: {source.name}'
assert info.get('CFBundleLocalizations') == ['en'], 'English app language must be declared'
print('PASS: known untranslated labels absent; English bundle language. Human language review still required.')
