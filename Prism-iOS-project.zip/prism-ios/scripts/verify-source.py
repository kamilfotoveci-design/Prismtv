"""Validate source archive wiring and icon files before invoking Xcode."""
from pathlib import Path
import json
import plistlib
import re
import struct

root=Path(__file__).resolve().parents[1]
project=(root/'Prism.xcodeproj/project.pbxproj').read_text()
objects=re.findall(r'^([0-9A-F]{24}) = \{',project,re.M)
assert len(objects)==len(set(objects)), 'Duplicate project object IDs'
known=set(objects)
refs=set(re.findall(r'\b[0-9A-F]{24}\b',project))
assert refs<=known, f'Dangling project IDs: {refs-known}'
file_refs=dict(re.findall(r'([0-9A-F]{24}) = \{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = ([^;]+);',project))
source_phase=re.search(r'isa = PBXSourcesBuildPhase;[^\n]+?files = \(([^)]+)\)',project).group(1)
compiled=[]
for build_id in re.findall(r'[0-9A-F]{24}',source_phase):
    match=re.search(build_id+r' = \{isa = PBXBuildFile; fileRef = ([0-9A-F]{24});',project)
    assert match, f'Missing build object {build_id}'
    compiled.append(file_refs[match.group(1)])
actual={p.name for p in (root/'Prism').glob('*.swift')}
assert set(compiled)==actual and len(compiled)==len(actual), 'Swift source phase is incomplete or duplicated'
info=plistlib.loads((root/'Prism/Info.plist').read_bytes())
assert info['CFBundleShortVersionString']=='2.3.0' and info['CFBundleVersion']=='8'
assert project.count('CURRENT_PROJECT_VERSION = 8;')==2
assert project.count('MARKETING_VERSION = 2.3.0;')==2
assert info.get('NSLocalNetworkUsageDescription')
icons=root/'Prism/Assets.xcassets/AppIcon.appiconset'
catalog=json.loads((icons/'Contents.json').read_text())
for icon in catalog['images']:
    path=icons/icon['filename']
    png=path.read_bytes()
    assert png[:8]==b'\x89PNG\r\n\x1a\n'
    width,height,depth,colour=struct.unpack('>IIBB',png[16:26])
    expected=round(float(icon['size'].split('x')[0])*float(icon['scale'][:-1]))
    assert width==height==expected, f'Wrong dimensions: {path.name}'
    assert colour==2 and depth==8, f'Icon must be opaque RGB: {path.name}'
print(f'PASS: {len(actual)} Swift source references, project IDs, version, privacy text and {len(catalog["images"])} RGB app icons.')
