"""Reject damaged/mislabelled source ZIPs and IPA packages before publishing."""
import argparse
import hashlib
import plistlib
import stat
import zipfile
from pathlib import Path, PurePosixPath


def verify(path, kind):
    path = Path(path)
    if not zipfile.is_zipfile(path):
        raise ValueError('Not a ZIP archive (possibly an incomplete download or an HTML error page)')
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        names = [e.filename for e in entries]
        if len(names) != len(set(names)):
            raise ValueError('Duplicate archive paths')
        for e in entries:
            p = PurePosixPath(e.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in e.filename:
                raise ValueError('Unsafe archive path')
            if e.flag_bits & 1:
                raise ValueError('Encrypted archive entry')
            if stat.S_ISLNK(e.external_attr >> 16):
                raise ValueError('Symlink archive entry')
        bad = archive.testzip()
        if bad:
            raise ValueError('Damaged entry: ' + bad)
        if kind == 'source':
            required = ['prism-ios/Prism/Info.plist', 'prism-ios/Prism.xcodeproj/project.pbxproj',
                        'prism-ios/build-ipa.sh', 'prism-ios/scripts/verify-archive.py',
                        'BUILD_WORKFLOW.yml']
            if any(n not in names for n in required):
                raise ValueError('Source archive is incomplete or has the wrong folder layout')
            if any(n.endswith('.ipa') for n in names):
                raise ValueError('Source ZIP must not contain a stale IPA')
            info = plistlib.loads(archive.read(required[0]))
        else:
            base = 'Payload/Prism.app/'
            if base + 'Info.plist' not in names:
                raise ValueError('No Payload/Prism.app; import the IPA inside the GitHub artifact ZIP')
            info = plistlib.loads(archive.read(base + 'Info.plist'))
            executable = base + info.get('CFBundleExecutable', '')
            if executable not in names:
                raise ValueError('Missing app executable')
            binary = archive.read(executable)
            if len(binary) < 32 or binary[:4] not in (b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca'):
                raise ValueError('Invalid Mach-O executable')
            if not stat.S_IMODE(archive.getinfo(executable).external_attr >> 16) & 0o111:
                raise ValueError('Executable permissions lost in IPA packaging')
            if base + 'Assets.car' not in names:
                raise ValueError('Missing compiled assets')
            if info.get('CFBundleIdentifier') != 'com.kamilwhoo.prismtv':
                raise ValueError('Unexpected bundle identifier')
        if info.get('CFBundleShortVersionString') != '2.6.1' or info.get('CFBundleVersion') != '12':
            raise ValueError('Wrong app version in archive')
    return hashlib.sha256(path.read_bytes()).hexdigest()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['source', 'ipa'])
    parser.add_argument('path')
    args = parser.parse_args()
    try:
        digest = verify(args.path, args.kind)
        print('PASS:', args.kind, 'integrity, contents and version')
        print('SHA256:', digest)
    except (OSError, ValueError, KeyError, zipfile.BadZipFile, plistlib.InvalidFileException) as error:
        raise SystemExit('ARCHIVE VALIDATION FAILED: ' + str(error))
