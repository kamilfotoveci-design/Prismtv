# Prism 2.7.0 repair audit

| Finding | Result |
| --- | --- |
| Fallback predicate omitted 401 and insufficient permissions | Fixed; regression sends a code-only 401 through the real parser and queue |
| Error handling discarded errorCode and nested error details | Fixed; typed rejection preserves code/reason and request URI in diagnostics |
| Direct settings rejection repeated on every change | Working compatibility route cached per category until reconnect |
| Three separate alert implementations | Consolidated; missing alert IDs and rejected close IDs handled |
| Generic notice stayed after a successful picture retry | Cleared on accepted request |
| Scene required readable pictureMode on every firmware | Settles first; unavailable read remains unverified; explicit mismatch stops |
| One bad scene setting rejected the whole dictionary | Each setting sent separately; rejected keys reported |
| Sound-mode change erased external output selection | Output retained as a request; no old EQ snapshot survives |
| Unknown output allowed TV EQ | Requires an explicitly known/requested TV speaker route |
| Sound search/context change failed to load controls | Missing reads loaded on query/context changes |
| Input changes with polling off left empty old context | Event-driven fresh core snapshot; stale replies discarded |
| Foreground ID shown as youtube.leanback.v4 | App-list title or YouTube fallback shown |
| Controls visible through translucent dock | Dock has an opaque backing; original compact cards/pills retained |
| Rejected slider draft remained onscreen | Draft resets on failed request; received state remains separate |
| Disconnect dropped callbacks silently | Pending request completion receives failure; scene continuations can finish |
| Compatible-write preference not retained | Saved/restored from app preferences |
| App/archive version checks differed | 2.7.0 / build 14 throughout |
| Fixed list of Xcode patch names | Detect installed Xcode 26+ |
| Standalone test compilation used implicit macOS target | Explicit macOS 14 target for SDK availability |

Validation scope: Swift source parsing; protocol, scripted-socket state-machine and regression tests; Python archive tests; Xcode source references/version/assets checks; shell syntax. Linux portable tests replace platform I/O and observation with doubles. Native UI tests remain wired into CI. A real iOS build and tests on the user's LG B9 were not performed in this workspace.

TV limitations remain visible. Compatibility-alert acknowledgement does not return the nested Luna result, so physical success must be read back where supported or checked on TV. Unreadable values are not represented as confirmed. Preset requests do not force the incoming video signal. TV sound controls do not configure the TCL soundbar's DSP.
