# Prism 2.6.2 · interaction audit

Scope: all app-owned navigation and interaction surfaces in the supplied SwiftUI source, including Home, toolbar, Display, Sound/EQ, Remote, scenes, devices and media. This is a source audit with regression tests added; it is not a completed physical-iPhone or LG B9 certification.

## Findings and changes

| Area | Finding | Change |
| --- | --- | --- |
| Home rows | Spacer/empty regions did not explicitly declare a rectangular hit region. Tapping the label was not an adequate test of the row. | Full-width button labels and rectangular content shapes; at least 44-point targets. UI tests tap blank space before the chevron in every Home row. |
| Navigation | Routing depended on value links resolved through custom view wrappers. No native navigation regression test existed. This was a risk, not a proven runtime failure. | One observable, root-owned path and explicit route buttons; native Back and destination titles retained. Repeated opening of the current destination is ignored. |
| Glass | GlassEffectContainer wrapped interactive content. A screenshot cannot establish whether it intercepted taps on the user's device. | All glass decoration moved behind content and marked noninteractive and hidden from accessibility. No GlassEffectContainer surrounds controls. Material/Reduce Transparency fallbacks retained. |
| Toolbar | Custom glass plus the system toolbar treatment produced two nested glass shapes in the screenshot. | Removed custom toolbar glass. System toolbar surface and 44-point icon targets retained. |
| Offline behavior | Screen-wide disabling can make navigation/help/local actions appear broken even when only a TV write is unavailable. Home navigation itself was not explicitly disabled. | Navigation and help remain available offline. Connection, context transition and command guards remain on TV writes. Unknown numeric values do not enable +/- based on an invented reading. |
| Equalizer | An inherited disabled modifier blocked the entire EQ card, including local Flat preview. | Individual guards for sliders/Apply and Read EQ. Flat preview stays local and accessible; it sends nothing until Apply. External soundbar output still blocks TV EQ writes. |
| Media | Launch and favourite buttons shared a List row; broad disabling also blocked local favourite changes. | Explicit borderless row buttons, independent launch guards, favourite action remains local. |
| Verification | Simulator launch/screenshots did not test tap delivery. | Added a native UI test target and shared scheme TestAction. CI tests interactions before building the release IPA. |

## Interaction review

- Home, toolbar and in-app route buttons use the same root router. Remote/Display connection actions lead to Manage TV.
- Display sliders, +/- and choices remain inline. Info sheets and exact-value entry are separate actions. Decorative strokes cannot receive touches.
- Bottom category/search controls occupy a safe-area inset, rather than an overlay covering the scroll content. Category changes/search do not introduce automatic TV refreshes.
- Sound follows the same decorative-background rule. Help stays enabled independently of TV write availability.
- Remote D-pad, touchpad and keyboard keep their pointer/connection guards. Touchpad drag and tap gestures are confined to its own surface, not a page-wide gesture.
- Scene/preset review, device IP validation and pending input/mode guards remain enforced. Enabling these blindly would make invalid requests possible rather than fix hit testing.
- Labels remain English. Larger text keeps adaptive layout; Reduce Transparency keeps opaque backgrounds. Minimum control targets remain 44 points.

## Regression tests added

`tests/InteractionTests.swift` exercises native simulator hit testing:

1. All nine Home destinations, tapping the blank region of each row, and Back navigation.
2. Both toolbar buttons and a real preference toggle.
3. Display help while disconnected, with TV-write controls still disabled.
4. Sound help while disconnected.
5. Picture +/- dispatch and displayed requested value using isolated Debug fixture data.
6. Picture category switching, Auto/Full/Limited choices and cross-category search.

The test fixture uses its own defaults suite and does not clear real pairing data. Test flags are Debug-only. For interaction tests only, writes receive a simulated acknowledgement with no socket or TV readback, avoiding network timeouts in the UI test. Ordinary screenshot previews do not simulate acknowledgements. Fixture tests validate UI dispatch, not TV command acceptance or actual TV readings.

## Verification status and remaining acceptance

Local checks cover project object wiring, source inclusion, test scheme wiring, version/icon/privacy metadata, source delimiter balance, shell syntax, archive CRC/structure and existing archive regression tests. Delimiter checking is not a Swift compiler.

This environment has no Xcode or iOS simulator. Native compilation and the newly added UI tests **have not run here**. The GitHub build must pass them before the IPA is published. A failure stops the pipeline; inspect interaction-build.log and the diagnostic screenshots/xcresult. Existing corrected ZIP workflows still call the same build script, so they pick up the new test gate without a workflow replacement.

On the target iPhone, verify tapping each Home row's icon, text, blank space and chevron, Back, sheets, sliders and small controls. Check both ordinary and accessibility text sizes. Confirm pairing, D-pad, volume, picture/sound writes and truthful readbacks on the actual LG B9. Firmware support and the original device-specific cause remain unconfirmed until that run. Do not interpret fixture values as hardware test evidence.
